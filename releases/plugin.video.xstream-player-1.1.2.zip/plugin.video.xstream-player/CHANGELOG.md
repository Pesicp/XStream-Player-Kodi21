To disable changelog go to Tools/Settings/Update

## V 1.1.3

- Added multilanguage support
- Added 16 new languages: EN, HR, DE, FR, ES, IT, PT, RU, PL, AR, CS, NL, EL, HU, RO, SV
- Go To tools Settings Language