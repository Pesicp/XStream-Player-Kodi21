To disable changelog go to Tools/Settings/Update

Version 2.1.0

### New Features
- Settings/Metadata - New option to disable playlist provider Metadata for movies and series separatly, for users that want faster experience

- Setings/General - Show/Hide playlist folders count

- Continue watching on main screen, combines 10  movies and 10 series across profiles

- When 1 profile on main screen, all of its content can be shown. Added to list - Favorites, Recently watched, Search.

- Expanded support for basic m3u links without creditentials to all known and usable types of playlist