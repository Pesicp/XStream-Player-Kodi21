To disable changelog go to Tools/Settings/Update

Version 2.1.2

### Bug Fixes

- Tools/Show/hide bug on fresh install