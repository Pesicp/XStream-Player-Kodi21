Version 1.1.1
- Fixed PVR not working (added missing ElementTree import)
- Fixed EPG XML parsing for Kodi 21
- Live TV Classic now shows all channels (removed 50 limit)
