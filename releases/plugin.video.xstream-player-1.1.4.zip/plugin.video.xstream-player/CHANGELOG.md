To disable changelog go to Tools/Settings/Update

## V 1.1.4

- Fixed hardcoded 'Favorites' string - now uses translation ID 30703 (AGENTS.md B1)
- Added addon_id validation before f-string in executebuiltin (AGENTS.md C3)
- Attempt to fix android update issues on some android devices