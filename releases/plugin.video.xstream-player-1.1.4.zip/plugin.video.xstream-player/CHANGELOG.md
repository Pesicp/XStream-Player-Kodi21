To disable changelog go to Tools/Settings/Update

## V 1.1.4

- Fixed hardcoded 'Favorites' string - now uses translation ID 30703
- Added addon_id validation before f-string in executebuiltin
- Attempt to fix android update issues on some android devices