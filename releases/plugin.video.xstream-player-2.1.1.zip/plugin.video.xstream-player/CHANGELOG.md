To disable changelog go to Tools/Settings/Update

Version 2.1.1

### Bug Fixes

- Tools/Reorder fixed, now it reorders ungrouped single profile properply. ungroupped profile is moved completly. 

- Tools/Show/hide now shows and manages ungrouped profile complete content properly