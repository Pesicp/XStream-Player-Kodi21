# -*- coding: utf-8 -*-
"""Self-update system for XStream Player"""
import json
import os
import re
import sys
import time
import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

ADDON_ID = 'plugin.video.xstream-player'
RELEASES_API = 'https://api.github.com/repos/Pesicp/XStream-Player-Kodi21/contents/releases'
RELEASES_BASE = 'https://pesicp.github.io/XStream-Player-Kodi21/releases'


def get_addon():
    """Get addon instance"""
    return xbmcaddon.Addon(id=ADDON_ID)


def get_current_version():
    """Get currently installed version"""
    return get_addon().getAddonInfo('version')


def _version_key(v):
    """Parse a version string into a comparable tuple. Tolerates suffixes like '1.0.6-rc1'."""
    parts = re.findall(r'\d+', v or '')
    return tuple(int(p) for p in parts) if parts else (0,)


def _release_url(filename):
    return f'{RELEASES_BASE}/{filename}'


def fetch_all_versions():
    """Fetch all available versions from GitHub API.
    Returns list of dicts with 'version', 'filename', 'url' (sorted newest first).
    """
    try:
        import urllib.request
        req = urllib.request.Request(RELEASES_API, headers={'User-Agent': 'Mozilla/5.0'})
        with urllib.request.urlopen(req, timeout=10) as response:
            data = json.loads(response.read().decode('utf-8'))

        versions = []
        for item in data:
            name = item.get('name', '')
            match = re.match(r'plugin\.video\.xstream-player-([\d.]+)\.zip', name)
            if match:
                versions.append({
                    'version': match.group(1),
                    'filename': name,
                    'url': _release_url(name),
                })

        versions.sort(key=lambda v: _version_key(v['version']), reverse=True)
        return versions
    except Exception as e:
        xbmc.log(f'[XStream Player] Failed to fetch versions: {str(e)}', xbmc.LOGERROR)
        return []


def check_for_update():
    """Check if update is available.
    Returns: (update_available, latest_version, download_url)
    """
    versions = fetch_all_versions()
    if not versions:
        return False, None, None

    latest = versions[0]
    if _version_key(latest['version']) > _version_key(get_current_version()):
        return True, latest['version'], latest['url']
    return False, latest['version'], None


def download_update(url, target_path):
    """Download update zip to temp location"""
    try:
        import urllib.request
        req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
        with urllib.request.urlopen(req, timeout=30) as response:
            with open(target_path, 'wb') as f:
                f.write(response.read())
        return True
    except Exception as e:
        xbmc.log(f'[XStream Player] Download failed: {str(e)}', xbmc.LOGERROR)
        return False


def _perform_install(new_version, url, dialog, completion_title='Update Complete'):
    """Download, extract, and prompt-restart for a given version. Returns True on success."""
    import tempfile
    import zipfile

    progress = xbmcgui.DialogProgress()
    progress.create('XStream Player', f'Downloading version {new_version}...')

    temp_dir = tempfile.gettempdir()
    zip_path = os.path.join(temp_dir, f'{ADDON_ID}-{new_version}.zip')

    success = download_update(url, zip_path)
    progress.close()

    if not success:
        dialog.notification('XStream Player', 'Download failed', xbmcgui.NOTIFICATION_ERROR)
        return False

    progress = xbmcgui.DialogProgress()
    progress.create('XStream Player', 'Installing update...')

    addon_path = xbmcvfs.translatePath('special://home/addons/')
    try:
        with zipfile.ZipFile(zip_path, 'r') as zip_ref:
            zip_ref.extractall(addon_path)
        xbmc.executebuiltin('UpdateLocalAddons')
    except Exception as e:
        xbmc.log(f'[XStream Player] Extract failed: {str(e)}', xbmc.LOGERROR)
        progress.close()
        dialog.notification('XStream Player', 'Install failed', xbmcgui.NOTIFICATION_ERROR)
        return False

    progress.close()

    # Update version setting so user sees new version in settings
    get_addon().setSetting('current_version_display', new_version)

    restart = dialog.yesno(
        completion_title,
        f'Version {new_version} installed successfully!\n\nRelaunch Kodi now?',
        nolabel='Later',
        yeslabel='Restart Now'
    )

    if restart:
        xbmc.executebuiltin('RestartApp')
    return True


def do_direct_update_install(new_version, url):
    """Direct install without check - used from startup prompt"""
    dialog = xbmcgui.Dialog()
    try:
        _perform_install(new_version, url, dialog)
    except Exception as e:
        xbmc.log(f'[XStream Player] Direct update ERROR: {str(e)}', xbmc.LOGERROR)
        dialog.ok('XStream Player', 'Update failed.\n\nPlease try again later.')


def check_and_install_update():
    """Main entry point: Check for update and prompt user (for Tools menu)"""
    xbmc.log('[XStream Player] Check update started', xbmc.LOGDEBUG)
    dialog = xbmcgui.Dialog()

    try:
        progress = xbmcgui.DialogProgress()
        progress.create('XStream Player', 'Checking for updates...')

        update_available, new_version, url = check_for_update()
        xbmc.log(
            f'[XStream Player] Update check: available={update_available}, version={new_version}',
            xbmc.LOGDEBUG,
        )

        progress.close()

        if not update_available:
            if new_version is None:
                dialog.ok('XStream Player', 'Update check failed.\n\nPlease check your internet connection.')
            else:
                dialog.ok('XStream Player', 'No available updates.')
            return

        current = get_current_version()
        result = dialog.yesno(
            'Update Available',
            f'New version found!\n\nCurrent: {current}\nLatest: {new_version}\n\nInstall now?'
        )
        if not result:
            return

        _perform_install(new_version, url, dialog)

    except Exception as e:
        xbmc.log(f'[XStream Player] Update ERROR: {str(e)}', xbmc.LOGERROR)
        import traceback
        xbmc.log(f'[XStream Player] Traceback: {traceback.format_exc()}', xbmc.LOGERROR)
        dialog.ok('XStream Player', 'Update check failed.\n\nPlease try again later.')


def silent_check_on_startup():
    """Background check on startup (if enabled in settings)"""
    addon = get_addon()
    check_interval = addon.getSetting('update_check_interval')

    if check_interval == 'Never':
        return

    last_check = addon.getSetting('last_update_check')
    today = time.strftime('%Y-%m-%d')

    if check_interval == 'Daily':
        if last_check == today:
            return
    elif check_interval == 'Weekly':
        if last_check:
            last_time = time.mktime(time.strptime(last_check, '%Y-%m-%d'))
            now_time = time.mktime(time.strptime(today, '%Y-%m-%d'))
            if (now_time - last_time) < (7 * 24 * 60 * 60):
                return
    elif check_interval == 'Monthly':
        if last_check:
            last_time = time.mktime(time.strptime(last_check, '%Y-%m-%d'))
            now_time = time.mktime(time.strptime(today, '%Y-%m-%d'))
            if (now_time - last_time) < (30 * 24 * 60 * 60):
                return
    # "On Startup" always proceeds here

    update_available, new_version, url = check_for_update()

    if update_available:
        current = get_current_version()
        result = xbmcgui.Dialog().yesno(
            'Update Available',
            f'A new version of XStream Player is available!\n\nCurrent: {current}\nLatest: {new_version}\n\nInstall now?',
            nolabel='Later',
            yeslabel='Install Now'
        )

        if result:
            do_direct_update_install(new_version, url)
            return
        else:
            addon.setSetting('update_available', 'true')
            addon.setSetting('update_version', new_version)

    addon.setSetting('last_update_check', today)


def get_available_versions():
    """Get list of all available version strings (newest first), for revert UI."""
    return [v['version'] for v in fetch_all_versions()]


def revert_to_version(version):
    """Revert to a specific older version."""
    filename = f'plugin.video.xstream-player-{version}.zip'
    url = _release_url(filename)

    dialog = xbmcgui.Dialog()
    result = dialog.yesno(
        'Revert Version',
        f'Downgrade to version {version}?\n\nThis will replace your current installation.'
    )
    if not result:
        return False

    return _perform_install(version, url, dialog, completion_title='Revert Complete')


def revert_version_menu():
    """Show menu to select version to revert to"""
    dialog = xbmcgui.Dialog()

    versions = get_available_versions()
    current = get_current_version()

    if not versions:
        dialog.notification('XStream Player', 'Could not fetch versions', xbmcgui.NOTIFICATION_ERROR)
        return

    older_versions = [v for v in versions if v != current]

    if not older_versions:
        dialog.ok('XStream Player', 'No older versions available to revert.')
        return

    selected = dialog.select(f'Revert to (current: {current})', older_versions)
    if selected == -1:
        return

    revert_to_version(older_versions[selected])


# Entry point for RunScript calls
if __name__ == '__main__':
    if len(sys.argv) > 1:
        action = sys.argv[1]
        if action == 'check':
            check_and_install_update()
        elif action == 'silent':
            silent_check_on_startup()
