import json
import os

import xbmcvfs

from lang import _t


class Favorites:
    def __init__(self, addon, profile_num='1'):
        self.profile_path = xbmcvfs.translatePath(addon.getAddonInfo('profile'))
        self.file = os.path.join(self.profile_path, f'favorites_{profile_num}.json')
        self._ensure_profile()
        # Migration: copy old shared favorites.json to profile-specific file
        if not os.path.exists(self.file):
            old_file = os.path.join(self.profile_path, 'favorites.json')
            if os.path.exists(old_file):
                import shutil
                shutil.copy2(old_file, self.file)
        self.items = self._load()

    def _ensure_profile(self):
        if not os.path.exists(self.profile_path):
            os.makedirs(self.profile_path)

    def _load(self):
        try:
            with open(self.file, 'r', encoding='utf-8') as f:
                data = json.load(f)
                # Migration: old format was flat list, new format has folders
                if isinstance(data, list):
                    folder_name = _t(30703) or 'Favorites'
                    return {folder_name: data}
                return data
        except Exception:
            return {'Favorites': []}

    def _save(self):
        tmp_file = self.file + '.tmp'
        with open(tmp_file, 'w', encoding='utf-8') as f:
            json.dump(self.items, f, ensure_ascii=False)
            # Durability: flush + fsync before rename. Without this, an
            # Android crash / power loss can land the rename before the data
            # reaches disk, leaving a zero-byte favorites file.
            try:
                f.flush()
                os.fsync(f.fileno())
            except OSError:
                pass
        os.replace(tmp_file, self.file)

    def get_folders(self):
        """Return list of folder names."""
        return list(self.items.keys())

    def is_favorite(self, item_id, folder=None):
        if folder:
            return any(i.get('id') == item_id for i in self.items.get(folder, []))
        return any(i.get('id') == item_id
                   for items in self.items.values() for i in items)

    def add(self, item, folder=None):
        # Resolve the default folder name at call time, not at function-def
        # time. Otherwise the default freezes at the language active when
        # favorites.py was first imported and never tracks UI language changes.
        if folder is None:
            folder = _t(30703) or 'Favorites'
        if folder not in self.items:
            self.items[folder] = []
        if not self.is_favorite(item.get('id'), folder):
            self.items[folder].append(item)
            self._save()
            return True
        return False

    def remove(self, item_id, folder=None):
        removed = False
        if folder:
            before = len(self.items.get(folder, []))
            self.items[folder] = [i for i in self.items.get(folder, []) if i.get('id') != item_id]
            removed = len(self.items[folder]) < before
        else:
            for f in self.items:
                before = len(self.items[f])
                self.items[f] = [i for i in self.items[f] if i.get('id') != item_id]
                if len(self.items[f]) < before:
                    removed = True
        if removed:
            self._save()
        return removed

    def get_all(self, folder=None):
        if folder:
            return self.items.get(folder, [])
        # Flat list of all items across all folders
        result = []
        for items in self.items.values():
            result.extend(items)
        return result

    def toggle(self, item, folder=None):
        if folder is None:
            folder = _t(30703) or 'Favorites'
        if self.is_favorite(item.get('id')):
            self.remove(item.get('id'))
            return False
        else:
            self.add(item, folder)
            return True

    def create_folder(self, name):
        if name not in self.items:
            self.items[name] = []
            self._save()

    def rename_folder(self, old_name, new_name):
        if old_name in self.items and new_name not in self.items:
            self.items[new_name] = self.items.pop(old_name)
            self._save()

    def delete_folder(self, name):
        # Protect the default folder regardless of UI language. Compare against
        # both the localized name and the English literal so a Croatian user
        # with "PVR favoriti" gets the same protection an English user gets.
        protected = {'Favorites', _t(30703) or 'Favorites'}
        if name in self.items and name not in protected:
            del self.items[name]
            self._save()

    def export_m3u(self, path, folder=None):
        """Export favorites as M3U file."""
        items = self.get_all(folder)
        lines = ['#EXTM3U']
        for item in items:
            name = item.get('name', 'Unknown')
            url = item.get('url', '')
            icon = item.get('icon', '')
            if not url:
                continue
            attrs = f'tvg-name="{name}"'
            if icon:
                attrs += f' tvg-logo="{icon}"'
            lines.append(f'#EXTINF:-1 {attrs},{name}')
            lines.append(url)
        with open(path, 'w', encoding='utf-8') as f:
            f.write('\n'.join(lines))
        return len(items)
