import json
import os
import re
import sys
import threading
import time
import urllib.parse
import xml.etree.ElementTree as ET
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

# Fix for Android: ensure Python's tempfile uses Kodi's writable temp directory
# Standard system temp paths (/tmp, /var/tmp) are not accessible on Android
import tempfile
tempfile.tempdir = xbmcvfs.translatePath('special://temp/')

from iptv import IPTV, build_m3u_content
from epg import EPG, _parse_xmltv_time
from favorites import Favorites
from history import WatchHistory, ResumePoints, WatchedEpisodes, WatchedMovies
from profiles import ProfileManager, RefreshTracker
from tmdb import TMDB
from lang import _t

addon = xbmcaddon.Addon()
addon_handle = int(sys.argv[1])
base_url = sys.argv[0]
args = urllib.parse.parse_qs(sys.argv[2][1:])
pm = ProfileManager(addon)
fav = Favorites(addon, pm.active)
watch_history = WatchHistory(addon)
resume_db = ResumePoints(addon)
watched_db = WatchedEpisodes(addon)
watched_movies = WatchedMovies(addon)

import xbmc

def _bootstrap_settings():
    profile = xbmcvfs.translatePath(addon.getAddonInfo('profile'))
    dest = os.path.join(profile, 'settings.xml')
    if os.path.exists(dest):
        return
    src = os.path.join(xbmcvfs.translatePath(addon.getAddonInfo('path')), 'resources', 'userdata', 'settings.xml')
    if os.path.exists(src):
        if not os.path.exists(profile):
            os.makedirs(profile)
        import shutil
        shutil.copy2(src, dest)
        xbmc.log('[XStream Player] Bootstrapped settings from addon package', xbmc.LOGINFO)

_bootstrap_settings()


def _configure_kodi_pvr_osd():
    """Configure Kodi's PVR OSD navigation settings"""
    try:
        if addon.getSetting('pvr_osd_navigation') != 'true':
            return
        
        # Enable PVR channel info and guide on arrow keys
        # These are Kodi settings, not addon settings
        settings = {
            'pvrplayback.confirmchannelswitch': 'false',  # Don't confirm channel switch
            'pvrplayback.channelentrytimeout': '0',  # Immediate channel switch
        }
        
        for setting, value in settings.items():
            xbmc.executeJSONRPC(json.dumps({
                'jsonrpc': '2.0', 'method': 'Settings.SetSettingValue',
                'params': {'setting': setting, 'value': value}, 'id': 1
            }))
        
        xbmc.log('[XStream Player] Configured Kodi PVR OSD settings', xbmc.LOGINFO)
    except Exception as e:
        xbmc.log(f'[XStream Player] PVR OSD config failed: {e}', xbmc.LOGWARNING)


def _install_pvr_keymap():
    """Install PVR keymap for left/right navigation if enabled."""
    try:
        if addon.getSetting('pvr_osd_navigation') != 'true':
            return
        keymaps_dir = xbmcvfs.translatePath('special://profile/keymaps/')
        keymap_path = os.path.join(keymaps_dir, 'xstream_pvr.xml')
        if os.path.exists(keymap_path):
            return  # Already installed
        if not os.path.exists(keymaps_dir):
            os.makedirs(keymaps_dir)
        # Create keymap content - OSD panels opened with L/R, closed only with Back
        keymap_xml = '''<?xml version="1.0" encoding="UTF-8"?>
<keymap>
  <FullscreenLiveTV>
    <keyboard>
      <left>ActivateWindow(PVROSDChannels)</left>
      <right>ActivateWindow(PVROSDGuide)</right>
    </keyboard>
  </FullscreenLiveTV>
  <FullscreenRadio>
    <keyboard>
      <left>ActivateWindow(PVROSDChannels)</left>
      <right>ActivateWindow(PVROSDGuide)</right>
    </keyboard>
  </FullscreenRadio>
</keymap>
'''
        with open(keymap_path, 'w', encoding='utf-8') as f:
            f.write(keymap_xml)
        xbmc.log('[XStream Player] Installed PVR keymap', xbmc.LOGINFO)
    except Exception as e:
        xbmc.log(f'[XStream Player] PVR keymap install failed: {e}', xbmc.LOGWARNING)


def _bootstrap_pvr():
    profile = xbmcvfs.translatePath(addon.getAddonInfo('profile'))
    if not os.path.exists(profile):
        os.makedirs(profile)
    m3u_path = os.path.join(profile, 'pvr_live.m3u8')
    epg_path = os.path.join(profile, 'pvr_epg.xml')
    if not os.path.exists(m3u_path):
        with open(m3u_path, 'w', encoding='utf-8') as f:
            f.write('#EXTM3U\n')
    if not os.path.exists(epg_path):
        with open(epg_path, 'w', encoding='utf-8') as f:
            f.write('<?xml version="1.0" encoding="utf-8"?><tv></tv>\n')
    # Configure PVR Simple Client to point at our stub files. Always overwrite —
    # if instance-1 ever ended up pointing at the wrong file (e.g. the favorites
    # m3u from instance-2), the in-place repair must take effect.
    try:
        pvr_profile = xbmcvfs.translatePath('special://profile/addon_data/pvr.iptvsimple')
        settings_path = os.path.join(pvr_profile, 'instance-settings-1.xml')
        if not os.path.exists(pvr_profile):
            os.makedirs(pvr_profile)
        updates = {'m3uPathType': '0', 'm3uPath': m3u_path, 'epgPathType': '0', 'epgPath': epg_path}
        if os.path.exists(settings_path):
            tree = ET.parse(settings_path)
            root = tree.getroot()
            changed = False
            for key, val in updates.items():
                el = root.find(f".//setting[@id='{key}']")
                if el is not None:
                    if (el.text or '') != val:
                        el.text = val
                        if 'default' in el.attrib:
                            del el.attrib['default']
                        changed = True
                else:
                    new_el = ET.SubElement(root, 'setting', {'id': key})
                    new_el.text = val
                    changed = True
            if changed:
                tree.write(settings_path, encoding='utf-8', xml_declaration=True)
        else:
            root = ET.Element('settings', {'version': '2'})
            for key, val in updates.items():
                el = ET.SubElement(root, 'setting', {'id': key})
                el.text = val
            ET.ElementTree(root).write(settings_path, encoding='utf-8', xml_declaration=True)
    except Exception as e:
        xbmc.log(f'[XStream Player] _bootstrap_pvr instance-1 write failed: {e}', xbmc.LOGWARNING)
    _configure_kodi_pvr_osd()
    _install_pvr_keymap()


def _apply_buffer_fix():
    if addon.getSetting('buffer_fix_enabled') != 'true':
        return
    size_mb = int(addon.getSetting('buffer_size_mb') or '100')
    read_factor = int(addon.getSetting('buffer_read_factor') or '20')
    settings = {
        'filecache.buffermode': 1,
        'filecache.memorysize': size_mb,
        'filecache.readfactor': read_factor * 100,
    }
    for key, val in settings.items():
        xbmc.executeJSONRPC(json.dumps({
            'jsonrpc': '2.0', 'method': 'Settings.SetSettingValue',
            'params': {'setting': key, 'value': val}, 'id': 1
        }))
    try:
        pvr_profile = xbmcvfs.translatePath('special://profile/addon_data/pvr.iptvsimple')
        settings_path = os.path.join(pvr_profile, 'instance-settings-1.xml')
        if os.path.exists(settings_path):
            tree = ET.parse(settings_path)
            root = tree.getroot()
            pvr_updates = {'defaultInputstream': 'inputstream.ffmpegdirect', 'defaultMimeType': 'video/mp2t'}
            changed = False
            for key, val in pvr_updates.items():
                el = root.find(f".//setting[@id='{key}']")
                if el is not None:
                    if (el.text or '') != val:
                        el.text = val
                        if 'default' in el.attrib:
                            del el.attrib['default']
                        changed = True
                else:
                    new_el = ET.SubElement(root, 'setting', {'id': key})
                    new_el.text = val
                    changed = True
            if changed:
                tree.write(settings_path, encoding='utf-8', xml_declaration=True)
    except Exception as e:
        xbmc.log(f'[XStream Player] _apply_buffer_fix PVR write failed: {e}', xbmc.LOGWARNING)
    xbmc.log(f'[XStream Player] Buffer fix applied: {size_mb}MB, read factor {read_factor}x', xbmc.LOGINFO)


def _run_one_time_bootstrap():
    """Gated startup work. The hot path is plugin reinvocation for menu
    navigation, so we skip bootstrap whenever the relevant inputs are
    unchanged. Sidecar stores `addon_version|buffer_enabled|size_mb|read_factor`;
    a mismatch (new install, addon upgrade, or buffer setting change) re-runs."""
    try:
        addon_version = addon.getAddonInfo('version')
        buf_enabled = addon.getSetting('buffer_fix_enabled') or 'false'
        buf_size = addon.getSetting('buffer_size_mb') or '100'
        buf_read = addon.getSetting('buffer_read_factor') or '20'
        signature = f'{addon_version}|{buf_enabled}|{buf_size}|{buf_read}'

        profile = xbmcvfs.translatePath(addon.getAddonInfo('profile'))
        if not os.path.exists(profile):
            os.makedirs(profile)
        sidecar = os.path.join(profile, '.bootstrap_signature')
        prev = ''
        if os.path.exists(sidecar):
            try:
                with open(sidecar, 'r', encoding='utf-8') as f:
                    prev = f.read().strip()
            except Exception:
                prev = ''
        if prev == signature:
            return
        _bootstrap_pvr()
        _apply_buffer_fix()
        # Bootstrap PVR Favorites stub M3U for instance 2
        favs = os.path.join(profile, 'pvr_favorites.m3u8')
        if not os.path.exists(favs):
            with open(favs, 'w', encoding='utf-8') as f:
                f.write('#EXTM3U\n')
        try:
            with open(sidecar, 'w', encoding='utf-8') as f:
                f.write(signature)
        except Exception as e:
            xbmc.log(f'[XStream Player] bootstrap sidecar write failed: {e}', xbmc.LOGWARNING)
    except Exception as e:
        xbmc.log(f'[XStream Player] one-time bootstrap failed: {e}', xbmc.LOGERROR)


_run_one_time_bootstrap()


_LOG_REDACT_PATH_RE = re.compile(r'(/(?:live|movie|series)/)([^/?\s]+)(/?)([^/?\s]*)', re.IGNORECASE)
_LOG_REDACT_QUERY_RE = re.compile(r'(?i)\b(password|pwd|pass)=([^&\s]+)')
_LOG_MAX_LEN = 4000


def _log(msg):
    safe_msg = str(msg)
    # Redact /live/USER/PASS, /movie/USER/PASS, /series/USER/PASS path credentials
    safe_msg = _LOG_REDACT_PATH_RE.sub(lambda m: m.group(1) + '***REDACTED***' + m.group(3) + ('***REDACTED***' if m.group(4) else ''), safe_msg)
    # Redact password=, pwd=, pass= query params
    safe_msg = _LOG_REDACT_QUERY_RE.sub(r'\1=***REDACTED***', safe_msg)
    if len(safe_msg) > _LOG_MAX_LEN:
        safe_msg = safe_msg[:_LOG_MAX_LEN] + '...[truncated]'
    xbmc.log(f'[XStream Player] {safe_msg}', xbmc.LOGINFO)


def _restart_or_prompt():
    """Platform-aware restart. RestartApp is a no-op on Android (Shield, Fire TV);
    on those devices we instruct the user to fully close and reopen Kodi."""
    if xbmc.getCondVisibility('System.Platform.Android'):
        xbmcgui.Dialog().ok(
            'XStream Player',
            'Please fully close Kodi (swipe it away from recent apps) and reopen it.'
        )
    else:
        xbmc.executebuiltin('RestartApp')


def build_url(query):
    return base_url + '?' + urllib.parse.urlencode(query, doseq=True)


def _apply_sort():
    if addon.getSetting('default_sort_order') == 'A-Z':
        xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_LABEL)


def _get_credentials():
    return pm.get_credentials()


def _prefetch_vod_info_batch(streams, base_url, user, pwd):
    def _fetch_one(s):
        sid = str(s.get('stream_id', ''))
        if not sid:
            return
        cname = f'vod_info_{sid}'
        if _cache_load(cname) is not None:
            return
        try:
            info = IPTV.get_vod_info(base_url, user, pwd, sid)
            _cache_save(cname, info or {})
        except Exception:
            pass

    threads = []
    for s in streams:
        t = threading.Thread(target=_fetch_one, args=(s,))
        t.daemon = True
        threads.append(t)
        t.start()
    # Single 15s deadline for the whole batch — previously each join had its
    # own 15s timeout, so worst case was 15s × N threads.
    deadline = time.monotonic() + 15
    for t in threads:
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            break
        t.join(timeout=remaining)


def _enrich_movie_info(s, base_url=None, user=None, pwd=None):
    result = {
        'plot': s.get('plot') or s.get('description') or s.get('info', {}).get('plot') or '',
        'poster_url': s.get('stream_icon') or '',
        'rating': str(s.get('rating', '') or s.get('rating_5based', '') or ''),
        'year': '',
        'cast': [],
        'genre': ''
    }
    if s.get('stream_id'):
        sid = str(s.get('stream_id'))
        cname = f'vod_info_{sid}'
        info = _cache_load(cname)
        if info is not None:
            result['plot'] = info.get('info', {}).get('plot') or info.get('plot') or result['plot']
            result['poster_url'] = info.get('info', {}).get('movie_image') or info.get('stream_icon') or result['poster_url']
            result['year'] = str(info.get('info', {}).get('releasedate', '') or info.get('info', {}).get('release_date', '') or '')[:4]

    tmdb_enabled = addon.getSetting('tmdb_enabled').lower() == 'true'
    tmdb_key = addon.getSetting('tmdb_api_key') or ''
    if tmdb_enabled and tmdb_key:
        use_tmdb_plot = addon.getSetting('tmdb_plot').lower() == 'true'
        use_tmdb_posters = addon.getSetting('tmdb_posters').lower() == 'true'
        use_tmdb_ratings = addon.getSetting('tmdb_ratings').lower() == 'true'
        use_tmdb_cast = addon.getSetting('tmdb_cast').lower() == 'true'
        # Fetch TMDB if ANY feature is enabled
        if use_tmdb_plot or use_tmdb_posters or use_tmdb_ratings or use_tmdb_cast:
            clean_title = s.get('name', '')
            # Sanitize title for use as filename (remove Windows invalid chars)
            safe_title = re.sub(r'[<>:"/\\|?*]', '', clean_title)
            cname = f"tmdb_search_{safe_title.lower().replace(' ', '_')}"
            tmdb_data = _cache_load(cname)
            cache_needs_refresh = tmdb_data is None or not _cache_valid(cname, hours=720)
            # Also refresh if cast/genre is enabled but missing from cache
            if not cache_needs_refresh and use_tmdb_cast and not tmdb_data.get('cast'):
                cache_needs_refresh = True
            if not cache_needs_refresh and not tmdb_data.get('genre'):
                cache_needs_refresh = True
            if cache_needs_refresh:
                tmdb = TMDB(tmdb_key)
                tmdb_data = tmdb.enrich(clean_title)
                _cache_save(cname, tmdb_data)
            # Use TMDB data based on individual settings (overwrite provider)
            if use_tmdb_posters and tmdb_data.get('poster_url'):
                result['poster_url'] = tmdb_data['poster_url']
            if use_tmdb_plot and tmdb_data.get('plot'):
                result['plot'] = tmdb_data['plot']
            if use_tmdb_ratings and tmdb_data.get('rating'):
                result['rating'] = tmdb_data['rating']
                result['year'] = tmdb_data.get('year', '')
            if use_tmdb_cast and tmdb_data.get('cast'):
                result['cast'] = tmdb_data['cast']
            # Always get genre if available
            if tmdb_data.get('genre'):
                result['genre'] = tmdb_data['genre']
    return result


def _enrich_series_info(s, base_url=None, user=None, pwd=None):
    result = {'plot': s.get('plot', ''), 'poster_url': s.get('cover', ''), 'rating': '', 'year': '', 'cast': [], 'genre': ''}
    tmdb_enabled = addon.getSetting('tmdb_enabled').lower() == 'true'
    tmdb_key = addon.getSetting('tmdb_api_key') or ''
    if tmdb_enabled and tmdb_key:
        use_tmdb_plot = addon.getSetting('tmdb_plot').lower() == 'true'
        use_tmdb_posters = addon.getSetting('tmdb_posters').lower() == 'true'
        use_tmdb_ratings = addon.getSetting('tmdb_ratings').lower() == 'true'
        use_tmdb_cast = addon.getSetting('tmdb_cast').lower() == 'true'
        # Fetch TMDB if ANY feature is enabled
        if use_tmdb_plot or use_tmdb_posters or use_tmdb_ratings or use_tmdb_cast:
            clean_title = s.get('name', '')
            safe_title = re.sub(r'[<>:"/\\|?*]', '', clean_title)
            cname = f"tmdb_tv_search_{safe_title.lower().replace(' ', '_')}"
            tmdb_data = _cache_load(cname)
            cache_needs_refresh = tmdb_data is None or not _cache_valid(cname, hours=720)
            # Also refresh if cast is enabled but missing from cache
            if not cache_needs_refresh and use_tmdb_cast and not tmdb_data.get('cast'):
                cache_needs_refresh = True
            if not cache_needs_refresh and not tmdb_data.get('genre'):
                cache_needs_refresh = True
            if cache_needs_refresh:
                tmdb = TMDB(tmdb_key)
                tmdb_data = tmdb.enrich_tv(clean_title)
                _cache_save(cname, tmdb_data)
            # Use TMDB data based on individual settings (overwrite provider)
            if use_tmdb_posters and tmdb_data.get('poster_url'):
                result['poster_url'] = tmdb_data['poster_url']
            if use_tmdb_plot and tmdb_data.get('plot'):
                result['plot'] = tmdb_data['plot']
            if use_tmdb_ratings and tmdb_data.get('rating'):
                result['rating'] = tmdb_data['rating']
                result['year'] = tmdb_data.get('year', '')
            if use_tmdb_cast and tmdb_data.get('cast'):
                result['cast'] = tmdb_data['cast']
            # Always get genre if available
            if tmdb_data.get('genre'):
                result['genre'] = tmdb_data['genre']
    return result


def _cache_path(name):
    profile = xbmcvfs.translatePath(addon.getAddonInfo('profile'))
    # Sanitize name to prevent path traversal - only allow alphanumeric, hyphen, underscore
    safe_name = re.sub(r'[^a-zA-Z0-9_-]', '', str(name))
    return os.path.join(profile, f'data_cache_p{pm.active}_{safe_name}.json')


def _cache_load(name):
    try:
        with open(_cache_path(name), 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return None


def _cache_save(name, data):
    profile = xbmcvfs.translatePath(addon.getAddonInfo('profile'))
    if not os.path.exists(profile):
        os.makedirs(profile)
    cache_file = _cache_path(name)
    tmp_file = cache_file + '.tmp'
    with open(tmp_file, 'w', encoding='utf-8') as f:
        json.dump(data, f)
        # Durability: atomic rename is not enough on Android — without fsync
        # the rename can land before the data, leaving a zero-byte cache file
        # after a crash / power loss.
        try:
            f.flush()
            os.fsync(f.fileno())
        except OSError:
            pass
    os.replace(tmp_file, cache_file)


def _cache_valid(name, hours=None):
    if hours is None:
        try:
            hours = float(addon.getSetting('auto_refresh_interval') or '24')
        except ValueError:
            hours = 24
    path = _cache_path(name)
    if not os.path.exists(path):
        return False
    age = time.time() - os.path.getmtime(path)
    return age < (hours * 3600)


def _cache_clear_all():
    """Clear cache for active profile."""
    return _cache_clear_profile(pm.active)


def _cache_clear_profile(pnum):
    """Clear cache for a specific profile number."""
    profile = xbmcvfs.translatePath(addon.getAddonInfo('profile'))
    prefix = f'data_cache_p{pnum}_'
    count = 0
    try:
        for fname in os.listdir(profile):
            if fname.startswith(prefix) or fname.startswith('epg_cache_profile_') or fname.startswith('vod_info_') or fname.startswith('tmdb_'):
                os.remove(os.path.join(profile, fname))
                count += 1
    except Exception as e:
        _log(f'Cache clear error: {e}')
    return count


def _cache_clear_all_profiles():
    """Clear cache for all profiles."""
    profile = xbmcvfs.translatePath(addon.getAddonInfo('profile'))
    count = 0
    try:
        for fname in os.listdir(profile):
            if fname.startswith('data_cache_') or fname.startswith('epg_cache_profile_') or fname.startswith('vod_info_') or fname.startswith('tmdb_'):
                os.remove(os.path.join(profile, fname))
                count += 1
    except Exception as e:
        _log(f'Cache clear error: {e}')
    return count


def _get_cached_m3u_channels(m3u_url):
    if not m3u_url:
        return []
    if _cache_valid('m3u'):
        return _cache_load('m3u') or []
    data = IPTV.get_m3u_channels(m3u_url)
    _cache_save('m3u', data)
    return data


def _get_cached_xtream_categories(url, user, pwd, stype):
    if not url or not user or not pwd:
        return []
    key = f'xtream_cats_{stype}'
    if _cache_valid(key):
        return _cache_load(key) or []
    data = IPTV.get_xtream_categories(url, user, pwd, stype)
    _cache_save(key, data)
    return data


def _get_cached_xtream_streams(url, user, pwd, stype, category_id=None):
    if not url or not user or not pwd:
        return []
    key = f'xtream_streams_{stype}'
    if _cache_valid(key):
        data = _cache_load(key) or []
    else:
        data = IPTV.get_xtream_streams(url, user, pwd, stype, None)
        _cache_save(key, data)
    if category_id:
        return [s for s in data if str(s.get('category_id', '')) == str(category_id)]
    return data


def _pvr_m3u_path():
    profile = xbmcvfs.translatePath(addon.getAddonInfo('profile'))
    return os.path.join(profile, 'pvr_live.m3u8')


def _pvr_epg_path():
    profile = xbmcvfs.translatePath(addon.getAddonInfo('profile'))
    return os.path.join(profile, 'pvr_epg.xml')


def _export_pvr_m3u():
    _log('PVR: Starting M3U export')
    creds = _get_credentials()
    m3u_url = creds.get('m3u_url', '')
    xt_url = creds.get('xtream_url', '')
    xt_user = creds.get('xtream_username', '')
    xt_pwd = creds.get('xtream_password', '')
    _log(f'PVR: m3u_url={bool(m3u_url)}, xt_url={bool(xt_url)}')

    channels = []
    total_streams = 0
    skipped = 0
    
    # Load hidden categories and items early so they're available for both M3U and Xtream
    hidden_live = _get_hidden_subcats('live')
    hidden_live_items = _get_hidden_items('live')
    hide_adult = addon.getSetting('hide_adult_categories').lower() == 'true'
    
    if m3u_url:
        for ch in _get_cached_m3u_channels(m3u_url):
            group = ch.get('group', 'General')
            # Skip channels from hidden groups
            if group in hidden_live:
                continue
            if hide_adult and (_is_adult_category(group) or _is_adult_category(ch.get('name', ''))):
                continue
            channels.append({
                'name': ch.get('name', 'Unknown'),
                'url': ch.get('url', ''),
                'tvg_id': ch.get('tvg_id', ''),
                'logo': ch.get('logo', ''),
                'group': group,
                'catchup': ch.get('catchup', ''),
                'catchup_source': ch.get('catchup_source', ''),
                'catchup_days': ch.get('catchup_days', '')
            })
    if xt_url and xt_user and xt_pwd:
        # Build category ID → name lookup
        cats = _cache_load('xtream_cats_live') or IPTV.get_xtream_categories(xt_url, xt_user, xt_pwd, 'live')
        cat_map = {}
        for c in (cats or []):
            cat_map[str(c.get('category_id', ''))] = c.get('category_name', 'Live TV')

        _log(f'PVR M3U export: {len(hidden_live)} hidden categories: {hidden_live}, {len(hidden_live_items)} hidden items')
        streams = _get_cached_xtream_streams(xt_url, xt_user, xt_pwd, 'live')
        total_streams = len(streams)
        skipped = 0
        for s in streams:
            cat_id = str(s.get('category_id', ''))
            if cat_id in hidden_live:
                skipped += 1
                continue
            if str(s.get('stream_id', '')) in hidden_live_items:
                skipped += 1
                continue
            group = cat_map.get(cat_id, 'Live TV')
            if hide_adult and (_is_adult_category(group) or _is_adult_category(s.get('name', ''))):
                skipped += 1
                continue
            sid = str(s.get('stream_id', ''))
            epg_id = s.get('epg_channel_id') or sid
            url = IPTV.build_xtream_stream_url(xt_url, xt_user, xt_pwd, s, 'live')
            channels.append({
                'name': s.get('name', 'Unknown'),
                'url': url,
                'tvg_id': epg_id,
                'logo': s.get('stream_icon', ''),
                'group': group,
                'catchup': 'default' if s.get('tv_archive') or s.get('catchup') else '',
                'catchup_source': f'{xt_url}/live/{xt_user}/{xt_pwd}/{sid}.ts?utc={{utc}}&lutc={{lutc}}' if (s.get('tv_archive') or s.get('catchup')) else '',
                'catchup_days': str(s.get('tv_archive_duration', '') or '7') if (s.get('tv_archive') or s.get('catchup')) else ''
            })

    _log(f'PVR M3U export: {total_streams} total streams, {skipped} skipped, {len(channels)} exported')

    if not channels:
        return False
    m3u_path = _pvr_m3u_path()
    m3u_data = build_m3u_content(channels)
    with open(m3u_path, 'w', encoding='utf-8') as f:
        f.write(m3u_data)
    # Quick validation: every EXTINF must contain a comma
    bad_lines = [ln for ln in m3u_data.splitlines() if ln.startswith('#EXTINF:') and ',' not in ln]
    if bad_lines:
        _log(f'M3U validation failed on {len(bad_lines)} lines')
        return False
    _log(f'Exported PVR M3U with {len(channels)} channels')
    return True


def _export_pvr_epg():
    epg_path = _pvr_epg_path()
    try:
        epg = EPG(addon)
        epg.load()
        if epg.programs and epg.export_xmltv(epg_path):
            _log(f'Exported real EPG for PVR ({len(epg.programs)} channels)')
            return True
        # Fallback stub if no data available
        stub = '<?xml version="1.0" encoding="utf-8"?><tv></tv>'
        with open(epg_path, 'w', encoding='utf-8') as f:
            f.write(stub)
        _log('Exported stub EPG for PVR (no EPG data available)')
        return True
    except Exception as e:
        _log(f'EPG export failed: {e}')
        return False


def _configure_pvr_iptvsimple():
    try:
        pvr_profile = xbmcvfs.translatePath('special://profile/addon_data/pvr.iptvsimple')
        if not os.path.exists(pvr_profile):
            os.makedirs(pvr_profile)
        settings_path = os.path.join(pvr_profile, 'instance-settings-1.xml')
        m3u_path = _pvr_m3u_path()
        epg_path = _pvr_epg_path()
        root = ET.Element('settings', {'version': '2'})
        catchup_enabled = addon.getSetting('pvr_catchup_enabled').lower() == 'true'
        catchup_days = addon.getSetting('pvr_catchup_days') or '7'
        defs = [
            ('m3uPathType', '0'),
            ('m3uPath', m3u_path),
            ('m3uUrl', ''),
            ('epgPathType', '0'),
            ('epgPath', epg_path),
            ('epgUrl', ''),
            ('m3uRefreshMode', '1'),
            ('logoPathType', '0'),
            ('logoPath', ''),
            ('logoBaseUrl', ''),
            ('catchupEnabled', 'true' if catchup_enabled else 'false'),
            ('catchupPlayEpgAsLive', 'false'),
            ('allChannelsCatchupMode', '0'),
            ('catchupOverrideMode', '0'),
            ('catchupDays', catchup_days),
            ('catchupOnlyOnFinishedProgrammes', 'false'),
            ('catchupWatchEpgBeginBufferMins', '5'),
            ('catchupWatchEpgEndBufferMins', '15'),
        ]
        for key, val in defs:
            el = ET.SubElement(root, 'setting', {'id': key})
            el.text = val
        tree = ET.ElementTree(root)
        tree.write(settings_path, encoding='utf-8', xml_declaration=True)
        _log('Configured PVR IPTV Simple Client')

        xbmcgui.Dialog().notification(
            'XStream Player',
            _t(30099),
            xbmcgui.NOTIFICATION_INFO,
            5000
        )
        return True
    except Exception as e:
        _log(f'Configure PVR failed: {e}')
        return False




def is_pvr_iptvsimple_installed():
    try:
        addon = xbmcaddon.Addon('pvr.iptvsimple')
        _log(f'PVR: IPTV Simple found, version={addon.getAddonInfo("version")}')
        return True
    except Exception as e:
        _log(f'PVR: IPTV Simple not installed: {e}')
        return False




def prompt_install_pvr():
    dlg = xbmcgui.Dialog()
    choice = dlg.yesno(
        _t(30560),
        _t(30561),
        yeslabel=_t(30182),
        nolabel=_t(30161)
    )
    if choice:
        xbmc.executebuiltin('InstallAddon(pvr.iptvsimple)')
        # Wait for installation and notify
        for _ in range(30):
            xbmc.sleep(1000)
            if is_pvr_iptvsimple_installed():
                xbmcgui.Dialog().notification('XStream Player', _t(30100), xbmcgui.NOTIFICATION_INFO, 5000)
                return True
    return choice


def _sync_pvr():
    if addon.getSetting('auto_sync_pvr').lower() != 'true':
        return False
    return _sync_pvr_force()


def _sync_pvr_force():
    """Sync PVR with EPG cache clear to prevent stale data."""
    _log('PVR: Starting sync with cache clear')
    if not is_pvr_iptvsimple_installed():
        _log('PVR: IPTV Simple not installed, prompting')
        prompt_install_pvr()
        return False
    
    try:
        xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "PVR.Manager.Stop", "id": 1}')
        _log('PVR: Manager stopped')
        xbmc.sleep(1000)
    except Exception as e:
        _log(f'PVR: Manager stop warning: {e}')
    
    # PVR Manager is already stopped above; the helper handles addon
    # disable/enable + WAL/SHM siblings + truncate fallback for Android.
    _hard_reset_pvr_epg_cache(stop_manager=False, start_manager=False)
    
    _log('PVR: Exporting M3U')
    if not _export_pvr_m3u():
        _log('PVR: M3U export failed')
        return False
    _log('PVR: Exporting EPG')
    _export_pvr_epg()
    
    _log('PVR: Configuring IPTV Simple')
    ok = _configure_pvr_iptvsimple()
    _log(f'PVR: Configuration result={ok}')
    
    try:
        xbmc.sleep(500)
        xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "PVR.Manager.Start", "id": 1}')
        _log('PVR: Manager started with fresh EPG')
    except Exception as e:
        _log(f'PVR: Manager start warning: {e}')
    
    if ok:
        _maybe_show_pvr_first_run()
    
    _sync_pvr_favorites()
    
    return ok


def _hard_reset_pvr_epg_cache(stop_manager=True, start_manager=True):
    """Wipe Kodi's PVR EPG database (Epg16.db) in a way that actually works on Android.

    On Android, PVR.Manager.Stop alone does not release the SQLite handle that
    pvr.iptvsimple holds on Epg16.db, so plain os.remove silently fails or
    leaves a ghost inode. We must disable the binary addon to force the
    handle to close. WAL mode also leaves -wal/-shm siblings that get replayed
    on next open, so we must remove those too. As a last-resort fallback for
    devices where unlink is refused but in-place writes are allowed, we
    truncate the file to zero bytes which forces Kodi to recreate the schema.
    """
    db_dir = xbmcvfs.translatePath('special://userdata/Database/')
    db_files = ('Epg16.db', 'Epg16.db-wal', 'Epg16.db-shm', 'Epg16.db-journal')

    try:
        if stop_manager:
            try:
                xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "PVR.Manager.Stop", "id": 1}')
                _log('PVR: Manager stopped (hard reset)')
                xbmc.sleep(1000)
            except Exception as e:
                _log(f'PVR: Manager stop warning: {e}')

        # Disable pvr.iptvsimple to release SQLite handles on Epg16.db.
        try:
            xbmc.executeJSONRPC(json.dumps({
                'jsonrpc': '2.0', 'id': 1,
                'method': 'Addons.SetAddonEnabled',
                'params': {'addonid': 'pvr.iptvsimple', 'enabled': False},
            }))
            _log('PVR: pvr.iptvsimple disabled')
            xbmc.sleep(1500)
        except Exception as e:
            _log(f'PVR: disable iptvsimple warning: {e}')

        # Wipe Epg16.db and its WAL/SHM/journal siblings.
        for name in db_files:
            p = os.path.join(db_dir, name)
            if not os.path.exists(p):
                continue
            removed = False
            try:
                os.remove(p)
                removed = True
                _log(f'PVR: removed {name}')
            except OSError as e:
                _log(f'PVR: unlink {name} refused ({e}); trying truncate fallback')
                try:
                    open(p, 'wb').close()
                    removed = True
                    _log(f'PVR: truncated {name}')
                except Exception as e2:
                    _log(f'PVR: could not clear {name}: {e2}')
            if not removed:
                _log(f'PVR: WARNING {name} still present')

        # Re-enable pvr.iptvsimple.
        try:
            xbmc.executeJSONRPC(json.dumps({
                'jsonrpc': '2.0', 'id': 1,
                'method': 'Addons.SetAddonEnabled',
                'params': {'addonid': 'pvr.iptvsimple', 'enabled': True},
            }))
            _log('PVR: pvr.iptvsimple re-enabled')
            xbmc.sleep(1000)
        except Exception as e:
            _log(f'PVR: re-enable iptvsimple warning: {e}')

        if start_manager:
            try:
                xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "PVR.Manager.Start", "id": 1}')
                _log('PVR: Manager started (hard reset)')
                xbmc.sleep(1000)
                # Backup nudge: explicitly request EPG load.
                xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "PVR.EPGLoad", "id": 1}')
                _log('PVR: EPG reload triggered')
            except Exception as e:
                _log(f'PVR: Manager start warning: {e}')
    except Exception as e:
        _log(f'PVR: hard reset failed: {e}')


def reset_pvr_epg_db_action():
    """User-facing action: hard-reset Kodi's PVR EPG database with progress UI."""
    dialog = xbmcgui.Dialog()
    pd = xbmcgui.DialogProgress()
    pd.create('XStream Player', _t(30704))
    try:
        _hard_reset_pvr_epg_cache()
    finally:
        pd.close()
    dialog.notification('XStream Player', _t(30705))


def _reload_pvr_epg():
    """Trigger PVR EPG reload by clearing cache and restarting PVR Manager."""
    _hard_reset_pvr_epg_cache()


def _maybe_show_pvr_first_run():
    flag = os.path.join(xbmcvfs.translatePath(addon.getAddonInfo('profile')), 'pvr_first_run_shown')
    if os.path.exists(flag):
        return
    try:
        with open(flag, 'w', encoding='utf-8') as f:
            f.write('1')
        xbmcgui.Dialog().ok('XStream Player', _t(30057) + '\n' + _t(30058))
    except Exception:
        pass


def _prefetch_all_data():
    creds = _get_credentials()
    xt_url = creds.get('xtream_url', '')
    xt_user = creds.get('xtream_username', '')
    xt_pwd = creds.get('xtream_password', '')
    m3u_url = creds.get('m3u_url', '')

    pd = xbmcgui.DialogProgress()
    pd.create('XStream Player', _t(30284))

    fast_steps = []
    load_live = False
    if m3u_url:
        fast_steps.append((_t(30350), lambda: _cache_save('m3u', IPTV.get_m3u_channels(m3u_url))))
    if xt_url and xt_user and xt_pwd:
        load_live = pm.get_profile_setting('load_live') != 'false'
        load_movies = pm.get_profile_setting('load_movies') != 'false'
        load_series = pm.get_profile_setting('load_series') != 'false'
        if load_live:
            fast_steps.extend([
                (_t(30351), lambda: _cache_save('xtream_cats_live', IPTV.get_xtream_categories(xt_url, xt_user, xt_pwd, 'live'))),
                (_t(30352), lambda: _cache_save('xtream_streams_live', IPTV.get_xtream_streams(xt_url, xt_user, xt_pwd, 'live'))),
            ])
        if load_movies:
            fast_steps.extend([
                (_t(30353), lambda: _cache_save('xtream_cats_movie', IPTV.get_xtream_categories(xt_url, xt_user, xt_pwd, 'movie'))),
                (_t(30354), lambda: _cache_save('xtream_streams_movie', IPTV.get_xtream_streams(xt_url, xt_user, xt_pwd, 'movie'))),
            ])
        if load_series:
            fast_steps.extend([
                (_t(30355), lambda: _cache_save('xtream_cats_series', IPTV.get_xtream_categories(xt_url, xt_user, xt_pwd, 'series'))),
                (_t(30356), lambda: _cache_save('xtream_streams_series', IPTV.get_xtream_streams(xt_url, xt_user, xt_pwd, 'series'))),
            ])

    slow_steps = []
    if load_live:
        slow_steps.append((_t(30357), lambda: EPG(addon).fetch()))
        if addon.getSetting('auto_sync_pvr').lower() == 'true':
            slow_steps.append((_t(30358), _sync_pvr))

    all_steps = fast_steps + slow_steps
    total = len(all_steps)

    for idx, (label, fn) in enumerate(all_steps):
        percent = int((idx / total) * 100) if total else 0
        pd.update(percent, _t(30359, label))
        try:
            fn()
        except Exception as e:
            _log(f'Prefetch error {label}: {e}')

    pd.close()
    xbmcgui.Dialog().notification('XStream Player', _t(30080))



def _live_url(url):
    opts = 'reconnect=1&reconnect_streamed=1&reconnect_at_eof=1&reconnect_delay_max=5&analyzeduration=8000000&probesize=10485760'
    if not url or opts in url:
        return url
    if '|' in url:
        return url + '&' + opts
    return url + '|' + opts


def _set_live_props(li):
    li.setMimeType('video/mp2t')
    li.setContentLookup(False)


def play_stream(play_url, name, title='', plot='', icon='', stype='live',
                series_id='', season_num='', ep_id=''):
    if stype == 'live':
        play_url = _live_url(play_url)
    li = xbmcgui.ListItem(path=play_url)
    li.setProperty('IsPlayable', 'true')
    info_tag = li.getVideoInfoTag()
    info_tag.setMediaType('video')
    info_tag.setTitle(title or name)
    info_tag.setPlot(plot or '')
    if icon:
        li.setArt({'icon': icon, 'thumb': icon})
    _prepare_playback_item(li)
    if stype == 'live':
        _set_live_props(li)
    # Resume point for non-live content (Kodi handles resume popup)
    resume_pos = resume_db.get_position(name, play_url) if stype in ('movie', 'series', 'episode') else 0
    if resume_pos > 0:
        li.setProperty('ResumeTime', str(resume_pos))
        li.setProperty('TotalTime', str(int(resume_pos * 1.1)))
    xbmcplugin.setResolvedUrl(addon_handle, True, listitem=li)
    # Store series metadata in history for proper playback from Recently Watched
    extra = None
    if stype == 'series' and series_id and season_num and ep_id:
        extra = {'series_id': series_id, 'season_num': season_num, 'ep_id': ep_id}
    watch_history.add(name, play_url, icon=icon, stype=stype, extra=extra)
    # Mark series episode as watched
    if stype == 'series' and series_id and season_num and ep_id:
        watched_db.mark_watched(series_id, season_num, ep_id)
    # Monitor playback for resume saving and error recovery
    _monitor_playback(name, play_url, stype)


def _monitor_playback(name, url, stype='live'):
    """Background thread to save resume position and detect stream failures."""
    def _worker():
        player = xbmc.Player()
        xbmc.sleep(3000)  # wait for playback to stabilize
        if not player.isPlaying():
            # Only show error for movies/series, not live TV (user can stop anytime)
            if stype not in ('live', 'movie', 'series'):
                _log(f'Playback failed to start for: {name}')
                retry = xbmcgui.Dialog().yesno(_t(30031),
                    _t(30053).format(name), yeslabel=_t(30166), nolabel=_t(30161))
                if retry:
                    li = xbmcgui.ListItem(path=url)
                    li.setProperty('IsPlayable', 'true')
                    _prepare_playback_item(li)
                    _set_live_props(li)
                    player.play(url, li)
            return
        while player.isPlaying():
            try:
                pos = player.getTime()
                dur = player.getTotalTime()
                if dur > 0:
                    resume_db.save_position(name, url, pos, dur)
            except Exception:
                pass
            xbmc.sleep(5000)
    t = threading.Thread(target=_worker)
    t.daemon = True
    t.start()


def _prepare_playback_item(li):
    if addon.getSetting('use_inputstream_adaptive').lower() == 'true':
        li.setProperty('inputstream', 'inputstream.adaptive')
        li.setProperty('inputstream.adaptive.manifest_type', 'hls')
    custom_ua = addon.getSetting('custom_user_agent')
    if custom_ua:
        li.setProperty('http-header', f'User-Agent={urllib.parse.quote(custom_ua)}')


def _pvr_fav_ctx(stream_id, name, icon=''):
    sid = str(stream_id)
    if _pvr_favs_is_fav(sid):
        return (_t(30217),
                f'RunPlugin({build_url({"mode": "pvr_fav_remove", "stream_id": sid})})')
    else:
        return (_t(30218),
                f'RunPlugin({build_url({"mode": "pvr_fav_add", "stream_id": sid, "name": name, "icon": icon})})')


def _build_fav_ctx(item_id, name, stype, icon, url, epg_id=''):
    stype_labels = {'live': _t(30360), 'movie': _t(30361), 'series': _t(30362)}
    label = stype_labels.get(stype, stype)
    ctx = []
    if fav.is_favorite(item_id):
        ctx.append((_t(30213).format(label),
            f'RunPlugin({build_url({"mode": "toggle_fav", "id": item_id, "name": name, "stype": stype, "icon": icon, "url": url, "epg_id": epg_id})})'))
    else:
        ctx.append((_t(30214).format(label),
            f'RunPlugin({build_url({"mode": "toggle_fav", "id": item_id, "name": name, "stype": stype, "icon": icon, "url": url, "epg_id": epg_id})})'))
    # Add entry for each custom group
    for gname in fav.get_folders():
        if gname == 'Favorites':
            continue
        ctx.append((_t(30219, gname),
            f'RunPlugin({build_url({"mode": "toggle_fav", "id": item_id, "name": name, "stype": stype, "icon": icon, "url": url, "epg_id": epg_id, "folder": gname})})'))
    return ctx


def _is_adult_category(name):
    # Adult keywords with word boundaries to reduce false positives
    adult_patterns = [
        r'\bxxx\b', r'\badult\b', r'\bmature\b', r'\bporn\b',
        r'\berotic\b', r'\berotica\b', r'\bnsfw\b', r'\bx-rated\b',
        r'\bxrated\b', r'\bplayboy\b', r'\bhustler\b', r'\bpenthouse\b',
        r'\bbrazzers\b', r'\bnaughty\b', r'\bsexy\b', r'\bsex\b',
        r'\bhentai\b', r'\bstriptease\b', r'\bfetish\b', r'\bnude\b',
        r'\bnaked\b', r'\borgasm\b', r'\bkamasutra\b', r'\bmilf\b',
        r'\blesbian\b', r'\bgay\b', r'\bhardcore\b', r'\bsoftcore\b',
        r'\btopless\b', r'\buncensored\b', r'\buncut\b', r'\bvoyeur\b',
        r'\bswinger\b', r'\bredlight\b', r'\bred light\b',
        r'\bblue film\b', r'\bhot club\b', r'\bnight show\b',
        r'\bfor adults\b', r'\b18\+', r'\(\s*18\+\s*\)', r'\[\s*18\+\s*\]',
    ]
    lower = name.lower()
    return any(re.search(p, lower) for p in adult_patterns)


def _hash_pin(pin):
    """Hash PIN with SHA-256 and addon-id salt for secure storage."""
    import hashlib
    salt = addon.getAddonInfo('id') or 'plugin.video.xstream-player'
    return hashlib.sha256((pin + salt).encode('utf-8')).hexdigest()


def _check_pin(required_for=''):
    if addon.getSetting('enable_parental_control').lower() != 'true':
        return True
    # Check per-area toggles
    area_map = {
        'Settings': 'parental_lock_settings',
        'Tools': 'parental_lock_tools',
    }
    setting_key = area_map.get(required_for)
    if setting_key and addon.getSetting(setting_key).lower() != 'true':
        return True
    stored_pin = addon.getSetting('parental_pin') or '0000'
    kb = xbmcgui.Dialog().input(_t(30032).format(required_for), type=xbmcgui.INPUT_NUMERIC)
    # Migration: if stored PIN is plaintext (4 digits), hash the input and compare
    # If already hashed (64 hex chars), hash input and compare hashes
    if len(stored_pin) == 4 and stored_pin.isdigit():
        # Plaintext legacy PIN - compare directly, then migrate to hashed
        if kb != stored_pin:
            xbmcgui.Dialog().notification('XStream Player', _t(30061))
            return False
        # Migrate to hashed storage
        addon.setSetting('parental_pin', _hash_pin(stored_pin))
        return True
    else:
        # Hashed PIN - compare hashes
        if _hash_pin(kb) != stored_pin:
            xbmcgui.Dialog().notification('XStream Player', _t(30061))
            return False
        return True


def _check_auto_refresh():
    creds = _get_credentials()
    if not creds.get('xtream_url') and not creds.get('m3u_url'):
        return
    # Don't auto-refresh on first credentials entry (let user manually refresh)
    flag_file = os.path.join(xbmcvfs.translatePath(addon.getAddonInfo('profile')), 'credentials_saved')
    if not os.path.exists(flag_file):
        return  # First run, user will manually refresh via prompt
    rt = RefreshTracker(addon)
    if rt.should_refresh():
        _log('Auto-refresh triggered')
        refresh_data()


def _check_credentials_refresh_prompt():
    creds = _get_credentials()
    has_creds = bool(creds.get('xtream_url') or creds.get('m3u_url'))
    
    flag_file = os.path.join(xbmcvfs.translatePath(addon.getAddonInfo('profile')), 'credentials_saved')
    
    if has_creds and not os.path.exists(flag_file):
        # First time credentials entered - show refresh prompt
        profile_name = creds.get('name', _t(30390, pm.active))
        choice = xbmcgui.Dialog().yesno(
            'XStream Player',
            _t(30062).format(profile_name) + '\n\n' + _t(30063)
        )
        if choice:
            refresh_data()  # This will show "Relaunch Kodi" after
        
        # Create flag so we don't prompt again
        with open(flag_file, 'w') as f:
            f.write('1')
        return True
    return False


def _is_first_refresh():
    profile = xbmcvfs.translatePath(addon.getAddonInfo('profile'))
    return not os.path.exists(os.path.join(profile, 'first_refresh_done'))

def _mark_first_refresh_done():
    profile = xbmcvfs.translatePath(addon.getAddonInfo('profile'))
    with open(os.path.join(profile, 'first_refresh_done'), 'w') as f:
        f.write('1')

def refresh_data():
    # Confirmation prompt with warning
    choice = xbmcgui.Dialog().yesno(
        'XStream Player',
        _t(30050) + '\n\n' + _t(30051),
        yeslabel=_t(30167),
        nolabel=_t(30161)
    )
    if not choice:
        return False
    
    first_time = _is_first_refresh()
    clear_cache = addon.getSetting('clear_cache_on_refresh').lower() == 'true'
    pd = xbmcgui.DialogProgress()
    pd.create('XStream Player', _t(30285) if clear_cache else _t(30286))
    count = _cache_clear_all()
    if clear_cache:
        profile_path = xbmcvfs.translatePath(addon.getAddonInfo('profile'))
        for fname in os.listdir(profile_path):
            if (fname.startswith('epg_cache_profile_') or fname == 'epg_cache.json'
                    or fname == 'view_prefs.json' or fname.startswith('data_cache_epg')
                    or fname.startswith('data_cache_tmdb_') or fname.startswith('tmdb_')):
                try:
                    os.remove(os.path.join(profile_path, fname))
                    count += 1
                except Exception:
                    pass
        _log(f'Cleared {count} cache files (all caches)')
    else:
        _log(f'Cleared {count} data cache files')
    rt = RefreshTracker(addon)
    rt.set_last_refresh()
    pd.update(30, _t(30562))
    _prefetch_all_data()
    pd.update(100, _t(30563))
    pd.close()
    if first_time:
        _mark_first_refresh_done()
    choice = xbmcgui.Dialog().yesno(
        'XStream Player',
        _t(30052),
        yeslabel=_t(30165),
        nolabel=_t(30164))
    if choice:
        _restart_or_prompt()
        return
    xbmc.executebuiltin('Container.Refresh')


def sync_pvr():
    if not is_pvr_iptvsimple_installed():
        prompt_install_pvr()
        return
    pd = xbmcgui.DialogProgress()
    pd.create('XStream Player', _t(30287))
    ok = False
    try:
        ok = _sync_pvr()
    except Exception as e:
        _log(f'PVR sync error: {e}')
    pd.close()
    if ok:
        xbmcgui.Dialog().notification('XStream Player', _t(30081))
    else:
        xbmcgui.Dialog().notification('XStream Player', _t(30082))


def open_pvr():
    xbmcplugin.endOfDirectory(addon_handle, succeeded=False)
    xbmc.executebuiltin('ActivateWindow(TVChannels)')


def open_pvr_guide():
    xbmcplugin.endOfDirectory(addon_handle, succeeded=False)
    xbmc.executebuiltin('ActivateWindow(TVGuide)')


def _pvr_favs_path():
    profile = xbmcvfs.translatePath(addon.getAddonInfo('profile'))
    return os.path.join(profile, f'pvr_favorites_{pm.active}.json')


def _pvr_favs_load_all():
    """Load all PVR favorite groups. Returns dict of {group_name: [channels]}."""
    try:
        with open(_pvr_favs_path(), 'r', encoding='utf-8') as f:
            data = json.load(f)
    except Exception:
        return {}
    # Migration: old format was a flat list
    if isinstance(data, list):
        if data:
            return {'Favorites': data}
        return {}
    return data


def _pvr_favs_save_all(groups):
    profile = xbmcvfs.translatePath(addon.getAddonInfo('profile'))
    if not os.path.exists(profile):
        os.makedirs(profile)
    favs_path = _pvr_favs_path()
    tmp_file = favs_path + '.tmp'
    with open(tmp_file, 'w', encoding='utf-8') as f:
        json.dump(groups, f, ensure_ascii=False)
    os.replace(tmp_file, favs_path)


def _pvr_favs_load(group=None):
    """Load channels from a specific group, or all channels flat."""
    groups = _pvr_favs_load_all()
    if group:
        return groups.get(group, [])
    # All channels flat
    all_items = []
    for items in groups.values():
        all_items.extend(items)
    return all_items


def _pvr_favs_save(items, group='Favorites'):
    """Save channels to a specific group."""
    groups = _pvr_favs_load_all()
    groups[group] = items
    _pvr_favs_save_all(groups)


def _pvr_favs_add(channel, group='Favorites'):
    items = _pvr_favs_load(group)
    sid = str(channel.get('stream_id', '') or channel.get('id', ''))
    if any(str(i.get('stream_id', '')) == sid for i in items):
        return False
    items.append(channel)
    _pvr_favs_save(items, group)
    return True


def _pvr_favs_remove(stream_id, group='Favorites'):
    items = _pvr_favs_load(group)
    sid = str(stream_id)
    new_items = [i for i in items if str(i.get('stream_id', '')) != sid]
    if len(new_items) != len(items):
        _pvr_favs_save(new_items, group)
        return True
    return False


def _pvr_favs_is_fav(stream_id):
    sid = str(stream_id)
    return any(str(i.get('stream_id', '')) == sid for i in _pvr_favs_load())


def _pvr_favs_m3u_path():
    profile = xbmcvfs.translatePath(addon.getAddonInfo('profile'))
    return os.path.join(profile, 'pvr_favorites.m3u8')


def _export_pvr_favs_m3u():
    """Export all PVR favorite groups to M3U for the second PVR instance."""
    groups = _pvr_favs_load_all()
    creds = _get_credentials()
    xt_url = creds.get('xtream_url', '')
    xt_user = creds.get('xtream_username', '')
    xt_pwd = creds.get('xtream_password', '')
    hide_adult = addon.getSetting('hide_adult_categories').lower() == 'true'
    lines = ['#EXTM3U']
    for gname, items in groups.items():
        for ch in items:
            name = ch.get('name', 'Unknown')
            if hide_adult and _is_adult_category(name):
                continue
            icon = ch.get('stream_icon', '') or ch.get('icon', '')
            sid = str(ch.get('stream_id', ''))
            epg_id = ch.get('epg_channel_id') or sid
            if xt_url and xt_user and xt_pwd and sid:
                url = f'{xt_url}/live/{xt_user}/{xt_pwd}/{sid}.ts'
            else:
                continue
            lines.append(f'#EXTINF:-1 tvg-id="{epg_id}" tvg-logo="{icon}" group-title="★ Favorites - {gname}",{name}')
            lines.append(url)
    m3u_path = _pvr_favs_m3u_path()
    with open(m3u_path, 'w', encoding='utf-8') as f:
        f.write('\n'.join(lines) + '\n')
    return m3u_path


def _configure_pvr_favs_instance():
    try:
        pvr_profile = xbmcvfs.translatePath('special://profile/addon_data/pvr.iptvsimple')
        if not os.path.exists(pvr_profile):
            os.makedirs(pvr_profile)
        settings_path = os.path.join(pvr_profile, 'instance-settings-2.xml')
        m3u_path = _pvr_favs_m3u_path()
        epg_path = _pvr_epg_path()
        root = ET.Element('settings', {'version': '2'})
        defs = [
            ('kodi_addon_instance_name', 'PVR Favorites'),
            ('kodi_addon_instance_enabled', 'true'),
            ('m3uPathType', '0'),
            ('m3uPath', m3u_path),
            ('m3uUrl', ''),
            ('epgPathType', '0'),
            ('epgPath', epg_path),
            ('epgUrl', ''),
            ('m3uRefreshMode', '1'),
            ('logoPathType', '0'),
            ('logoPath', ''),
            ('logoBaseUrl', ''),
            ('catchupEnabled', 'true' if addon.getSetting('pvr_catchup_enabled').lower() == 'true' else 'false'),
            ('catchupPlayEpgAsLive', 'false'),
            ('allChannelsCatchupMode', '0'),
            ('catchupOverrideMode', '0'),
            ('catchupDays', addon.getSetting('pvr_catchup_days') or '7'),
            ('catchupOnlyOnFinishedProgrammes', 'false'),
            ('catchupWatchEpgBeginBufferMins', '5'),
            ('catchupWatchEpgEndBufferMins', '15'),
        ]
        for key, val in defs:
            el = ET.SubElement(root, 'setting', {'id': key})
            el.text = val
        tree = ET.ElementTree(root)
        tree.write(settings_path, encoding='utf-8', xml_declaration=True)
        _log('Configured PVR Favorites instance (instance-settings-2.xml)')
        return True
    except Exception as e:
        _log(f'Configure PVR Favorites instance failed: {e}')
        return False


def _sync_pvr_favorites():
    """Sync PVR favorites M3U and configure the second PVR instance."""
    _export_pvr_favs_m3u()
    _configure_pvr_favs_instance()




def pvr_favorites_manager(group=None):
    """PVR Favorites Manager - groups with channels, similar to Favorites Manager."""
    groups = _pvr_favs_load_all()

    # Level 1: show groups + New Group
    if group is None:
        for gname, items in groups.items():
            count = len(items)
            li = xbmcgui.ListItem(label=_t(30272).format(gname, count))
            li.setArt({'icon': 'DefaultFavourites.png'})
            ctx_items = [
                (_t(30320), f'RunPlugin({build_url({"mode": "pvr_favs_rename_group", "group": gname})})'),
                (_t(30321), f'RunPlugin({build_url({"mode": "pvr_favs_delete_group", "group": gname})})'),
            ]
            li.addContextMenuItems(ctx_items)
            q = {'mode': 'pvr_favorites_manager', 'group': gname}
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=build_url(q), listitem=li, isFolder=True)
        # + New PVR Group
        li = xbmcgui.ListItem(label='[COLOR yellow]{0}[/COLOR]'.format(_t(30200)))
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=build_url({'mode': 'pvr_favs_new_group'}), listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(addon_handle)
        return

    # Level 2: inside a group - manage button + channels
    items = groups.get(group, [])
    li = xbmcgui.ListItem(label='[COLOR yellow]{0}[/COLOR]'.format(_t(30201)))
    li.setArt({'icon': 'DefaultAddonService.png'})
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=build_url({'mode': 'pvr_favs_manage_group', 'group': group}), listitem=li, isFolder=True)

    if not items:
        li = xbmcgui.ListItem(label='[COLOR gray]{0}[/COLOR]'.format(_t(30202)))
        xbmcplugin.addDirectoryItem(handle=addon_handle, url='', listitem=li, isFolder=False)
    else:
        creds = _get_credentials()
        xt_url = creds.get('xtream_url', '')
        xt_user = creds.get('xtream_username', '')
        xt_pwd = creds.get('xtream_password', '')
        for ch in items:
            name = ch.get('name', 'Unknown')
            icon = ch.get('stream_icon', '') or ch.get('icon', '')
            sid = str(ch.get('stream_id', ''))
            li = xbmcgui.ListItem(label=name)
            li.setArt({'icon': icon, 'thumb': icon})
            ctx_items = [
                (_t(30322), f'RunPlugin({build_url({"mode": "pvr_fav_remove", "stream_id": sid, "group": group})})'),
            ]
            li.addContextMenuItems(ctx_items)
            stream_url = f'{xt_url}/live/{xt_user}/{xt_pwd}/{sid}.ts' if xt_url else ''
            q = {'mode': 'play_stream', 'url': stream_url, 'name': name, 'icon': icon, 'stype': 'live'}
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=build_url(q), listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(addon_handle)


def pvr_favs_manage_group(group):
    """Category browser for adding channels to a specific PVR group."""
    creds = _get_credentials()
    url = creds.get('xtream_url', '')
    user = creds.get('xtream_username', '')
    pwd = creds.get('xtream_password', '')
    if not url:
        xbmcgui.Dialog().notification('XStream Player', _t(30056))
        xbmcplugin.endOfDirectory(addon_handle)
        return
    # Current channels multiselect
    current_count = len(_pvr_favs_load(group))
    li = xbmcgui.ListItem(label='[COLOR gold]{0}[/COLOR]'.format(_t(30203).format(current_count)))
    li.setArt({'icon': 'DefaultFavourites.png'})
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=build_url({'mode': 'pvr_favs_group_current', 'group': group}), listitem=li, isFolder=False)
    # Search
    li = xbmcgui.ListItem(label='[COLOR yellow]{0}[/COLOR]'.format(_t(30204)))
    li.setArt({'icon': 'DefaultAddonsSearch.png'})
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=build_url({'mode': 'pvr_favs_group_search', 'group': group}), listitem=li, isFolder=False)
    # Categories - filter out hidden
    cats = _get_cached_xtream_categories(url, user, pwd, 'live')
    hidden_live = _get_hidden_subcats('live')
    for c in (cats or []):
        cat_id = str(c.get('category_id', ''))
        if cat_id in hidden_live:
            continue
        cat_name = c.get('category_name', 'Unknown')
        li = xbmcgui.ListItem(label=cat_name)
        li.setArt({'icon': 'DefaultFolder.png'})
        q = {'mode': 'pvr_favs_manage_cat', 'cat_id': cat_id, 'cat_name': cat_name, 'group': group}
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=build_url(q), listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(addon_handle)


def pvr_favs_group_current(group):
    """Multiselect dialog to keep/remove channels in a PVR group."""
    items = _pvr_favs_load(group)
    if not items:
        xbmcgui.Dialog().notification('XStream Player', _t(30101))
        return
    dialog = xbmcgui.Dialog()
    names = [ch.get('name', 'Unknown') for ch in items]
    preselect = list(range(len(items)))
    result = dialog.multiselect(_t(30330, group), names, preselect=preselect)
    if result is None:
        return
    if len(result) == len(items):
        return
    new_favs = [items[i] for i in result]
    _pvr_favs_save(new_favs, group)
    _sync_pvr_favorites()
    removed = len(items) - len(new_favs)
    dialog.notification('XStream Player', _t(30168, removed))
    xbmc.executebuiltin('Container.Refresh')


def pvr_favs_group_search(group):
    """Search channels and multiselect to add/remove from a PVR group."""
    dialog = xbmcgui.Dialog()
    query = dialog.input(_t(30146))
    if not query:
        return
    creds = _get_credentials()
    url = creds.get('xtream_url', '')
    user = creds.get('xtream_username', '')
    pwd = creds.get('xtream_password', '')
    streams = _get_cached_xtream_streams(url, user, pwd, 'live')
    hidden_live = _get_hidden_subcats('live')
    hidden_items = _get_hidden_items('live')
    if not streams:
        dialog.notification('XStream Player', _t(30067))
        return
    query_lower = query.lower()
    filtered = [s for s in streams if query_lower in s.get('name', '').lower()
                and str(s.get('category_id', '')) not in hidden_live
                and str(s.get('stream_id', '')) not in hidden_items]
    if not filtered:
        dialog.notification('XStream Player', _t(30067))
        return
    _pvr_favs_multiselect(filtered, dialog, group)


def pvr_favs_manage_cat(cat_id, cat_name, group):
    """Pick a category: add entire or multiselect individual channels for a PVR group."""
    dialog = xbmcgui.Dialog()
    action = dialog.select(cat_name, [_t(30331, group), _t(30332)])
    if action < 0:
        return
    creds = _get_credentials()
    url = creds.get('xtream_url', '')
    user = creds.get('xtream_username', '')
    pwd = creds.get('xtream_password', '')
    streams = _get_cached_xtream_streams(url, user, pwd, 'live')
    hidden_items = _get_hidden_items('live')
    filtered = [s for s in (streams or []) if str(s.get('category_id', '')) == cat_id
                and str(s.get('stream_id', '')) not in hidden_items]
    if not filtered:
        dialog.notification('XStream Player', _t(30068))
        return
    if action == 0:
        current_favs = _pvr_favs_load(group)
        fav_ids = {str(i.get('stream_id', '')) for i in current_favs}
        added = 0
        for s in filtered:
            if str(s.get('stream_id', '')) not in fav_ids:
                current_favs.append(s)
                added += 1
        _pvr_favs_save(current_favs, group)
        _sync_pvr_favorites()
        dialog.notification('XStream Player', _t(30169, added))
        xbmc.executebuiltin('Container.Refresh')
        return
    _pvr_favs_multiselect(filtered, dialog, group)


def _pvr_favs_multiselect(filtered, dialog, group='Favorites'):
    """Multiselect channels to add/remove from a PVR group."""
    names = [s.get('name', 'Unknown') for s in filtered]
    current_favs = _pvr_favs_load(group)
    fav_ids = {str(i.get('stream_id', '')) for i in current_favs}
    preselect = [i for i, s in enumerate(filtered) if str(s.get('stream_id', '')) in fav_ids]
    result = dialog.multiselect(_t(30151, group), names, preselect=preselect)
    if result is None:
        return
    filtered_ids = {str(s.get('stream_id', '')) for s in filtered}
    new_favs = [f for f in current_favs if str(f.get('stream_id', '')) not in filtered_ids]
    for i in (result or []):
        new_favs.append(filtered[i])
    _pvr_favs_save(new_favs, group)
    _sync_pvr_favorites()
    dialog.notification('XStream Player', _t(30170, len(new_favs), group))
    xbmc.executebuiltin('Container.Refresh')


def _check_account_expiry():
    """Warn if Xtream account expires within 7 days."""
    creds = _get_credentials()
    url = creds.get('xtream_url', '')
    user = creds.get('xtream_username', '')
    pwd = creds.get('xtream_password', '')
    if not url or not user or not pwd:
        return
    # Only check once per session using a flag file
    profile = xbmcvfs.translatePath(addon.getAddonInfo('profile'))
    flag = os.path.join(profile, 'expiry_checked')
    if os.path.exists(flag):
        try:
            age = time.time() - os.path.getmtime(flag)
            if age < 86400:  # check once per day
                return
        except Exception:
            pass
    try:
        info = IPTV.validate_xtream(url, user, pwd)
        if not info:
            # HTTP/auth failure — don't write the flag, otherwise we'd rate-limit
            # ourselves for 24h after a transient failure.
            return
        if info.get('exp_date'):
            import datetime
            exp_dt = datetime.datetime.fromtimestamp(int(info['exp_date']))
            days_left = (exp_dt - datetime.datetime.now()).days
            if days_left < 7:
                xbmcgui.Dialog().notification(
                    'XStream Player',
                    _t(30300, days_left),
                    xbmcgui.NOTIFICATION_WARNING, 5000)
        try:
            with open(flag, 'w') as f:
                f.write('1')
        except Exception as e:
            _log(f'expiry flag write failed: {e}')
    except Exception as e:
        _log(f'account expiry check failed: {e}')


# Per-invocation parse cache for settings.xml. Same plugin invocation may call
# _get_setting_direct() many times across menu builders; reparsing the XML on
# every call is wasteful. We key on (path, mtime) so any external write is seen.
_settings_xml_cache = {'path': None, 'mtime': 0, 'values': None}


def _get_setting_direct(setting_id, default=''):
    """Read setting directly from settings.xml to bypass Kodi's cache."""
    try:
        profile = xbmcvfs.translatePath(addon.getAddonInfo('profile'))
        settings_path = os.path.join(profile, 'settings.xml')
        if os.path.exists(settings_path):
            mtime = os.path.getmtime(settings_path)
            cache = _settings_xml_cache
            if cache['path'] != settings_path or cache['mtime'] != mtime or cache['values'] is None:
                import xml.etree.ElementTree as ET
                tree = ET.parse(settings_path)
                root = tree.getroot()
                values = {}
                for setting in root.findall('setting'):
                    sid = setting.get('id')
                    if sid:
                        values[sid] = setting.text or ''
                cache['path'] = settings_path
                cache['mtime'] = mtime
                cache['values'] = values
            if setting_id in cache['values']:
                return cache['values'][setting_id] or default
    except Exception:
        pass
    return addon.getSetting(setting_id) or default


def _get_addon_group_items():
    items = []
    ag_visible = set(_get_ag_visible())
    
    for i in range(1, 6):
        if _get_setting_direct(f'ag_{i}_enabled', 'false') != 'true':
            continue
        # Check if this specific group is visible (if ag_visible is set)
        if ag_visible and f'ag_{i}' not in ag_visible:
            continue
        
        group_name = _get_setting_direct(f'ag_{i}_name', _t(30391, i))
        group_addons = _get_group_addons(i)
        
        # Empty group - show message item
        if not group_addons:
            items.append(('[COLOR gray]{0} {1}[/COLOR]'.format(group_name, _t(30196)), 
                         {'mode': 'empty_addon_group', 'group': str(i)}, 'DefaultAddonVideo.png', True))
            continue
        
        # Single addon - open directly; Multiple - show list
        if len(group_addons) == 1:
            items.append((group_name, 
                         {'mode': 'open_addon', 'addon_id': group_addons[0]['id'], 'group': str(i)}, 'DefaultAddonVideo.png', False))
        else:
            items.append((group_name, 
                         {'mode': 'open_addon_group', 'group': str(i)}, 'DefaultAddonVideo.png', True))
    return items


def empty_addon_group(group_num):
    group_name = _get_setting_direct(f'ag_{group_num}_name', _t(30391, group_num))
    dialog = xbmcgui.Dialog()
    choice = dialog.yesno(
        group_name,
        _t(30564),
        yeslabel=_t(30183),
        nolabel=_t(30164)
    )
    if choice:
        # Open settings at Addon Groups category
        addon.openSettings()
        # Navigate to Addon Groups tab (category index 2: 0=Profile, 1=Profiles, 2=Addon Groups)
        xbmc.sleep(500)
        xbmc.executebuiltin('SetFocus(10,2)')  # Settings categories control ID 10, index 2
    # Always end directory properly
    xbmcplugin.endOfDirectory(addon_handle, succeeded=False)


def _get_addon_data_path():
    return xbmcvfs.translatePath(addon.getAddonInfo('path'))


def _get_group_addons(group_num):
    data_path = _get_addon_data_path()
    try:
        with open(os.path.join(data_path, f'ag_{group_num}_addons.json'), 'r') as f:
            return json.load(f)
    except Exception:
        return []


def _save_group_addons(group_num, addons_list):
    """Save list of addons for a group (persists across profiles)"""
    data_path = _get_addon_data_path()
    addons_file = os.path.join(data_path, f'ag_{group_num}_addons.json')
    tmp_file = addons_file + '.tmp'
    with open(tmp_file, 'w') as f:
        json.dump(addons_list, f)
    os.replace(tmp_file, addons_file)


def select_ag_addons(group):
    dialog = xbmcgui.Dialog()
    
    # Get all installed video, audio, picture addons
    all_addons = []
    for addon_type in ['xbmc.addon.video', 'xbmc.addon.audio', 'xbmc.addon.image']:
        try:
            resp = xbmc.executeJSONRPC(json.dumps({
                'jsonrpc': '2.0', 'method': 'Addons.GetAddons',
                'params': {'type': addon_type, 'installed': True, 'properties': ['name']},
                'id': 1
            }))
            result = json.loads(resp).get('result', {}).get('addons', [])
            all_addons.extend(result)
        except Exception:
            pass
    
    # Exclude self
    all_addons = [a for a in all_addons if a.get('addonid') != 'plugin.video.xstream-player']
    
    if not all_addons:
        dialog.notification('XStream Player', _t(30069))
        return
    
    # Sort by name
    all_addons.sort(key=lambda x: x.get('name', '').lower())
    
    # Get currently saved addons
    saved = _get_group_addons(group)
    saved_ids = {a['id'] for a in saved}
    
    # Build list for dialog
    names = [a.get('name', 'Unknown') for a in all_addons]
    preselect = [i for i, a in enumerate(all_addons) if a.get('addonid') in saved_ids]
    
    result = dialog.multiselect(_t(30171), names, preselect=preselect)
    if result is None:
        return
    
    # Save selected
    selected = [{'id': all_addons[i]['addonid'], 'name': all_addons[i]['name']} for i in result]
    _save_group_addons(group, selected)
    dialog.notification('XStream Player', _t(30259, len(selected)))
    xbmc.sleep(1000)
    dialog.notification('XStream Player', _t(30070), xbmcgui.NOTIFICATION_INFO, 5000)
    xbmc.executebuiltin('Container.Refresh')


def open_addon_group(group):
    group = int(group)
    group_name = addon.getSetting(f'ag_{group}_name') or _t(30391, group)
    addons = _get_group_addons(group)
    
    if not addons:
        xbmcgui.Dialog().notification('XStream Player', _t(30102))
        xbmcplugin.endOfDirectory(addon_handle)
        return
    
    # Show list of addons in group
    for a in addons:
        addon_id = a['id']
        addon_name = a['name']
        li = xbmcgui.ListItem(label=addon_name)
        li.setArt({'icon': 'DefaultAddonVideo.png'})
        # Pass group so we know to return to group list
        q = {'mode': 'open_addon', 'addon_id': addon_id, 'group': str(group)}
        # isFolder=False because we launch the addon directly
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=build_url(q), listitem=li, isFolder=False)
    
    xbmcplugin.endOfDirectory(addon_handle)


def open_addon(addon_id, group=None):
    # Validate addon_id format to prevent injection (standard Kodi addon ID pattern)
    if not addon_id or not re.match(r'^[a-zA-Z][a-zA-Z0-9._-]*$', str(addon_id)):
        _log(f'Invalid addon_id format: {addon_id}')
        return
    if group:
        # Called from group - return to group when backing out
        xbmc.executebuiltin(f'Container.Update(plugin://{addon_id})')
    else:
        # Single addon - return to main menu when backing out  
        xbmc.executebuiltin(f'Container.Update(plugin://{addon_id})')


def main_menu():
    _log('Opening main menu')
    _check_credentials_refresh_prompt()  # Prompt to refresh after first credentials entry
    _check_auto_refresh()
    if addon.getSetting('pvr_reload_on_launch').lower() == 'true':
        try:
            resp = json.loads(xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.GetAddonDetails","params":{"addonid":"pvr.iptvsimple","properties":["enabled"]},"id":1}'))
            enabled = resp.get('result', {}).get('addon', {}).get('enabled', False)
            if not enabled:
                xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","params":{"addonid":"pvr.iptvsimple","enabled":true},"id":1}')
                _log('PVR was disabled, enabled it on launch')
            else:
                _log('PVR already enabled on launch')
        except Exception as e:
            _log(f'PVR load on launch error: {e}')

    # Move blocking startup checks (account expiry HTTP call, update check HTTP
    # call) to a background thread so menu rendering is never gated on the
    # network. Their dialogs (if any) surface after the menu is already on screen.
    # Snapshot the active profile so a profile switch on the main thread cannot
    # cause the daemon to write a cache/credentials file under the wrong key.
    _profile_snapshot = pm.active

    def _bg_startup_checks():
        # Pin profile inside the daemon to the snapshot taken at thread spawn.
        # _check_account_expiry reads pm.get_credentials() which depends on
        # pm.active; if the user switched profiles mid-flight we'd validate
        # credentials for the wrong profile and cache the wrong expiry flag.
        try:
            if pm.active != _profile_snapshot:
                _log(f'startup checks: profile changed ({_profile_snapshot}->{pm.active}), pinning to snapshot')
                pm.active = _profile_snapshot
        except Exception:
            pass
        try:
            _check_account_expiry()
        except Exception as e:
            _log(f'Account expiry check error: {e}')
        try:
            from updater import silent_check_on_startup
            silent_check_on_startup()
        except Exception as e:
            _log(f'Update check error: {e}')
    t = threading.Thread(target=_bg_startup_checks, name='XStreamStartupChecks')
    t.daemon = True
    t.start()
    # Update version display in settings
    try:
        current_version = addon.getAddonInfo('version')
        addon.setSetting('current_version_display', current_version)
    except Exception as e:
        _log(f'Version display update error: {e}')
    
    # Show changelog on first launch after update
    try:
        if addon.getSetting('show_changelog_on_update') != 'false':
            current_version = addon.getAddonInfo('version')
            last_seen = addon.getSetting('last_seen_version') or '0.0.0'
            if current_version != last_seen:
                changelog_path = os.path.join(xbmcvfs.translatePath(addon.getAddonInfo('path')), 'CHANGELOG.md')
                try:
                    with open(changelog_path, 'r', encoding='utf-8') as f:
                        changelog = f.read()
                    # Extract only the first version section (latest)
                    lines = changelog.split('\n')
                    version_content = []
                    in_version = False
                    for line in lines:
                        if line.startswith('Version ') and not in_version:
                            in_version = True
                            version_content.append(line)
                        elif line.startswith('Version ') and in_version:
                            # Found next version, stop
                            break
                        elif in_version:
                            # Collect all lines until next version
                            version_content.append(line)
                    # Remove trailing empty lines
                    while version_content and not version_content[-1].strip():
                        version_content.pop()
                    if version_content:
                        xbmcgui.Dialog().textviewer(_t(30340, current_version), '\n'.join(version_content))
                except Exception:
                    pass
                addon.setSetting('last_seen_version', current_version)
    except Exception as e:
        _log(f'Changelog display error: {e}')
    
    visible = set(pm.get_visible_categories())
    creds = _get_credentials()
    load_live = pm.get_profile_setting('load_live') != 'false'
    load_movies = pm.get_profile_setting('load_movies') != 'false'
    load_series = pm.get_profile_setting('load_series') != 'false'
    has_live = bool(creds.get('xtream_url') or creds.get('m3u_url')) and load_live
    has_movies = bool(creds.get('xtream_url')) and load_movies
    has_series = bool(creds.get('xtream_url')) and load_series
    has_replay = bool(creds.get('xtream_url')) and load_live
    has_favs = len(fav.get_all()) > 0

    # Backwards compat: old 'live' key enables both
    if 'live' in visible:
        visible.add('live_pvr')
        visible.add('live_classic')
    
    # Build items dict for ordering
    items_dict = {}
    
    # Addon Groups
    ag_items = _get_addon_group_items()
    for item in ag_items:
        if len(item) == 4:
            label, q, icon, is_folder = item
        else:
            label, q, icon = item
            is_folder = True
        # Use group index as key for individual groups (always ag_{num})
        group_num = q.get('group', [''])[0] if 'group' in q else None
        if group_num:
            items_dict[f'ag_{group_num}'] = (label, q, icon, is_folder)
        else:
            # Fallback - shouldn't happen with new structure
            addon_id = q.get('addon_id', [''])[0]
            items_dict[f'ag_single_{addon_id}'] = (label, q, icon, is_folder)
    
    # Regular items
    if 'live_pvr' in visible and has_live:
        items_dict['live_pvr'] = (_t(30001), {'mode': 'open_pvr'}, 'DefaultAddonPVRClient.png', False)
    if 'live_classic' in visible and has_live:
        items_dict['live_classic'] = (_t(30002), {'mode': 'live_menu'}, 'DefaultTVShows.png', True)
    if 'guide' in visible and has_live:
        items_dict['guide'] = (_t(30003), {'mode': 'open_pvr_guide'}, 'DefaultPVRGuide.png', False)
    if 'movies' in visible and has_movies:
        items_dict['movies'] = (_t(30004), {'mode': 'movies_menu'}, 'DefaultMovies.png', True)
    if 'series' in visible and has_series:
        items_dict['series'] = (_t(30005), {'mode': 'series_menu'}, 'DefaultTVShows.png', True)
    if 'replay' in visible and has_replay:
        items_dict['replay'] = (_t(30006), {'mode': 'replay_menu'}, 'DefaultAddonsUpdates.png', True)
    if 'search' in visible and has_live:
        items_dict['search'] = (_t(30007), {'mode': 'search_global'}, 'DefaultAddonsSearch.png', True)
    if 'pvr_favs' in visible and has_live:
        items_dict['pvr_favs'] = (_t(30008), {'mode': 'pvr_favorites_manager'}, 'DefaultFavourites.png', True)
    if 'favorites' in visible and (has_live or has_movies or has_series):
        items_dict['favorites'] = (_t(30009), {'mode': 'favorites_menu'}, 'DefaultFavourites.png', True)
    items_dict['tools'] = (_t(30010), {'mode': 'tools_menu'}, 'DefaultAddonService.png', True)
    
    # Apply saved order if exists
    saved_order = _get_main_menu_order()
    if saved_order:
        ordered_items = []
        for key in saved_order:
            if key in items_dict:
                ordered_items.append(items_dict.pop(key))
        # Add any remaining items (new items not in saved order) at the end
        ordered_items.extend(items_dict.values())
        items = ordered_items
    else:
        items = list(items_dict.values())

    for item in items:
        if len(item) == 4:
            # Addon group item: (label, query, icon, is_folder)
            label, q, icon, is_folder = item
        else:
            # Regular item: (label, query, icon)
            label, q, icon = item
            is_folder = q.get('mode') not in ('open_pvr', 'open_pvr_guide')
        li = xbmcgui.ListItem(label=label)
        li.setArt({'icon': icon})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=build_url(q), listitem=li, isFolder=is_folder)
    xbmcplugin.endOfDirectory(addon_handle)


def tools_menu():
    _log('Opening tools menu')
    if not _check_pin('Tools'):
        xbmcplugin.endOfDirectory(addon_handle, succeeded=False)
        return
    creds = _get_credentials()
    active_name = creds.get('name', _t(30390, 1))
    pvr_synced = os.path.exists(_pvr_m3u_path())
    items = [
        ('[COLOR yellow]{0}[/COLOR]'.format(_t(30011)), {'mode': 'settings'}, 'DefaultAddonService.png'),
        (_t(30012).format(active_name), {'mode': 'refresh_data'}, 'DefaultAddonService.png'),
        (_t(30013), {'mode': 'manage_visible_cats'}, 'DefaultAddonService.png'),
        (_t(30014), {'mode': 'reorder_main_menu'}, 'DefaultAddonService.png'),
        (_t(30015), {'mode': 'hide_categories_menu'}, 'DefaultAddonService.png'),
        (_t(30016), {'mode': 'clear_cache_menu'}, 'DefaultAddonService.png'),
        (_t(30017), {'mode': 'switch_profile'}, 'DefaultAddonService.png'),
        (_t(30018), {'mode': 'test_connection'}, 'DefaultAddonService.png'),
        (_t(30019), {'mode': 'account_info'}, 'DefaultAddonService.png'),
        ('[COLOR green]{0}[/COLOR]'.format(_t(30020)), {'mode': 'check_update'}, 'DefaultAddonService.png'),
    ]
    for label, q, icon in items:
        li = xbmcgui.ListItem(label=label)
        li.setArt({'icon': icon})
        is_folder = q.get('mode') not in ('settings', 'refresh_data', 'toggle_setting', 'manage_visible_cats',
                                             'clear_cache_menu', 'reorder_main_menu')
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=build_url(q), listitem=li, isFolder=is_folder)
    xbmcplugin.endOfDirectory(addon_handle)


def reorder_main_menu():
    """Reorder main menu items - pick item, then pick where to put it."""
    dialog = xbmcgui.Dialog()
    
    while True:  # Loop to stay in reorder tool
        # Build list of current main menu items
        visible = set(pm.get_visible_categories())
        creds = _get_credentials()
        load_live = pm.get_profile_setting('load_live') != 'false'
        load_movies = pm.get_profile_setting('load_movies') != 'false'
        load_series = pm.get_profile_setting('load_series') != 'false'
        has_live = bool(creds.get('xtream_url') or creds.get('m3u_url')) and load_live
        has_movies = bool(creds.get('xtream_url')) and load_movies
        has_series = bool(creds.get('xtream_url')) and load_series
        has_replay = bool(creds.get('xtream_url')) and load_live
        
        if 'live' in visible:
            visible.add('live_pvr')
            visible.add('live_classic')
        
        # Build items list
        items = []
        ag_visible = set(_get_ag_visible())
        for i in range(1, 6):
            if _get_setting_direct(f'ag_{i}_enabled', 'false') != 'true':
                continue
            if ag_visible and f'ag_{i}' not in ag_visible:
                continue
            group_name = _get_setting_direct(f'ag_{i}_name', _t(30391, i))
            items.append([f'ag_{i}', group_name])
        
        if 'live_pvr' in visible and has_live:
            items.append(['live_pvr', _t(30001)])
        if 'live_classic' in visible and has_live:
            items.append(['live_classic', _t(30002)])
        if 'guide' in visible and has_live:
            items.append(['guide', _t(30380)])
        if 'movies' in visible and has_movies:
            items.append(['movies', _t(30004)])
        if 'series' in visible and has_series:
            items.append(['series', _t(30005)])
        if 'replay' in visible and has_replay:
            items.append(['replay', _t(30381)])
        if 'search' in visible and has_live:
            items.append(['search', _t(30007)])
        if 'pvr_favs' in visible and has_live:
            items.append(['pvr_favs', _t(30008)])
        if 'favorites' in visible and (has_live or has_movies or has_series):
            items.append(['favorites', _t(30009)])
        items.append(['tools', _t(30010)])
        
        if len(items) <= 1:
            dialog.notification('XStream Player', _t(30071))
            return
        
        # Load saved order
        saved_order = _get_main_menu_order()
        if saved_order:
            order_map = {k: i for i, k in enumerate(saved_order)}
            items.sort(key=lambda x: order_map.get(x[0], 9999))
        
        labels = [f"{i+1}. {name}" for i, (key, name) in enumerate(items)]
        labels.append('[COLOR red]{0}[/COLOR]'.format(_t(30158)))
        
        choice = dialog.select(_t(30172), labels)
        if choice == -1 or choice >= len(items):
            return  # Cancelled - exit
        
        from_idx = choice
        from_key, from_name = items[from_idx]
        
        to_labels = []
        original_indices = []  # Track which items[i] each label refers to
        for i, (key, name) in enumerate(items):
            if i == from_idx:
                continue
            to_labels.append(_t(30192, name))
            original_indices.append(i)  # Remember this label = items[i]
        to_labels.append(_t(30193))
        to_labels.append('[COLOR red]{0}[/COLOR]'.format(_t(30158)))
        
        to_choice = dialog.select(_t(30194, from_name), to_labels)
        if to_choice == -1 or to_choice == len(to_labels) - 1:
            return  # Cancel - exit
        
        # Calculate new position
        if to_choice == len(to_labels) - 2:  # Move to End
            to_idx = len(items)
        else:
            # Map back to original index
            to_idx = original_indices[to_choice]
            # After popping from_idx, indices after it shift down by 1
            if to_idx > from_idx:
                to_idx -= 1
        
        confirm = dialog.yesno(_t(30041), 
                               _t(30565, from_name),
                               yeslabel=_t(30160),
                               nolabel=_t(30161))
        if not confirm:
            continue  # Back to start
        
        # Perform the move
        item = items.pop(from_idx)
        if to_idx > len(items):
            items.append(item)
        else:
            items.insert(to_idx, item)
        
        # Save
        new_order = [k for k, n in items]
        _set_main_menu_order(new_order)
        dialog.notification('XStream Player', _t(30072))
        # Return to main menu so it shows updated order
        xbmc.executebuiltin('Container.Update(plugin://plugin.video.xstream-player/,replace)')


def manage_visible_cats():
    visible = set(pm.get_visible_categories())
    ag_visible = set(_get_ag_visible())
    
    # Build options and keys dynamically with Addon Groups
    # Each group is separate - no master toggle
    options = []
    keys = []
    
    # Add enabled addon group names as separate items
    for i in range(1, 6):
        if _get_setting_direct(f'ag_{i}_enabled', 'false') == 'true':
            group_name = _get_setting_direct(f'ag_{i}_name', _t(30391, i))
            options.append(group_name)
            keys.append(f'ag_{i}')
    
    options.extend(['Live TV - PVR', 'Live TV - Classic', 'Guide', 'Movies', 'Series', 'Replay', 'Search', 'Favorites Manager - PVR', 'Favorites - Classic, Movies, Series'])
    keys.extend(['live_pvr', 'live_classic', 'guide', 'movies', 'series', 'replay', 'search', 'pvr_favs', 'favorites'])
    
    # Backwards compat: old 'live' key enables both
    if 'live' in visible:
        visible.add('live_pvr')
        visible.add('live_classic')
        visible.discard('live')
    
    # Build preselect
    combined_visible = visible | ag_visible
    preselect = [i for i, k in enumerate(keys) if k in combined_visible]
    
    dialog = xbmcgui.Dialog()
    result = dialog.multiselect(_t(30173), options, preselect=preselect)
    if result is None:
        return
    
    new_visible = []
    new_ag_visible = []
    for i in result:
        key = keys[i]
        if key.startswith('ag_'):
            new_ag_visible.append(key)
        else:
            new_visible.append(key)
    
    pm.set_visible_categories(new_visible)
    _set_ag_visible(new_ag_visible)
    xbmcgui.Dialog().notification('XStream Player', _t(30083))
    xbmc.executebuiltin('Container.Refresh')


def _get_ag_visible():
    data_path = _get_addon_data_path()
    try:
        with open(os.path.join(data_path, 'ag_visible.json'), 'r') as f:
            return json.load(f)
    except Exception:
        # Default: all enabled groups are visible
        return [f'ag_{i}' for i in range(1, 6) if _get_setting_direct(f'ag_{i}_enabled', 'false') == 'true']


def _get_main_menu_order_path():
    profile = xbmcvfs.translatePath(addon.getAddonInfo('profile'))
    return os.path.join(profile, f'main_menu_order_p{pm.active}.json')


def _get_main_menu_order():
    """Load saved main menu order. Returns list of keys or empty list."""
    try:
        with open(_get_main_menu_order_path(), 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return []


def _set_main_menu_order(order_list):
    """Save main menu order."""
    profile = xbmcvfs.translatePath(addon.getAddonInfo('profile'))
    if not os.path.exists(profile):
        os.makedirs(profile)
    order_path = _get_main_menu_order_path()
    tmp_file = order_path + '.tmp'
    with open(tmp_file, 'w', encoding='utf-8') as f:
        json.dump(order_list, f)
    os.replace(tmp_file, order_path)


def _set_ag_visible(ag_list):
    """Save list of visible addon groups (persists across profiles)"""
    data_path = _get_addon_data_path()
    visible_file = os.path.join(data_path, 'ag_visible.json')
    tmp_file = visible_file + '.tmp'
    with open(tmp_file, 'w') as f:
        json.dump(ag_list, f)
    os.replace(tmp_file, visible_file)


def _get_hidden_subcats(stype, profile_num=None):
    """Get list of hidden subcategory IDs for a given type (live/movie/series)."""
    pnum = profile_num or pm.active
    profile = xbmcvfs.translatePath(addon.getAddonInfo('profile'))
    path = os.path.join(profile, f'hidden_subcats_{stype}_{pnum}.json')
    try:
        with open(path, 'r', encoding='utf-8') as f:
            return set(json.load(f))
    except Exception:
        return set()


def _set_hidden_subcats(stype, hidden, profile_num=None):
    """Save list of hidden subcategory IDs for a given type."""
    pnum = profile_num or pm.active
    profile = xbmcvfs.translatePath(addon.getAddonInfo('profile'))
    if not os.path.exists(profile):
        os.makedirs(profile)
    path = os.path.join(profile, f'hidden_subcats_{stype}_{pnum}.json')
    tmp_file = path + '.tmp'
    with open(tmp_file, 'w', encoding='utf-8') as f:
        json.dump(list(hidden), f)
    os.replace(tmp_file, path)


def _get_hidden_items(stype, profile_num=None):
    """Get set of hidden individual stream IDs for a given type."""
    pnum = profile_num or pm.active
    profile = xbmcvfs.translatePath(addon.getAddonInfo('profile'))
    path = os.path.join(profile, f'hidden_items_{stype}_{pnum}.json')
    try:
        with open(path, 'r', encoding='utf-8') as f:
            return set(json.load(f))
    except Exception:
        return set()


def _set_hidden_items(stype, hidden, profile_num=None):
    """Save set of hidden individual stream IDs for a given type."""
    pnum = profile_num or pm.active
    profile = xbmcvfs.translatePath(addon.getAddonInfo('profile'))
    if not os.path.exists(profile):
        os.makedirs(profile)
    path = os.path.join(profile, f'hidden_items_{stype}_{pnum}.json')
    tmp_file = path + '.tmp'
    with open(tmp_file, 'w', encoding='utf-8') as f:
        json.dump(list(hidden), f)
    os.replace(tmp_file, path)


def hide_categories_menu(profile_num=None):
    """Show content types as folder view."""
    pnum = profile_num or pm.active
    options = [(_t(30002), 'live'), (_t(30004), 'movie'), (_t(30005), 'series')]
    for label, stype in options:
        li = xbmcgui.ListItem(label=label)
        li.setArt({'icon': 'DefaultFolder.png'})
        q = {'mode': 'manage_hidden_subcats', 'stype': stype, 'pnum': pnum}
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=build_url(q), listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(addon_handle)


def manage_content_dialog(stype, profile_num):
    """Dialog-based content manager for use from settings. Loops until user cancels."""
    pnum = profile_num or pm.active
    creds = _get_credentials()
    url = creds.get('xtream_url', '')
    user = creds.get('xtream_username', '')
    pwd = creds.get('xtream_password', '')
    if not url:
        xbmcgui.Dialog().notification('XStream Player', _t(30073))
        return
    cats = _get_cached_xtream_categories(url, user, pwd, stype)
    if not cats:
        xbmcgui.Dialog().notification('XStream Player', _t(30074))
        return
    dialog = xbmcgui.Dialog()
    streams = _get_cached_xtream_streams(url, user, pwd, stype)
    stype_label = stype.replace('movie', 'Movies').replace('live', 'Live TV').replace('series', 'Series')
    changed = False
    while True:
        hidden = _get_hidden_subcats(stype, pnum)
        hidden_items = _get_hidden_items(stype, pnum)
        hidden_cat_count = len(hidden)
        hidden_item_count = len(hidden_items)
        labels = [
            '[COLOR gold]{0}[/COLOR]'.format(_t(30159, hidden_cat_count)),
            '[COLOR gold]{0}[/COLOR]'.format(_t(30190, hidden_item_count)),
        ]
        for c in cats:
            cat_name = c.get('category_name', 'Unknown')
            labels.append(cat_name)
        choice = dialog.select(f'Manage {stype_label} content', labels)
        if choice < 0:
            break
        if choice == 0:
            # Multiselect categories — checked = HIDDEN, with Select/Deselect All
            cat_names = [_t(30333), _t(30334)] + [c.get('category_name', 'Unknown') for c in cats]
            cat_ids = [str(c.get('category_id', '')) for c in cats]
            preselect = [i + 2 for i, cid in enumerate(cat_ids) if cid in hidden]
            result = dialog.multiselect(_t(30335), cat_names, preselect=preselect)
            if result is None:
                continue
            if 0 in result:
                # Select All — reopen with all selected
                preselect = list(range(2, len(cat_names)))
                result = dialog.multiselect(_t(30335), cat_names, preselect=preselect)
                if result is None:
                    continue
            if 1 in result:
                # Deselect All — reopen with none selected
                result = dialog.multiselect(_t(30523), cat_names, preselect=[])
                if result is None:
                    continue
            real_result = [i - 2 for i in result if i >= 2] if result else []
            new_hidden = {cat_ids[i] for i in real_result} if real_result else set()
            if new_hidden != hidden:
                _set_hidden_subcats(stype, new_hidden, pnum)
                dialog.notification('XStream Player', _t(30174, len(new_hidden)))
                changed = True
            continue
        if choice == 1:
            # View all hidden individual items — multiselect to unhide
            if not hidden_items:
                dialog.notification('XStream Player', _t(30075))
                continue
            hidden_streams = [s for s in (streams or []) if str(s.get('stream_id', '')) in hidden_items]
            if not hidden_streams:
                dialog.notification('XStream Player', _t(30135))
                continue
            h_names = [s.get('name', 'Unknown') for s in hidden_streams]
            h_ids = [str(s.get('stream_id', '')) for s in hidden_streams]
            preselect = list(range(len(hidden_streams)))
            result = dialog.multiselect(_t(30152, stype_label), h_names, preselect=preselect)
            if result is None:
                continue
            new_hidden = {h_ids[i] for i in result} if result else set()
            orphan_ids = hidden_items - set(h_ids)
            _set_hidden_items(stype, new_hidden | orphan_ids, pnum)
            unhidden = len(hidden_streams) - (len(result) if result else 0)
            if unhidden:
                dialog.notification('XStream Player', _t(30175, unhidden))
                changed = True
            continue
        # Category selected — go directly into content multiselect
        cat = cats[choice - 2]
        cat_id = str(cat.get('category_id', ''))
        cat_name = cat.get('category_name', 'Unknown')
        filtered = [s for s in (streams or []) if str(s.get('category_id', '')) == cat_id]
        if not filtered:
            dialog.notification('XStream Player', _t(30136))
            continue
        ids = [str(s.get('stream_id', '')) for s in filtered]
        names = [_t(30333), _t(30334)] + [s.get('name', 'Unknown') for s in filtered]
        preselect = [i + 2 for i, sid in enumerate(ids) if sid in hidden_items]
        result = dialog.multiselect(_t(30336, cat_name), names, preselect=preselect)
        if result is None:
            continue
        if 0 in result:
            preselect = list(range(2, len(names)))
            result = dialog.multiselect(_t(30336, cat_name), names, preselect=preselect)
            if result is None:
                continue
        if 1 in result:
            result = dialog.multiselect(_t(30524, cat_name), names, preselect=[])
            if result is None:
                continue
        real_result = [i - 2 for i in result if i >= 2] if result else []
        cat_id_set = set(ids)
        new_hidden = (hidden_items - cat_id_set) | ({ids[i] for i in real_result} if real_result else set())
        if new_hidden != hidden_items:
            _set_hidden_items(stype, new_hidden, pnum)
            hidden_count = len(result) if result else 0
            dialog.notification('XStream Player', _t(30176, hidden_count, cat_name))
            changed = True
    # Re-sync PVR if anything changed and this is the active profile
    if changed and pnum == pm.active and stype == 'live':
        _sync_pvr_force()
    # Reopen settings at Profiles tab
    xbmc.executebuiltin('Addon.OpenSettings(plugin.video.xstream-player)')
    xbmc.sleep(300)
    xbmc.executebuiltin('SetFocus(9,1)')
    xbmc.executebuiltin('SetFocus(10,0)')


def manage_hidden_subcats(stype, profile_num=None):
    """Show subcategories as folder view. Clicking opens dialog: hide entire or browse content."""
    pnum = profile_num or pm.active
    creds = _get_credentials()
    url = creds.get('xtream_url', '')
    user = creds.get('xtream_username', '')
    pwd = creds.get('xtream_password', '')
    if not url:
        xbmcgui.Dialog().notification('XStream Player', _t(30073))
        xbmcplugin.endOfDirectory(addon_handle)
        return
    cats = _get_cached_xtream_categories(url, user, pwd, stype)
    if not cats:
        xbmcgui.Dialog().notification('XStream Player', _t(30074))
        xbmcplugin.endOfDirectory(addon_handle)
        return
    hidden = _get_hidden_subcats(stype, pnum)
    hidden_items = _get_hidden_items(stype, pnum)
    # Select All / Deselect All at top
    li = xbmcgui.ListItem(label='[COLOR red]{0}[/COLOR]'.format(_t(30260)))
    li.setArt({'icon': 'DefaultAddonNone.png'})
    q = {'mode': 'hide_all_subcats', 'stype': stype, 'pnum': pnum, 'action': 'hide'}
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=build_url(q), listitem=li, isFolder=False)
    li = xbmcgui.ListItem(label='[COLOR green]{0}[/COLOR]'.format(_t(30261)))
    li.setArt({'icon': 'DefaultAddonNone.png'})
    q = {'mode': 'hide_all_subcats', 'stype': stype, 'pnum': pnum, 'action': 'unhide'}
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=build_url(q), listitem=li, isFolder=False)
    # Hidden Items
    li = xbmcgui.ListItem(label='[COLOR gold]{0}[/COLOR]'.format(_t(30262).format(len(hidden_items))))
    li.setArt({'icon': 'DefaultFavourites.png'})
    q = {'mode': 'hidden_items_all', 'stype': stype, 'pnum': pnum}
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=build_url(q), listitem=li, isFolder=False)
    for c in cats:
        cat_id = str(c.get('category_id', ''))
        cat_name = c.get('category_name', 'Unknown')
        is_hidden = cat_id in hidden
        label = '[COLOR red]{0}[/COLOR] {1}'.format(_t(30191), cat_name) if is_hidden else cat_name
        li = xbmcgui.ListItem(label=label)
        li.setArt({'icon': 'DefaultFolder.png'})
        q = {'mode': 'hide_subcat_action', 'stype': stype, 'cat_id': cat_id, 'cat_name': cat_name, 'pnum': pnum}
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=build_url(q), listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(addon_handle)


def hide_subcat_action(stype, cat_id, cat_name, profile_num=None):
    """Dialog: hide/unhide entire category or browse individual items."""
    pnum = profile_num or pm.active
    hidden = _get_hidden_subcats(stype, pnum)
    is_hidden = cat_id in hidden
    dialog = xbmcgui.Dialog()
    if is_hidden:
        options = [_t(30525), _t(30526)]
    else:
        options = [_t(30527), _t(30526)]
    choice = dialog.select(cat_name, options)
    if choice < 0:
        return
    if choice == 0:
        if is_hidden:
            hidden.discard(cat_id)
            xbmcgui.Dialog().notification('XStream Player', _t(30301, cat_name))
        else:
            hidden.add(cat_id)
            xbmcgui.Dialog().notification('XStream Player', _t(30302, cat_name))
        _set_hidden_subcats(stype, hidden, pnum)
        xbmc.executebuiltin('Container.Refresh')
    elif choice == 1:
        creds = _get_credentials()
        url = creds.get('xtream_url', '')
        user = creds.get('xtream_username', '')
        pwd = creds.get('xtream_password', '')
        streams = _get_cached_xtream_streams(url, user, pwd, stype)
        filtered = [s for s in (streams or []) if str(s.get('category_id', '')) == cat_id]
        if not filtered:
            xbmcgui.Dialog().notification('XStream Player', _t(30136))
            return
        hidden_items = _get_hidden_items(stype, pnum)
        ids = [str(s.get('stream_id', '')) for s in filtered]
        names = [_t(30333), _t(30334)] + [s.get('name', 'Unknown') for s in filtered]
        preselect = [i + 2 for i, sid in enumerate(ids) if sid in hidden_items]
        result = dialog.multiselect(_t(30528, cat_name), names, preselect=preselect)
        if result is None:
            return
        if 0 in result:
            preselect = list(range(2, len(names)))
            result = dialog.multiselect(_t(30528, cat_name), names, preselect=preselect)
            if result is None:
                return
        if 1 in result:
            result = dialog.multiselect(_t(30528, cat_name), names, preselect=[])
            if result is None:
                return
        real_result = [i - 2 for i in result if i >= 2] if result else []
        cat_ids = set(ids)
        new_hidden = (hidden_items - cat_ids) | ({ids[i] for i in real_result} if real_result else set())
        _set_hidden_items(stype, new_hidden, pnum)
        hidden_count = len(result) if result else 0
        xbmcgui.Dialog().notification('XStream Player', _t(30312, hidden_count, cat_name))


def hide_all_subcats(stype, action, profile_num=None):
    """Hide or unhide all subcategories at once."""
    pnum = profile_num or pm.active
    creds = _get_credentials()
    url = creds.get('xtream_url', '')
    user = creds.get('xtream_username', '')
    pwd = creds.get('xtream_password', '')
    cats = _get_cached_xtream_categories(url, user, pwd, stype)
    if not cats:
        return
    if action == 'hide':
        new_hidden = {str(c.get('category_id', '')) for c in cats}
        _set_hidden_subcats(stype, new_hidden, pnum)
        xbmcgui.Dialog().notification('XStream Player', _t(30313, len(new_hidden)))
    else:
        _set_hidden_subcats(stype, set(), pnum)
        xbmcgui.Dialog().notification('XStream Player', _t(30137))
    if pnum == pm.active and stype == 'live':
        _sync_pvr_force()
    xbmc.executebuiltin('Container.Refresh')


def _get_recent_live():
    """Get recently watched live channels."""
    return watch_history.get_all('live')[:10]


def _render_recent_items(items, stype):
    """Render recently watched items."""
    import datetime
    
    # For series: group by series_id + season_num, keep most recent per group
    if stype == 'series':
        seen_groups = {}  # (series_id, season_num) -> entry
        for entry in items:
            series_id = entry.get('series_id')
            season_num = entry.get('season_num')
            if series_id and season_num:
                key = (series_id, season_num)
                # Keep the most recent entry for this series+season
                if key not in seen_groups or entry.get('timestamp', 0) > seen_groups[key].get('timestamp', 0):
                    seen_groups[key] = entry
        # Render grouped series entries
        for (series_id, season_num), entry in seen_groups.items():
            name = entry.get('name', '')
            icon = entry.get('icon', '')
            ts = entry.get('timestamp', 0)
            when = datetime.datetime.fromtimestamp(ts).strftime('%d/%m %H:%M') if ts else ''
            # Extract series name (remove episode info if present)
            series_name = name
            if ' S' in name and 'E' in name:
                # Try to extract base series name (e.g., "Breaking Bad S01E05" -> "Breaking Bad")
                parts = name.rsplit(' S', 1)
                if parts:
                    series_name = parts[0]
            label = _t(30540, series_name, season_num)
            if when:
                label += f'  [COLOR gray]({when})[/COLOR]'
            li = xbmcgui.ListItem(label=label)
            if icon:
                li.setArt({'icon': icon, 'thumb': icon})
            _prepare_playback_item(li)
            q = {'mode': 'xtream_season', 'series_id': series_id, 'season_num': season_num}
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=build_url(q), listitem=li, isFolder=True)
        return
    
    # For movies/live: render individual entries
    for entry in items:
        name = entry.get('name', '')
        url = entry.get('url', '')
        icon = entry.get('icon', '')
        ts = entry.get('timestamp', 0)
        when = datetime.datetime.fromtimestamp(ts).strftime('%d/%m %H:%M') if ts else ''
        label = f'{name}  [COLOR gray]({when})[/COLOR]' if when else name
        li = xbmcgui.ListItem(label=label)
        if icon:
            li.setArt({'icon': icon, 'thumb': icon})
        li.setProperty('IsPlayable', 'true')
        _prepare_playback_item(li)
        q = {'mode': 'play_stream', 'url': url, 'name': name, 'icon': icon, 'stype': stype}
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=build_url(q), listitem=li, isFolder=False)


def live_menu():
    creds = _get_credentials()
    xtream_url = creds.get('xtream_url', '')
    m3u_url = creds.get('m3u_url', '')
    _log(f'live_menu: xtream_url={bool(xtream_url)}, m3u_url={bool(m3u_url)}')

    if not xtream_url and not m3u_url:
        li = xbmcgui.ListItem(label=_t(30240))
        xbmcplugin.addDirectoryItem(handle=addon_handle, url='', listitem=li, isFolder=False)

        xbmcplugin.endOfDirectory(addon_handle)
        return

    # Add Recently Watched folder at top
    if addon.getSetting('show_section_history') == 'true':
        recent_live = _get_recent_live()
        if recent_live:
            li = xbmcgui.ListItem(label='[COLOR yellow]{0}[/COLOR]'.format(_t(30230)))
            li.setArt({'icon': 'DefaultAddonPVRClient.png'})
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=build_url({'mode': 'recently_watched_by_type', 'stype': 'live'}), listitem=li, isFolder=True)

    if xtream_url and not m3u_url:
        li = xbmcgui.ListItem(label='[COLOR yellow]{0}[/COLOR]'.format(_t(30007)))
        li.setArt({'icon': 'DefaultAddonsSearch.png'})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=build_url({'mode': 'search_global'}), listitem=li, isFolder=True)
        if addon.getSetting('show_section_favorites') == 'true':
            li = xbmcgui.ListItem(label='[COLOR gold]{0}[/COLOR]'.format(_t(30231)))
            li.setArt({'icon': 'DefaultFolder.png'})
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=build_url({'mode': 'favorites_menu'}), listitem=li, isFolder=True)
        xtream_categories('live')
        return
    if m3u_url and not xtream_url:
        li = xbmcgui.ListItem(label='[COLOR yellow]{0}[/COLOR]'.format(_t(30007)))
        li.setArt({'icon': 'DefaultAddonsSearch.png'})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=build_url({'mode': 'search_global'}), listitem=li, isFolder=True)
        if addon.getSetting('show_section_favorites') == 'true':
            li = xbmcgui.ListItem(label='[COLOR gold]{0}[/COLOR]'.format(_t(30231)))
            li.setArt({'icon': 'DefaultFolder.png'})
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=build_url({'mode': 'favorites_menu'}), listitem=li, isFolder=True)
        m3u_live()
        return

    li = xbmcgui.ListItem(label='[COLOR yellow]{0}[/COLOR]'.format(_t(30007)))
    li.setArt({'icon': 'DefaultAddonsSearch.png'})
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=build_url({'mode': 'search_global'}), listitem=li, isFolder=True)
    li = xbmcgui.ListItem(label='[COLOR gold]{0}[/COLOR]'.format(_t(30231)))
    li.setArt({'icon': 'DefaultFolder.png'})
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=build_url({'mode': 'favorites_menu'}), listitem=li, isFolder=True)
    li = xbmcgui.ListItem(label=_t(30270))
    li.setArt({'icon': 'DefaultFolder.png'})
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=build_url({'mode': 'xtream_categories', 'type': 'live'}), listitem=li, isFolder=True)

    li = xbmcgui.ListItem(label=_t(30271))
    li.setArt({'icon': 'DefaultFolder.png'})
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=build_url({'mode': 'm3u_live'}), listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(addon_handle)


def m3u_live():
    creds = _get_credentials()
    channels = _get_cached_m3u_channels(creds.get('m3u_url', ''))
    groups = {}
    for ch in channels:
        grp = ch.get('group') or 'General'
        groups.setdefault(grp, []).append(ch)
    for grp in sorted(groups.keys()):
        li = xbmcgui.ListItem(label=grp)
        li.setArt({'icon': 'DefaultFolder.png'})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=build_url({'mode': 'm3u_group', 'group': grp}), listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(addon_handle)


def _epg_enabled():
    return addon.getSetting('show_epg_live').lower() == 'true'


def m3u_group(group):
    xbmcplugin.setContent(addon_handle, 'livetv')
    show_epg = _epg_enabled()
    epg = EPG(addon)
    if show_epg:
        epg.load()
    creds = _get_credentials()
    channels = _get_cached_m3u_channels(creds.get('m3u_url', ''))
    for ch in channels:
        if (ch.get('group') or 'General') != group:
            continue
        name = ch.get('name', 'Unknown')
        tvg_id = ch.get('tvg_id') or name
        url = ch.get('url')
        item_id = ch.get('tvg_id') or url
        plot, display_name, current_title = _make_epg_info(epg, tvg_id, name) if show_epg else ('', name, '')
        li = xbmcgui.ListItem(label=display_name)
        info_tag = li.getVideoInfoTag()
        info_tag.setMediaType('video')
        info_tag.setTitle(current_title or name)
        info_tag.setPlot(plot)
        if ch.get('logo'):
            li.setArt({'icon': ch['logo'], 'thumb': ch['logo']})
        li.setProperty('IsPlayable', 'true')
        li.setProperty('IsLiveTV', '1')
        li.setProperty('previewpath', _live_url(url))
        _prepare_playback_item(li)
        _set_live_props(li)
        live_play_url = _live_url(url)
        ctx = _build_fav_ctx(item_id, name, 'live', ch.get('logo', ''), url, tvg_id)
        li.addContextMenuItems(ctx)
        q = {'mode': 'play_stream', 'url': live_play_url, 'name': name, 'title': current_title or name, 'plot': plot, 'icon': ch.get('logo', '')}
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=build_url(q), listitem=li, isFolder=False)
    _apply_sort()

    xbmcplugin.endOfDirectory(addon_handle)


def _is_adult_locked(stype):
    """Check if adult content for this type requires PIN."""
    if addon.getSetting('enable_parental_control').lower() != 'true':
        return False
    lock_map = {'live': 'parental_lock_adult_live', 'movie': 'parental_lock_adult_movies', 'series': 'parental_lock_adult_series'}
    key = lock_map.get(stype, '')
    return key and addon.getSetting(key).lower() == 'true'


def xtream_categories(stype):
    creds = _get_credentials()
    url = creds.get('xtream_url', '')
    user = creds.get('xtream_username', '')
    pwd = creds.get('xtream_password', '')
    cats = _get_cached_xtream_categories(url, user, pwd, stype)
    hide_adult = addon.getSetting('hide_adult_categories').lower() == 'true'
    adult_locked = _is_adult_locked(stype)
    hidden_subcats = _get_hidden_subcats(stype)
    for c in cats:
        name = c.get('category_name', 'Unknown')
        cat_id = str(c.get('category_id', ''))
        if cat_id in hidden_subcats:
            continue
        if hide_adult and _is_adult_category(name):
            continue
        is_adult = _is_adult_category(name)
        count = len(_get_cached_xtream_streams(url, user, pwd, stype, c.get('category_id', '')))
        display = f"{name}  [COLOR gray]({count})[/COLOR]"
        if is_adult and adult_locked:
            display = f'[COLOR red]🔒[/COLOR] {display}'
        li = xbmcgui.ListItem(label=display)
        li.setArt({'icon': 'DefaultFolder.png'})
        q = {'mode': 'xtream_streams', 'type': stype, 'cat_id': c.get('category_id', ''), 'adult': '1' if is_adult else '0'}
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=build_url(q), listitem=li, isFolder=True)
    _apply_sort()
    xbmcplugin.endOfDirectory(addon_handle)


def xtream_streams(stype, cat_id, page=1, adult='0'):
    if adult == '1' and _is_adult_locked(stype):
        if not _check_pin('Adult Content'):
            xbmcplugin.endOfDirectory(addon_handle, succeeded=False)
            return
    creds = _get_credentials()
    url = creds.get('xtream_url', '')
    user = creds.get('xtream_username', '')
    pwd = creds.get('xtream_password', '')
    streams = _get_cached_xtream_streams(url, user, pwd, stype, cat_id)
    hidden_items = _get_hidden_items(stype)
    if hidden_items:
        streams = [s for s in streams if str(s.get('stream_id', '')) not in hidden_items]
    epg = EPG(addon)
    epg.load()

    # Show all channels for live TV, paginate movies/series
    if stype == 'live':
        per_page = len(streams)
    else:
        per_page = 50
    total = len(streams)
    start = (page - 1) * per_page
    end = start + per_page
    page_streams = streams[start:end]

    if stype == 'movie' and url and user and pwd:
        _prefetch_vod_info_batch(page_streams, url, user, pwd)

    if stype == 'live':
        xbmcplugin.setContent(addon_handle, 'livetv')
    show_epg = _epg_enabled() if stype == 'live' else False
    for s in page_streams:
        name = s.get('name', 'Unknown')
        if stype == 'live':
            sid = str(s.get('stream_id', ''))
            epg_id = s.get('epg_channel_id') or sid
            play_url = _live_url(IPTV.build_xtream_stream_url(url, user, pwd, s, 'live'))
            plot, display_name, current_title = _make_epg_info(epg, epg_id, name) if show_epg else ('', name, '')
            li = xbmcgui.ListItem(label=display_name)
            info_tag = li.getVideoInfoTag()
            info_tag.setMediaType('video')
            info_tag.setTitle(current_title or name)
            info_tag.setPlot(plot)
            if s.get('stream_icon'):
                li.setArt({'icon': s['stream_icon'], 'thumb': s['stream_icon']})
            li.setProperty('IsPlayable', 'true')
            li.setProperty('IsLiveTV', '1')
            li.setProperty('previewpath', play_url)
            _prepare_playback_item(li)
            _set_live_props(li)
            ctx = _build_fav_ctx(sid, name, 'live', s.get('stream_icon', ''), play_url, epg_id)
            li.addContextMenuItems(ctx)
            q = {'mode': 'play_stream', 'url': play_url, 'name': name, 'title': current_title or name, 'plot': plot, 'icon': s.get('stream_icon', '')}
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=build_url(q), listitem=li, isFolder=False)
        elif stype == 'movie':
            sid = str(s.get('stream_id', ''))
            play_url = IPTV.build_xtream_stream_url(url, user, pwd, s, 'movie')
            info = _enrich_movie_info(s, url, user, pwd)
            # Check if movie was marked as watched
            is_watched = watched_movies.is_watched(sid)
            label = f'[COLOR green]✓[/COLOR] {name}' if is_watched else name
            li = xbmcgui.ListItem(label=label)
            info_tag = li.getVideoInfoTag()
            info_tag.setMediaType('movie')
            info_tag.setTitle(name)
            # Format plot with year, genre, cast at top
            header_parts = []
            if info.get('year'):
                header_parts.append(info['year'])
            if info.get('genre'):
                header_parts.append(info['genre'])
            header = " | ".join(header_parts)
            plot = info['plot']
            if info.get('cast'):
                cast_names = ', '.join([a['name'] for a in info['cast'][:5]])
                if header:
                    plot = f"{header}\n[COLOR gray]Cast: {cast_names}[/COLOR]\n\n{plot}"
                else:
                    plot = f"[COLOR gray]Cast: {cast_names}[/COLOR]\n\n{plot}"
            elif header:
                plot = f"{header}\n\n{plot}"
            info_tag.setPlot(plot)
            if info['rating']:
                try:
                    info_tag.setRating(float(info['rating']))
                except Exception:
                    pass
            if info['year']:
                try:
                    info_tag.setYear(int(info['year']))
                except Exception:
                    pass
            # Set cast for Kodi info dialog
            if info.get('cast'):
                cast_list = []
                for idx, actor in enumerate(info['cast'][:10]):  # Top 10 actors
                    name = actor.get('name', '')
                    role = actor.get('role', '')
                    thumbnail = actor.get('thumbnail', '')
                    cast_list.append(xbmc.Actor(name, role, idx, thumbnail))
                if cast_list:
                    info_tag.setCast(cast_list)
            art = {}
            if info['poster_url']:
                art['icon'] = info['poster_url']
                art['thumb'] = info['poster_url']
                art['poster'] = info['poster_url']
            li.setArt(art)
            li.setProperty('IsPlayable', 'true')
            _prepare_playback_item(li)
            ctx = _build_fav_ctx(sid, name, 'movie', info.get('poster_url', ''), play_url)
            # Simple mark as watched/unwatched for movies - use stream_id
            ctx.append((_t(30250), f'RunPlugin({build_url({"mode": "toggle_movie_watched", "stream_id": sid, "action": "watched"})})'))
            ctx.append((_t(30251), f'RunPlugin({build_url({"mode": "toggle_movie_watched", "stream_id": sid, "action": "unwatched"})})'))
            li.addContextMenuItems(ctx)
            q = {'mode': 'play_stream', 'url': play_url, 'name': name, 'icon': info.get('poster_url', ''), 'stype': 'movie'}
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=build_url(q), listitem=li, isFolder=False)
        elif stype == 'series':
            sid = str(s.get('series_id', ''))
            info = _enrich_series_info(s, url, user, pwd)
            # Check if any episodes in series are watched
            total_watched = watched_db.get_watched_count(sid)
            is_watched = total_watched > 0
            label = f'[COLOR green]✓[/COLOR] {name}' if is_watched else name
            q = {'mode': 'xtream_series', 'series_id': sid}
            series_url = build_url(q)
            li = xbmcgui.ListItem(label=label)
            info_tag = li.getVideoInfoTag()
            info_tag.setMediaType('tvshow')
            info_tag.setTitle(name)
            # Format plot with year, genre, cast at top
            header_parts = []
            if info.get('year'):
                header_parts.append(info['year'])
            if info.get('genre'):
                header_parts.append(info['genre'])
            header = " | ".join(header_parts)
            plot = info['plot']
            if info.get('cast'):
                cast_names = ', '.join([a['name'] for a in info['cast'][:5]])
                if header:
                    plot = f"{header}\n[COLOR gray]Cast: {cast_names}[/COLOR]\n\n{plot}"
                else:
                    plot = f"[COLOR gray]Cast: {cast_names}[/COLOR]\n\n{plot}"
            elif header:
                plot = f"{header}\n\n{plot}"
            info_tag.setPlot(plot)
            if info['rating']:
                try:
                    info_tag.setRating(float(info['rating']))
                except Exception:
                    pass
            if info['year']:
                try:
                    info_tag.setYear(int(info['year']))
                except Exception:
                    pass
            # Set cast for Kodi info dialog
            if info.get('cast'):
                cast_list = []
                for idx, actor in enumerate(info['cast'][:10]):  # Top 10 actors
                    name = actor.get('name', '')
                    role = actor.get('role', '')
                    thumbnail = actor.get('thumbnail', '')
                    cast_list.append(xbmc.Actor(name, role, idx, thumbnail))
                if cast_list:
                    info_tag.setCast(cast_list)
            art = {}
            if info['poster_url']:
                art['icon'] = info['poster_url']
                art['thumb'] = info['poster_url']
                art['poster'] = info['poster_url']
            li.setArt(art)
            ctx = _build_fav_ctx(sid, name, 'series', info.get('poster_url', ''), series_url)
            # Add series-level watched marking
            ctx.append((_t(30323), f'RunPlugin({build_url({"mode": "toggle_series_watched", "series_id": sid, "action": "watched"})})'))
            ctx.append((_t(30324), f'RunPlugin({build_url({"mode": "toggle_series_watched", "series_id": sid, "action": "unwatched"})})'))
            li.addContextMenuItems(ctx)
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=series_url, listitem=li, isFolder=True)

    if stype in ('movie', 'series') and end < total:
        li = xbmcgui.ListItem(label='[COLOR yellow]{0}[/COLOR]'.format(_t(30232)))
        li.setArt({'icon': 'DefaultFolder.png'})
        q = {'mode': 'xtream_streams', 'type': stype, 'cat_id': cat_id, 'page': page + 1}
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=build_url(q), listitem=li, isFolder=True)

    _apply_sort()
    xbmcplugin.endOfDirectory(addon_handle)


def xtream_series(series_id):
    creds = _get_credentials()
    url = creds.get('xtream_url', '')
    user = creds.get('xtream_username', '')
    pwd = creds.get('xtream_password', '')
    info = IPTV.get_xtream_series_info(url, user, pwd, series_id)
    episodes = info.get('episodes', {})
    for season_num in sorted(episodes.keys(), key=lambda x: (0, int(x)) if str(x).isdigit() else (1, str(x))):
        total_eps = len(episodes[season_num])
        watched_count = watched_db.get_watched_count(series_id, season_num)
        all_watched = watched_count >= total_eps
        label = _t(30541, season_num)
        if all_watched:
            label = f'[COLOR green]✓[/COLOR] {label}'
        elif watched_count > 0:
            label += f'  [COLOR gray]({watched_count}/{total_eps})[/COLOR]'
        li = xbmcgui.ListItem(label=label)
        li.setArt({'icon': 'DefaultFolder.png'})
        # Context menu: season level - only mark season
        ctx_items = []
        if all_watched:
            ctx_items.append((_t(30324), f'RunPlugin({build_url({"mode": "toggle_season_watched", "series_id": series_id, "season_num": season_num, "action": "unwatched"})})'))
        else:
            ctx_items.append((_t(30323), f'RunPlugin({build_url({"mode": "toggle_season_watched", "series_id": series_id, "season_num": season_num, "action": "watched"})})'))
        li.addContextMenuItems(ctx_items)
        q = {'mode': 'xtream_season', 'series_id': series_id, 'season_num': season_num}
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=build_url(q), listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(addon_handle)


def xtream_season(series_id, season_num):
    creds = _get_credentials()
    url = creds.get('xtream_url', '')
    user = creds.get('xtream_username', '')
    pwd = creds.get('xtream_password', '')
    info = IPTV.get_xtream_series_info(url, user, pwd, series_id)
    eps = info.get('episodes', {}).get(season_num, [])
    for ep in eps:
        ep_id = str(ep.get('id', ''))
        title = ep.get('title') or _t(30542, ep.get('episode_num', '?'))
        watched = watched_db.is_watched(series_id, season_num, ep_id)
        label = f'[COLOR green]✓[/COLOR] {title}' if watched else title
        li = xbmcgui.ListItem(label=label)
        info_tag = li.getVideoInfoTag()
        info_tag.setMediaType('episode')
        info_tag.setTitle(title)
        info_tag.setPlot(ep.get('info', {}).get('plot', ''))
        if watched:
            info_tag.setPlaycount(1)
        movie_image = ep.get('info', {}).get('movie_image')
        if movie_image:
            li.setArt({'icon': movie_image, 'thumb': movie_image})
        li.setProperty('IsPlayable', 'true')
        _prepare_playback_item(li)
        play_url = IPTV.build_xtream_stream_url(url, user, pwd, ep, 'series')
        # Simple context menu for episode watched status
        ctx = []
        if watched:
            ctx.append((_t(30324), f'RunPlugin({build_url({"mode": "toggle_watched", "series_id": series_id, "season_num": season_num, "ep_id": ep_id, "action": "unwatched"})})'))
        else:
            ctx.append((_t(30323), f'RunPlugin({build_url({"mode": "toggle_watched", "series_id": series_id, "season_num": season_num, "ep_id": ep_id, "action": "watched"})})'))
        li.addContextMenuItems(ctx)
        q = {'mode': 'play_stream', 'url': play_url, 'name': title, 'icon': movie_image or '',
             'stype': 'series', 'series_id': series_id, 'season_num': season_num, 'ep_id': ep_id}
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=build_url(q), listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(addon_handle)


def movies_menu():
    creds = _get_credentials()
    xtream_url = creds.get('xtream_url', '')
    if xtream_url:
        # Add Recently Watched Movies folder
        if addon.getSetting('show_section_history') == 'true':
            recent_movies = watch_history.get_all('movie')
            if recent_movies:
                li = xbmcgui.ListItem(label='[COLOR gold]{0}[/COLOR]'.format(_t(30230)))
                li.setArt({'icon': 'DefaultMovies.png'})
                xbmcplugin.addDirectoryItem(handle=addon_handle, url=build_url({'mode': 'recently_watched_by_type', 'stype': 'movie'}), listitem=li, isFolder=True)
        
        li = xbmcgui.ListItem(label='[COLOR yellow]{0}[/COLOR]'.format(_t(30007)))
        li.setArt({'icon': 'DefaultAddonsSearch.png'})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=build_url({'mode': 'search_global'}), listitem=li, isFolder=True)
        if addon.getSetting('show_section_favorites') == 'true':
            li = xbmcgui.ListItem(label='[COLOR gold]{0}[/COLOR]'.format(_t(30231)))
            li.setArt({'icon': 'DefaultFolder.png'})
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=build_url({'mode': 'favorites_menu'}), listitem=li, isFolder=True)
        xtream_categories('movie')
    else:
        li = xbmcgui.ListItem(label=_t(30241))
        xbmcplugin.addDirectoryItem(handle=addon_handle, url='', listitem=li, isFolder=False)

        xbmcplugin.endOfDirectory(addon_handle)


def series_menu():
    creds = _get_credentials()
    xtream_url = creds.get('xtream_url', '')
    if xtream_url:
        # Add Recently Watched Series folder
        if addon.getSetting('show_section_history') == 'true':
            recent_series = watch_history.get_all('series')
            if recent_series:
                li = xbmcgui.ListItem(label='[COLOR gold]{0}[/COLOR]'.format(_t(30230)))
                li.setArt({'icon': 'DefaultTVShows.png'})
                xbmcplugin.addDirectoryItem(handle=addon_handle, url=build_url({'mode': 'recently_watched_by_type', 'stype': 'series'}), listitem=li, isFolder=True)
        
        li = xbmcgui.ListItem(label='[COLOR yellow]{0}[/COLOR]'.format(_t(30007)))
        li.setArt({'icon': 'DefaultAddonsSearch.png'})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=build_url({'mode': 'search_global'}), listitem=li, isFolder=True)
        if addon.getSetting('show_section_favorites') == 'true':
            li = xbmcgui.ListItem(label='[COLOR gold]{0}[/COLOR]'.format(_t(30231)))
            li.setArt({'icon': 'DefaultFolder.png'})
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=build_url({'mode': 'favorites_menu'}), listitem=li, isFolder=True)
        xtream_categories('series')
    else:
        li = xbmcgui.ListItem(label=_t(30242))
        xbmcplugin.addDirectoryItem(handle=addon_handle, url='', listitem=li, isFolder=False)

        xbmcplugin.endOfDirectory(addon_handle)


def replay_menu():
    creds = _get_credentials()
    url = creds.get('xtream_url', '')
    user = creds.get('xtream_username', '')
    pwd = creds.get('xtream_password', '')
    streams = _get_cached_xtream_streams(url, user, pwd, 'live')
    epg = EPG(addon)
    epg.load()

    for s in streams:
        if not s.get('tv_archive') and not s.get('catchup'):
            continue
        name = s.get('name', 'Unknown')
        li = xbmcgui.ListItem(label=name)
        if s.get('stream_icon'):
            li.setArt({'icon': s['stream_icon'], 'thumb': s['stream_icon']})
        q = {
            'mode': 'replay_channel',
            'stream_id': str(s.get('stream_id', '')),
            'epg_id': s.get('epg_channel_id') or str(s.get('stream_id', '')),
            'name': name
        }
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=build_url(q), listitem=li, isFolder=True)
    _apply_sort()

    xbmcplugin.endOfDirectory(addon_handle)


def replay_channel(stream_id, epg_id, name=''):
    epg = EPG(addon)
    epg.load()
    try:
        days_back = int(addon.getSetting('replay_days') or '7')
    except ValueError:
        days_back = 7
    programs = epg.get_programs_for_channel(epg_id, channel_name=name, days_back=days_back)

    if not programs:
        import datetime
        now = datetime.datetime.now()
        for hours_back in range(1, 25):
            start = now - datetime.timedelta(hours=hours_back)
            start_fmt = start.strftime('%Y-%m-%d:%H-%M')
            title = f"{start.strftime('%d/%m %H:%M')} - {_t(30543)}"
            li = xbmcgui.ListItem(label=title)
            info_tag = li.getVideoInfoTag()
            info_tag.setMediaType('video')
            info_tag.setTitle(title)
            li.setProperty('IsPlayable', 'true')
            _prepare_playback_item(li)
            q = {
                'mode': 'replay_play',
                'stream_id': stream_id,
                'start': start_fmt,
                'duration': 3600
            }
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=build_url(q), listitem=li, isFolder=False)
    else:
        for prog in programs:
            title = f"{prog['start_str']} - {prog['title']}"
            li = xbmcgui.ListItem(label=title)
            info_tag = li.getVideoInfoTag()
            info_tag.setMediaType('video')
            info_tag.setTitle(prog['title'])
            info_tag.setPlot(prog.get('desc', ''))
            li.setProperty('IsPlayable', 'true')
            _prepare_playback_item(li)
            q = {
                'mode': 'replay_play',
                'stream_id': stream_id,
                'start': prog['start_timestamp'],
                'duration': prog['duration_sec']
            }
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=build_url(q), listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(addon_handle)


def replay_play(stream_id, start, duration):
    creds = _get_credentials()
    url = creds.get('xtream_url', '')
    user = creds.get('xtream_username', '')
    pwd = creds.get('xtream_password', '')
    try:
        duration = int(duration)
    except (ValueError, TypeError):
        duration = 3600
    play_url = IPTV.build_catchup_url(url, user, pwd, stream_id, start, duration)
    li = xbmcgui.ListItem(path=play_url)
    li.setProperty('IsPlayable', 'true')
    info_tag = li.getVideoInfoTag()
    info_tag.setMediaType('video')
    info_tag.setTitle(f'Replay {stream_id}')
    _prepare_playback_item(li)
    xbmcplugin.setResolvedUrl(addon_handle, True, listitem=li)


def _search_history_path():
    profile = xbmcvfs.translatePath(addon.getAddonInfo('profile'))
    return os.path.join(profile, 'search_history.json')


def _load_search_history():
    try:
        with open(_search_history_path(), 'r', encoding='utf-8') as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        return []


def _save_search_history(history):
    history_path = _search_history_path()
    tmp_file = history_path + '.tmp'
    with open(tmp_file, 'w', encoding='utf-8') as f:
        json.dump(history[:10], f, ensure_ascii=False)
    os.replace(tmp_file, history_path)


def search_global(query=None):
    if query is None:
        history = _load_search_history()
        if history:
            options = [_t(30544)] + history
            idx = xbmcgui.Dialog().select(_t(30140), options)
            if idx < 0:
                return
            if idx == 0:
                kb = xbmcgui.Dialog().input(_t(30140), type=xbmcgui.INPUT_ALPHANUM)
                if not kb:
                    return
                query = kb
            else:
                query = history[idx - 1]
        else:
            kb = xbmcgui.Dialog().input(_t(30140), type=xbmcgui.INPUT_ALPHANUM)
            if not kb:
                return
            query = kb
    # Save to search history
    history = _load_search_history()
    if query in history:
        history.remove(query)
    history.insert(0, query)
    _save_search_history(history)
    unified_search(query)


def unified_search(query):
    creds = _get_credentials()
    url = creds.get('xtream_url', '')
    user = creds.get('xtream_username', '')
    pwd = creds.get('xtream_password', '')
    qlower = query.lower()
    epg = EPG(addon)
    epg.load()
    show_epg = _epg_enabled()
    hide_adult = addon.getSetting('hide_adult_categories').lower() == 'true'

    live_streams = _get_cached_xtream_streams(url, user, pwd, 'live')
    live_results = [s for s in live_streams if qlower in s.get('name', '').lower()]
    if hide_adult:
        live_results = [s for s in live_results if not _is_adult_category(s.get('name', '') + ' ' + s.get('category_name', ''))]
    if live_results:
        li = xbmcgui.ListItem(label='[COLOR yellow]{0}[/COLOR]'.format(_t(30220)))
        xbmcplugin.addDirectoryItem(handle=addon_handle, url='', listitem=li, isFolder=False)
        for s in live_results:
            name = s.get('name', 'Unknown')
            sid = str(s.get('stream_id', ''))
            epg_id = s.get('epg_channel_id') or sid
            play_url = _live_url(IPTV.build_xtream_stream_url(url, user, pwd, s, 'live'))
            plot, display_name, current_title = _make_epg_info(epg, epg_id, name) if show_epg else ('', name, '')
            li = xbmcgui.ListItem(label=display_name)
            info_tag = li.getVideoInfoTag()
            info_tag.setMediaType('video')
            info_tag.setTitle(current_title or name)
            info_tag.setPlot(plot)
            if s.get('stream_icon'):
                li.setArt({'icon': s['stream_icon'], 'thumb': s['stream_icon'], 'poster': s['stream_icon']})
            li.setProperty('IsPlayable', 'true')
            _prepare_playback_item(li)
            _set_live_props(li)
            ctx = _build_fav_ctx(sid, name, 'live', s.get('stream_icon', ''), play_url, epg_id)
            li.addContextMenuItems(ctx)
            q = {'mode': 'play_stream', 'url': play_url, 'name': name, 'title': current_title or name, 'plot': plot, 'icon': s.get('stream_icon', '')}
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=build_url(q), listitem=li, isFolder=False)

    movie_streams = _get_cached_xtream_streams(url, user, pwd, 'movie')
    movie_results = [s for s in movie_streams if qlower in s.get('name', '').lower()]
    if hide_adult:
        movie_results = [s for s in movie_results if not _is_adult_category(s.get('name', '') + ' ' + s.get('category_name', ''))]
    if movie_results:
        li = xbmcgui.ListItem(label='[COLOR yellow]{0}[/COLOR]'.format(_t(30221)))
        xbmcplugin.addDirectoryItem(handle=addon_handle, url='', listitem=li, isFolder=False)
        for s in movie_results:
            name = s.get('name', 'Unknown')
            sid = str(s.get('stream_id', ''))
            play_url = IPTV.build_xtream_stream_url(url, user, pwd, s, 'movie')
            info = _enrich_movie_info(s, url, user, pwd)
            li = xbmcgui.ListItem(label=name)
            info_tag = li.getVideoInfoTag()
            info_tag.setMediaType('movie')
            info_tag.setTitle(name)
            # Format plot with year, genre, cast at top
            header_parts = []
            if info.get('year'):
                header_parts.append(info['year'])
            if info.get('genre'):
                header_parts.append(info['genre'])
            header = " | ".join(header_parts)
            plot = info['plot']
            if info.get('cast'):
                cast_names = ', '.join([a['name'] for a in info['cast'][:5]])
                if header:
                    plot = f"{header}\n[COLOR gray]Cast: {cast_names}[/COLOR]\n\n{plot}"
                else:
                    plot = f"[COLOR gray]Cast: {cast_names}[/COLOR]\n\n{plot}"
            elif header:
                plot = f"{header}\n\n{plot}"
            info_tag.setPlot(plot)
            if info['rating']:
                try:
                    info_tag.setRating(float(info['rating']))
                except Exception:
                    pass
            if info['year']:
                try:
                    info_tag.setYear(int(info['year']))
                except Exception:
                    pass
            # Set cast for Kodi info dialog
            if info.get('cast'):
                cast_list = []
                for idx, actor in enumerate(info['cast'][:10]):  # Top 10 actors
                    name = actor.get('name', '')
                    role = actor.get('role', '')
                    thumbnail = actor.get('thumbnail', '')
                    cast_list.append(xbmc.Actor(name, role, idx, thumbnail))
                if cast_list:
                    info_tag.setCast(cast_list)
            art = {}
            if info['poster_url']:
                art['icon'] = info['poster_url']
                art['thumb'] = info['poster_url']
                art['poster'] = info['poster_url']
            li.setArt(art)
            li.setProperty('IsPlayable', 'true')
            _prepare_playback_item(li)
            ctx = _build_fav_ctx(sid, name, 'movie', info.get('poster_url', ''), play_url)
            li.addContextMenuItems(ctx)
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=play_url, listitem=li, isFolder=False)

    series_streams = _get_cached_xtream_streams(url, user, pwd, 'series')
    series_results = [s for s in series_streams if qlower in s.get('name', '').lower()]
    if hide_adult:
        series_results = [s for s in series_results if not _is_adult_category(s.get('name', '') + ' ' + s.get('category_name', ''))]
    if series_results:
        li = xbmcgui.ListItem(label='[COLOR yellow]{0}[/COLOR]'.format(_t(30222)))
        xbmcplugin.addDirectoryItem(handle=addon_handle, url='', listitem=li, isFolder=False)
        for s in series_results:
            name = s.get('name', 'Unknown')
            sid = str(s.get('series_id', ''))
            series_url = build_url({'mode': 'xtream_series', 'series_id': sid})
            li = xbmcgui.ListItem(label=name)
            info_tag = li.getVideoInfoTag()
            info_tag.setMediaType('tvshow')
            info_tag.setTitle(name)
            info_tag.setPlot(s.get('plot', ''))
            if s.get('cover'):
                li.setArt({'icon': s['cover'], 'thumb': s['cover']})
            ctx = _build_fav_ctx(sid, name, 'series', s.get('cover', ''), series_url)
            li.addContextMenuItems(ctx)
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=series_url, listitem=li, isFolder=True)

    if not live_results and not movie_results and not series_results:
        li = xbmcgui.ListItem(label=_t(30223))
        xbmcplugin.addDirectoryItem(handle=addon_handle, url='', listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(addon_handle)


def search_m3u(query=None):
    if query is None:
        kb = xbmcgui.Dialog().input(_t(30141), type=xbmcgui.INPUT_ALPHANUM)
        if not kb:
            return
        query = kb
    show_epg = _epg_enabled()
    epg = EPG(addon)
    if show_epg:
        epg.load()
    creds = _get_credentials()
    channels = _get_cached_m3u_channels(creds.get('m3u_url', ''))
    qlower = query.lower()
    for ch in channels:
        if qlower not in ch.get('name', '').lower() and qlower not in ch.get('group', '').lower():
            continue
        name = ch.get('name', 'Unknown')
        tvg_id = ch.get('tvg_id') or name
        url = ch.get('url')
        item_id = ch.get('tvg_id') or url
        plot, display_name, current_title = _make_epg_info(epg, tvg_id, name) if show_epg else ('', name, '')
        li = xbmcgui.ListItem(label=display_name)
        info_tag = li.getVideoInfoTag()
        info_tag.setMediaType('video')
        info_tag.setTitle(current_title or name)
        info_tag.setPlot(plot)
        if ch.get('logo'):
            li.setArt({'icon': ch['logo'], 'thumb': ch['logo']})
        li.setProperty('IsPlayable', 'true')
        _prepare_playback_item(li)
        _set_live_props(li)
        ctx = _build_fav_ctx(item_id, name, 'live', ch.get('logo', ''), url, tvg_id)
        li.addContextMenuItems(ctx)
        q = {'mode': 'play_stream', 'url': url, 'name': name, 'title': current_title or name, 'plot': plot, 'icon': ch.get('logo', '')}
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=build_url(q), listitem=li, isFolder=False)
    _apply_sort()

    xbmcplugin.endOfDirectory(addon_handle)


def search_xtream(stype, query=None):
    if query is None:
        kb = xbmcgui.Dialog().input(_t(30142).format(stype.capitalize()), type=xbmcgui.INPUT_ALPHANUM)
        if not kb:
            return
        query = kb
    creds = _get_credentials()
    url = creds.get('xtream_url', '')
    user = creds.get('xtream_username', '')
    pwd = creds.get('xtream_password', '')
    streams = _get_cached_xtream_streams(url, user, pwd, stype)
    qlower = query.lower()
    filtered = [s for s in streams if qlower in s.get('name', '').lower()]
    show_epg = _epg_enabled() if stype == 'live' else False
    epg = EPG(addon)
    if show_epg:
        epg.load()

    for s in filtered:
        name = s.get('name', 'Unknown')
        if stype == 'live':
            sid = str(s.get('stream_id', ''))
            epg_id = s.get('epg_channel_id') or sid
            play_url = _live_url(IPTV.build_xtream_stream_url(url, user, pwd, s, 'live'))
            plot, display_name, current_title = _make_epg_info(epg, epg_id, name) if show_epg else ('', name, '')
            li = xbmcgui.ListItem(label=display_name)
            info_tag = li.getVideoInfoTag()
            info_tag.setMediaType('video')
            info_tag.setTitle(current_title or name)
            info_tag.setPlot(plot)
            if s.get('stream_icon'):
                li.setArt({'icon': s['stream_icon'], 'thumb': s['stream_icon'], 'poster': s['stream_icon']})
            li.setProperty('IsPlayable', 'true')
            _prepare_playback_item(li)
            _set_live_props(li)
            ctx = _build_fav_ctx(sid, name, 'live', s.get('stream_icon', ''), play_url, epg_id)
            li.addContextMenuItems(ctx)
            q = {'mode': 'play_stream', 'url': play_url, 'name': name, 'title': current_title or name, 'plot': plot, 'icon': s.get('stream_icon', '')}
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=build_url(q), listitem=li, isFolder=False)
        elif stype == 'movie':
            sid = str(s.get('stream_id', ''))
            play_url = IPTV.build_xtream_stream_url(url, user, pwd, s, 'movie')
            li = xbmcgui.ListItem(label=name)
            info_tag = li.getVideoInfoTag()
            info_tag.setMediaType('movie')
            info_tag.setTitle(name)
            info_tag.setPlot(s.get('plot', ''))
            if s.get('stream_icon'):
                li.setArt({'icon': s['stream_icon'], 'thumb': s['stream_icon']})
            li.setProperty('IsPlayable', 'true')
            _prepare_playback_item(li)
            ctx = _build_fav_ctx(sid, name, 'movie', s.get('stream_icon', ''), play_url)
            li.addContextMenuItems(ctx)
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=play_url, listitem=li, isFolder=False)
        elif stype == 'series':
            sid = str(s.get('series_id', ''))
            q = {'mode': 'xtream_series', 'series_id': sid}
            series_url = build_url(q)
            li = xbmcgui.ListItem(label=name)
            info_tag = li.getVideoInfoTag()
            info_tag.setMediaType('tvshow')
            info_tag.setTitle(name)
            info_tag.setPlot(s.get('plot', ''))
            if s.get('cover'):
                li.setArt({'icon': s['cover'], 'thumb': s['cover']})
            ctx = _build_fav_ctx(sid, name, 'series', s.get('cover', ''), series_url)
            li.addContextMenuItems(ctx)
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=series_url, listitem=li, isFolder=True)
    _apply_sort()

    xbmcplugin.endOfDirectory(addon_handle)


def _fav_render_items(items, source_folder=None):
    """Render a list of favorite items with context menus."""
    hide_adult = addon.getSetting('hide_adult_categories').lower() == 'true'
    if hide_adult:
        items = [i for i in items if not _is_adult_category(i.get('name', '') + ' ' + i.get('category_name', ''))]
    has_live = any(i.get('stype', 'live') == 'live' for i in items)
    epg = None
    if has_live and _epg_enabled():
        epg = EPG(addon)
        epg.load()
    for item in items:
        stype = item.get('stype', 'live')
        name = item.get('name', 'Unknown')
        li = xbmcgui.ListItem(label=name)
        info_tag = li.getVideoInfoTag()
        info_tag.setMediaType('video')
        info_tag.setTitle(name)
        if item.get('icon'):
            li.setArt({'icon': item['icon'], 'thumb': item['icon']})
        li.setProperty('IsPlayable', 'true')
        _prepare_playback_item(li)
        plot = ''
        current_title = ''
        if stype == 'live':
            _set_live_props(li)
            plot, display_name, current_title = _make_epg_info(epg, item.get('epg_id', ''), name) if epg else ('', name, '')
            info_tag = li.getVideoInfoTag()
            info_tag.setMediaType('video')
            info_tag.setTitle(current_title or name)
            info_tag.setPlot(plot)
        # Remove: if inside a specific folder, remove from that folder; otherwise remove from all
        remove_folder = source_folder or '__all__'
        ctx = [
            (_t(30545),
             f'RunPlugin({build_url({"mode": "fav_remove", "id": item.get("id"), "folder": remove_folder})})'),
        ]
        if source_folder:
            ctx.append((_t(30216),
                f'RunPlugin({build_url({"mode": "fav_move", "id": item.get("id"), "name": name, "stype": stype, "icon": item.get("icon", ""), "url": item.get("url", ""), "epg_id": item.get("epg_id", ""), "from_folder": source_folder})})'))
        # Add "Add to [group]" for each custom group
        for gname in fav.get_folders():
            if gname == 'Favorites':
                continue
            ctx.append((_t(30215).format(gname),
                f'RunPlugin({build_url({"mode": "toggle_fav", "id": item.get("id"), "name": name, "stype": stype, "icon": item.get("icon", ""), "url": item.get("url", ""), "epg_id": item.get("epg_id", ""), "folder": gname})})'))
        li.addContextMenuItems(ctx)
        if stype == 'live':
            q = {'mode': 'play_stream', 'url': item.get('url', ''), 'name': name, 'title': current_title or name, 'plot': plot, 'icon': item.get('icon', '')}
            item_url = build_url(q)
        else:
            item_url = item.get('url')
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=item_url, listitem=li, isFolder=stype == 'series')


def favorites_menu(folder=None, stype_filter=None):
    stype_labels = {'live': 'Live TV', 'movie': 'Movies', 'series': 'Series'}
    stype_icons = {'live': 'DefaultAddonPVRClient.png', 'movie': 'DefaultMovies.png', 'series': 'DefaultTVShows.png'}
    folders = fav.get_folders()
    custom_folders = [f for f in folders if f != 'Favorites']

    # Level 1: top-level — show custom groups + New Group
    if folder is None and stype_filter is None:
        for gname in custom_folders:
            count = len(fav.get_all(gname))
            li = xbmcgui.ListItem(label=f'{gname}  [COLOR gray]({count})[/COLOR]')
            li.setArt({'icon': 'DefaultFavourites.png'})
            ctx_items = [
                (_t(30320), f'RunPlugin({build_url({"mode": "fav_rename_folder", "folder": gname})})'),
                (_t(30325), f'RunPlugin({build_url({"mode": "export_favorites", "folder": gname})})'),
                (_t(30321), f'RunPlugin({build_url({"mode": "fav_delete_folder", "folder": gname})})'),
            ]
            li.addContextMenuItems(ctx_items)
            q = {'mode': 'favorites_menu', 'folder': gname}
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=build_url(q), listitem=li, isFolder=True)
        # + New Favorites Group
        li = xbmcgui.ListItem(label='[COLOR yellow]{0}[/COLOR]'.format(_t(30210)))
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=build_url({'mode': 'fav_new_folder'}), listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(addon_handle)
        return

    # Inside a custom group — show stype subgroups or items directly
    if folder and stype_filter is None:
        items = fav.get_all(folder)
        stypes_present = {}
        for item in items:
            st = item.get('stype', 'live')
            stypes_present[st] = stypes_present.get(st, 0) + 1
        if not stypes_present:
            li = xbmcgui.ListItem(label='[COLOR gray]{0}[/COLOR]'.format(_t(30211)))
            xbmcplugin.addDirectoryItem(handle=addon_handle, url='', listitem=li, isFolder=False)
            xbmcplugin.endOfDirectory(addon_handle)
            return
        if len(stypes_present) == 1:
            stype_filter = list(stypes_present.keys())[0]
        else:
            for st, count in stypes_present.items():
                label = f'{stype_labels.get(st, st)}  [COLOR gray]({count})[/COLOR]'
                li = xbmcgui.ListItem(label=label)
                li.setArt({'icon': stype_icons.get(st, 'DefaultFolder.png')})
                q = {'mode': 'favorites_menu', 'folder': folder, 'stype_filter': st}
                xbmcplugin.addDirectoryItem(handle=addon_handle, url=build_url(q), listitem=li, isFolder=True)
            xbmcplugin.endOfDirectory(addon_handle)
            return

    # Items in custom group filtered by stype
    if folder and stype_filter:
        items = [i for i in fav.get_all(folder) if i.get('stype') == stype_filter]
        if not items:
            li = xbmcgui.ListItem(label='[COLOR gray]{0}[/COLOR]'.format(_t(30212)))
            xbmcplugin.addDirectoryItem(handle=addon_handle, url='', listitem=li, isFolder=False)
            xbmcplugin.endOfDirectory(addon_handle)
            return
        _fav_render_items(items, source_folder=folder)
        xbmcplugin.endOfDirectory(addon_handle)
        return


def toggle_favorite(item_id, name, stype, icon, url, epg_id='', folder='Favorites'):
    item = {'id': item_id, 'name': name, 'stype': stype, 'icon': icon, 'url': url, 'epg_id': epg_id}
    if fav.is_favorite(item_id, folder):
        fav.remove(item_id, folder)
        xbmcgui.Dialog().notification('XStream Player', _t(30085).format(folder))
        xbmc.executebuiltin('Container.Refresh')
        return
    fav.add(item, folder)
    xbmcgui.Dialog().notification('XStream Player', _t(30084).format(folder))
    xbmc.executebuiltin('Container.Refresh')


def switch_profile():
    current = addon.getSetting('active_profile') or '1'
    profiles = []
    for i in range(1, 11):
        name = addon.getSetting(f'profile_{i}_name') or _t(30390, i)
        marker = ' [COLOR green]*[/COLOR]' if str(i) == current else ''
        profiles.append((str(i), f'{name}{marker}'))
    labels = [p[1] for p in profiles]
    idx = xbmcgui.Dialog().select(_t(30017), labels)
    if idx < 0:
        return
    selected = profiles[idx][0]
    if selected == current:
        xbmcgui.Dialog().notification('XStream Player', _t(30121))
        return
    addon.setSetting('active_profile', selected)
    _cache_clear_all()
    xbmcgui.Dialog().notification('XStream Player', _t(30307, profiles[idx][1].replace("[COLOR green]*[/COLOR]", "").strip()))
    xbmc.executebuiltin('Container.Refresh')


def view_changelog():
    """Show full changelog from addon folder."""
    changelog_path = os.path.join(xbmcvfs.translatePath(addon.getAddonInfo('path')), 'CHANGELOG.md')
    try:
        with open(changelog_path, 'r', encoding='utf-8') as f:
            changelog = f.read()
        current_version = addon.getAddonInfo('version')
        xbmcgui.Dialog().textviewer(_t(30341), changelog)
    except Exception:
        xbmcgui.Dialog().notification('XStream Player', _t(30103))


def test_connection():
    creds = _get_credentials()
    url = creds.get('xtream_url', '')
    user = creds.get('xtream_username', '')
    pwd = creds.get('xtream_password', '')
    if not url or not user or not pwd:
        xbmcgui.Dialog().ok('XStream Player', _t(30056))
        return
    pd = xbmcgui.DialogProgress()
    pd.create('XStream Player', _t(30288))
    info = IPTV.validate_xtream(url, user, pwd)
    pd.close()
    if info is None:
        xbmcgui.Dialog().ok(_t(30031), _t(30054) + '\n' + _t(30055))
        return
    import datetime
    exp = info.get('exp_date', '')
    exp_str = _t(30546)
    if exp:
        try:
            exp_dt = datetime.datetime.fromtimestamp(int(exp))
            exp_str = exp_dt.strftime('%Y-%m-%d %H:%M')
            days_left = (exp_dt - datetime.datetime.now()).days
            exp_str += _t(30420, days_left)
        except (ValueError, TypeError):
            exp_str = str(exp)
    msg = (f'{_t(30421)}: {info.get("status", _t(30428))}\n'
           f'{_t(30422)}: {exp_str}\n'
           f'{_t(30423)}: {info.get("max_connections", "N/A")} | {_t(30424)}: {info.get("active_cons", "0")}')
    xbmcgui.Dialog().ok(_t(30033), msg)


def account_info():
    creds = _get_credentials()
    url = creds.get('xtream_url', '')
    user = creds.get('xtream_username', '')
    pwd = creds.get('xtream_password', '')
    if not url or not user or not pwd:
        xbmcgui.Dialog().ok('XStream Player', _t(30056))
        return
    info = IPTV.validate_xtream(url, user, pwd)
    if info is None:
        xbmcgui.Dialog().ok('XStream Player', _t(30123))
        return
    import datetime
    exp = info.get('exp_date', '')
    exp_str = _t(30546)
    if exp:
        try:
            exp_dt = datetime.datetime.fromtimestamp(int(exp))
            exp_str = exp_dt.strftime('%Y-%m-%d %H:%M')
        except (ValueError, TypeError):
            exp_str = str(exp)
    lines = [
        f'{_t(30421)}: {info.get("status", _t(30429))}',
        f'{_t(30422)}: {exp_str}',
        f'{_t(30423)}: {info.get("max_connections", "N/A")}',
        f'{_t(30425)}: {info.get("active_cons", "0")}',
        f'{_t(30426)}: {_t(30430) if info.get("is_trial") == "1" else _t(30431)}',
        f'{_t(30427)}: {info.get("server_url", "N/A")}',
    ]
    xbmcgui.Dialog().textviewer(_t(30019), '\n'.join(lines))


def _validate_settings():
    """Validate settings after user closes settings dialog."""
    from iptv import _validate_url
    creds = _get_credentials()
    xt_url = creds.get('xtream_url', '')
    m3u_url = creds.get('m3u', '')
    # Validate URLs
    for label, url in [(_t(30566), xt_url), (_t(30567), m3u_url)]:
        if not url:
            continue
        validated = _validate_url(url, allow_http=True)
        if not validated:
            xbmcgui.Dialog().notification('XStream Player',
                _t(30308, label),
                xbmcgui.NOTIFICATION_WARNING, 5000)
        elif url.startswith('http://') and addon.getSetting('warn_http').lower() == 'true':
            xbmcgui.Dialog().notification('XStream Player',
                _t(30309, label),
                xbmcgui.NOTIFICATION_WARNING, 3000)
            _log(f'Warning: {label} uses insecure HTTP connection')


def settings():
    xbmcplugin.endOfDirectory(addon_handle, succeeded=False)
    if not _check_pin('Settings'):
        return
    # Store active profile info before opening
    active_profile_before = pm.active
    creds_before = _get_credentials()
    _log(f'Settings opened. Active profile: {active_profile_before}, URL: {creds_before.get("xtream_url","")[:20]}...')
    addon.openSettings()
    _validate_settings()
    # Re-read active profile (may have changed)
    pm_after = ProfileManager(addon)
    active_profile_after = pm_after.active
    creds_after = pm_after.get_credentials()
    # Check if active profile changed (either profile number or credentials)
    profile_switched = active_profile_before != active_profile_after
    creds_changed = (
        creds_before.get('xtream_url') != creds_after.get('xtream_url') or
        creds_before.get('xtream_username') != creds_after.get('xtream_username') or
        creds_before.get('xtream_password') != creds_after.get('xtream_password') or
        creds_before.get('m3u_url') != creds_after.get('m3u_url') or
        creds_before.get('epg_url') != creds_after.get('epg_url')
    )
    active_changed = profile_switched or creds_changed
    _log(f'Settings closed. Profile switched: {profile_switched}, Creds changed: {creds_changed}')
    # Only prompt if active profile was modified or switched
    if active_changed:
        profile_name = creds_after.get('name', _t(30390, active_profile_after))
        _log(f'Showing refresh prompt for profile: {profile_name}')
        choice = xbmcgui.Dialog().yesno(
            'XStream Player',
            _t(30440, profile_name)
        )
        if choice:
            refresh_data()
    # Force refresh of main menu to show addon group changes immediately
    xbmc.executebuiltin('Container.Update(plugin://plugin.video.xstream-player/,replace)')





def _make_epg_info(epg, channel_id, channel_name):
    if not _epg_enabled():
        return '', channel_name, ''
    matched_id = epg._find_channel_id(channel_id, channel_name)
    if not matched_id:
        return '', channel_name, ''
    now = time.time()
    upcoming = []
    current_title = ''
    current_desc = ''
    for prog in epg.programs[matched_id]:
        start = epg._apply_offset(_parse_xmltv_time(prog['start']))
        stop = epg._apply_offset(_parse_xmltv_time(prog['stop']))
        if start and start > now:
            upcoming.append(prog)
        elif start and start <= now < stop:
            upcoming.insert(0, prog)
            current_title = prog['title']
            current_desc = prog.get('desc', '')
    upcoming = upcoming[:8]
    if current_title:
        if current_desc:
            clean_desc = current_desc.replace('\n', ' ').replace('\r', ' ').strip()
            if len(clean_desc) > 150:
                clean_desc = clean_desc[:147] + '...'
            display_name = f"[B]{channel_name}[/B]  [COLOR yellow]{current_title}[/COLOR]: [COLOR gray]{clean_desc}[/COLOR]"
        else:
            display_name = f"[B]{channel_name}[/B]  [COLOR yellow]{current_title}[/COLOR]"
    else:
        display_name = f"[B]{channel_name}[/B]"
    plot_lines = []
    for idx, prog in enumerate(upcoming):
        t = _parse_xmltv_time(prog['start'])
        stop_t = _parse_xmltv_time(prog['stop'])
        is_current = (idx == 0 and t and stop_t and t <= now < stop_t)
        if t:
            time_str = time.strftime('%H:%M', time.localtime(t))
            line = f"{time_str} - {prog['title']}"
        else:
            line = prog['title']
        if is_current:
            line = f"[B][COLOR yellow]> {line}[/COLOR][/B]"
        plot_lines.append(line)
    plot = '\n'.join(plot_lines)
    _log(f'EPG info for {channel_name}: found {len(upcoming)} programs, current={current_title}')
    return plot, display_name, current_title


def backup_settings():
    import zipfile
    profile_path = xbmcvfs.translatePath(addon.getAddonInfo('profile'))
    backup_path = os.path.join(profile_path, 'xtream_m3u_addon_backup.zip')
    try:
        with zipfile.ZipFile(backup_path, 'w', zipfile.ZIP_DEFLATED) as zf:
            settings_file = os.path.join(profile_path, 'settings.xml')
            if os.path.exists(settings_file):
                zf.write(settings_file, 'settings.xml')
            fav_file = os.path.join(profile_path, 'favorites.json')
            if os.path.exists(fav_file):
                zf.write(fav_file, 'favorites.json')
            for fname in os.listdir(profile_path):
                if fname.startswith('epg_cache_profile_') or fname.startswith('refresh_'):
                    fpath = os.path.join(profile_path, fname)
                    zf.write(fpath, fname)
        xbmcgui.Dialog().notification('XStream Player', _t(30089))
    except Exception as e:
        _log(f'Backup failed: {e}')
        xbmcgui.Dialog().notification('XStream Player', _t(30090))


def restore_settings():
    import zipfile
    dialog = xbmcgui.Dialog()
    zip_path = dialog.browse(1, _t(30337), 'files', '.zip', False, False, '')
    if not zip_path:
        return
    profile_path = xbmcvfs.translatePath(addon.getAddonInfo('profile'))
    try:
        with zipfile.ZipFile(zip_path, 'r') as zf:
            for name in zf.namelist():
                # Security: normalize and validate path to prevent directory traversal
                target = os.path.normpath(os.path.join(profile_path, name))
                if not target.startswith(os.path.normpath(profile_path)):
                    _log(f'Skipped unsafe backup entry (traversal attempt): {name}')
                    continue
                # Only allow expected backup files
                allowed_prefixes = ('settings.xml', 'favorites', 'epg_cache_', 'refresh_', 
                                   'category_prefs.json', 'watch_history_', 'resume_points_',
                                   'watched_', 'hidden_', 'pvr_favorites', 'ag_', 'main_menu_order_')
                basename = os.path.basename(name)
                if not any(basename.startswith(p) for p in allowed_prefixes):
                    _log(f'Skipped unexpected backup entry: {name}')
                    continue
                zf.extract(name, profile_path)
        xbmcgui.Dialog().notification('XStream Player', _t(30091))
    except Exception as e:
        _log(f'Restore failed: {e}')
        xbmcgui.Dialog().notification('XStream Player', _t(30092))


def clear_cache_menu():
    active_name = addon.getSetting(f'profile_{pm.active}_name') or _t(30390, pm.active)
    options = [
        _t(30500, active_name),
        _t(30501),
        _t(30502),
        _t(30503),
        _t(30504),
        _t(30505),
        _t(30506),
    ]
    dialog = xbmcgui.Dialog()
    choice = dialog.select(_t(30153), options)
    if choice < 0:
        return
    if choice == 0:
        clear_all_caches()
    elif choice == 1:
        clear_epg_cache()
    elif choice == 2:
        clear_channel_cache()
    elif choice == 3:
        clear_tmdb_cache()
    elif choice == 4:
        if dialog.yesno(_t(30042), _t(30076)):
            watch_history.clear()
            dialog.notification('XStream Player', _t(30253))
    elif choice == 5:
        clear_watched_content_menu()
    elif choice == 6:
        clear_kodi_cache()


def clear_watched_content_menu():
    """Clear watched content by type."""
    active_name = addon.getSetting(f'profile_{pm.active}_name') or _t(30390, pm.active)
    options = [
        _t(30507, active_name),
        _t(30508),
        _t(30509),
        _t(30510),
    ]
    dialog = xbmcgui.Dialog()
    choice = dialog.select(_t(30154), options)
    if choice < 0:
        return
    if choice == 0:
        if dialog.yesno(_t(30042), _t(30077, active_name)):
            watched_movies.clear()
            watched_db.clear()
            dialog.notification('XStream Player', _t(30254))
    elif choice == 1:
        if dialog.yesno(_t(30042), _t(30078)):
            watched_movies.clear()
            dialog.notification('XStream Player', _t(30255))
    elif choice == 2:
        if dialog.yesno(_t(30042), _t(30079)):
            watched_db.clear()
            dialog.notification('XStream Player', _t(30256))
    elif choice == 3:
        if dialog.yesno(_t(30042), _t(30282)):
            watch_history.clear_by_type('live')
            dialog.notification('XStream Player', _t(30257))


def clear_all_caches():
    count = _cache_clear_all_profiles()
    profile_path = xbmcvfs.translatePath(addon.getAddonInfo('profile'))
    for fname in os.listdir(profile_path):
        if fname.startswith('epg_cache_profile_') or fname == 'epg_cache.json' or fname == 'view_prefs.json':
            try:
                os.remove(os.path.join(profile_path, fname))
                count += 1
            except Exception:
                pass
    xbmcgui.Dialog().notification('XStream Player', _t(30258, count))


def clear_epg_cache():
    profile_path = xbmcvfs.translatePath(addon.getAddonInfo('profile'))
    count = 0
    for fname in os.listdir(profile_path):
        if fname.startswith('epg_cache_profile_') or fname == 'epg_cache.json' or fname.startswith('data_cache_epg'):
            try:
                os.remove(os.path.join(profile_path, fname))
                count += 1
            except Exception:
                pass
    xbmcgui.Dialog().notification('XStream Player', _t(30303, count))


def clear_channel_cache():
    profile_path = xbmcvfs.translatePath(addon.getAddonInfo('profile'))
    count = 0
    for fname in os.listdir(profile_path):
        if (fname.startswith('data_cache_xtream_') or fname.startswith('data_cache_m3u')
                or fname.startswith('vod_info_')):
            try:
                os.remove(os.path.join(profile_path, fname))
                count += 1
            except Exception:
                pass
    xbmcgui.Dialog().notification('XStream Player', _t(30304, count))


def clear_tmdb_cache():
    profile_path = xbmcvfs.translatePath(addon.getAddonInfo('profile'))
    count = 0
    for fname in os.listdir(profile_path):
        if fname.startswith('data_cache_tmdb_') or fname.startswith('tmdb_'):
            try:
                os.remove(os.path.join(profile_path, fname))
                count += 1
            except Exception:
                pass
    xbmcgui.Dialog().notification('XStream Player', _t(30305, count))


def clear_kodi_cache():
    """Clear Kodi's system cache (thumbnails, temp files, etc.)"""
    dialog = xbmcgui.Dialog()
    if not dialog.yesno(_t(30044), _t(30283)):
        return
    
    count = 0
    # Clear thumbnails cache
    thumbs_path = xbmcvfs.translatePath('special://thumbnails/')
    if os.path.exists(thumbs_path):
        for root, dirs, files in os.walk(thumbs_path):
            for f in files:
                try:
                    os.remove(os.path.join(root, f))
                    count += 1
                except Exception:
                    pass

    # Clear temp folder
    temp_path = xbmcvfs.translatePath('special://temp/')
    if os.path.exists(temp_path):
        for fname in os.listdir(temp_path):
            fpath = os.path.join(temp_path, fname)
            try:
                if os.path.isfile(fpath):
                    os.remove(fpath)
                    count += 1
                elif os.path.isdir(fpath):
                    import shutil
                    shutil.rmtree(fpath)
                    count += 1
            except Exception:
                pass

    # Clear cache folder
    cache_path = xbmcvfs.translatePath('special://cache/')
    if os.path.exists(cache_path):
        for fname in os.listdir(cache_path):
            fpath = os.path.join(cache_path, fname)
            try:
                if os.path.isfile(fpath):
                    os.remove(fpath)
                    count += 1
            except Exception:
                pass

    dialog.notification('XStream Player', _t(30177, count))


def recently_watched_by_type(stype):
    """Show recently watched items for a specific type."""
    items = watch_history.get_all(stype)
    if not items:
        li = xbmcgui.ListItem(label=_t(30243))
        xbmcplugin.addDirectoryItem(handle=addon_handle, url='', listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(addon_handle)
        return
    _render_recent_items(items, stype)
    xbmcplugin.endOfDirectory(addon_handle)


# Note: EPG cache can be cleared via Settings → EPG and guide → Clear EPG database

mode = args.get('mode', [None])[0]

if mode is None:
    main_menu()
elif mode == 'live_menu':
    live_menu()
elif mode == 'm3u_live':
    m3u_live()
elif mode == 'm3u_group':
    m3u_group(args.get('group', [''])[0])
elif mode == 'xtream_categories':
    xtream_categories(args.get('type', ['live'])[0])
elif mode == 'xtream_streams':
    try:
        page = int(args.get('page', ['1'])[0])
    except ValueError:
        page = 1
    xtream_streams(args.get('type', ['live'])[0], args.get('cat_id', [''])[0], page, args.get('adult', ['0'])[0])
elif mode == 'xtream_series':
    xtream_series(args.get('series_id', [''])[0])
elif mode == 'xtream_season':
    xtream_season(args.get('series_id', [''])[0], args.get('season_num', [''])[0])
elif mode == 'movies_menu':
    movies_menu()
elif mode == 'series_menu':
    series_menu()
elif mode == 'replay_menu':
    replay_menu()
elif mode == 'replay_channel':
    replay_channel(args.get('stream_id', [''])[0], args.get('epg_id', [''])[0], args.get('name', [''])[0])
elif mode == 'replay_play':
    replay_play(args.get('stream_id', [''])[0], args.get('start', [''])[0], args.get('duration', [''])[0])
elif mode == 'search_global':
    search_global(args.get('query', [None])[0])
elif mode == 'search_m3u':
    search_m3u(args.get('query', [None])[0])
elif mode == 'search_xtream':
    search_xtream(args.get('type', ['live'])[0], args.get('query', [None])[0])

elif mode == 'favorites_menu':
    favorites_menu(args.get('folder', [None])[0], args.get('stype_filter', [None])[0])
elif mode == 'fav_new_folder':
    name = xbmcgui.Dialog().input(_t(30143))
    if name:
        fav.create_folder(name)
        xbmcgui.Dialog().notification('XStream Player', _t(30094).format(name))
        xbmc.executebuiltin('Container.Refresh')
elif mode == 'fav_rename_folder':
    fname = args.get('folder', [''])[0]
    if fname:
        new_name = xbmcgui.Dialog().input(_t(30144), default=fname)
        if new_name and new_name != fname:
            fav.rename_folder(fname, new_name)
            xbmcgui.Dialog().notification('XStream Player', _t(30095).format(new_name))
            xbmc.executebuiltin('Container.Refresh')
elif mode == 'fav_delete_folder':
    fname = args.get('folder', [''])[0]
    if fname and fname != 'Favorites':
        if xbmcgui.Dialog().yesno(_t(30038), _t(30066).format(fname)):
            fav.delete_folder(fname)
            xbmcgui.Dialog().notification('XStream Player', _t(30096).format(fname))
            xbmc.executebuiltin('Container.Refresh')
elif mode == 'fav_move':
    item_id = args.get('id', [''])[0]
    from_folder = args.get('from_folder', ['Favorites'])[0]
    folders = [f for f in fav.get_folders() if f != from_folder]
    if not folders:
        xbmcgui.Dialog().notification('XStream Player', _t(30124))
    else:
        idx = xbmcgui.Dialog().select(_t(30145), folders)
        if idx >= 0:
            # Find the item in the source folder
            source_items = fav.get_all(from_folder)
            item_data = next((i for i in source_items if i.get('id') == item_id), None)
            if item_data:
                fav.remove(item_id, from_folder)
                fav.add(item_data, folders[idx])
                xbmcgui.Dialog().notification('XStream Player', _t(30097).format(folders[idx]))
                xbmc.executebuiltin('Container.Refresh')
elif mode == 'export_favorites':
    fname = args.get('folder', [None])[0]
    path = xbmcgui.Dialog().browseSingle(3, _t(30338), 'files')
    if path:
        export_name = f'favorites_{fname}.m3u' if fname else 'favorites.m3u'
        full_path = os.path.join(path, export_name)
        count = fav.export_m3u(full_path, fname)
        xbmcgui.Dialog().notification('XStream Player', _t(30116).format(count))
elif mode == 'fav_remove':
    _fav_item_id = args.get('id', [''])[0]
    _fav_folder = args.get('folder', ['__all__'])[0]
    if _fav_folder == '__all__':
        fav.remove(_fav_item_id)
    else:
        fav.remove(_fav_item_id, _fav_folder)
        xbmcgui.Dialog().notification('XStream Player', _t(30085).format('Favorites'))
    xbmc.executebuiltin('Container.Refresh')
elif mode == 'toggle_fav':
    toggle_favorite(
        args.get('id', [''])[0],
        args.get('name', [''])[0],
        args.get('stype', ['live'])[0],
        args.get('icon', [''])[0],
        args.get('url', [''])[0],
        args.get('epg_id', [''])[0],
        args.get('folder', ['Favorites'])[0]
    )
elif mode == 'refresh_data':
    refresh_data()
elif mode == 'sync_pvr':
    sync_pvr()
elif mode == 'open_pvr':
    open_pvr()
elif mode == 'pvr_favorites_manager':
    pvr_favorites_manager(args.get('group', [None])[0])
elif mode == 'pvr_favs_manage_group':
    pvr_favs_manage_group(args.get('group', ['Favorites'])[0])
elif mode == 'pvr_favs_group_current':
    pvr_favs_group_current(args.get('group', ['Favorites'])[0])
elif mode == 'pvr_favs_group_search':
    pvr_favs_group_search(args.get('group', ['Favorites'])[0])
elif mode == 'pvr_favs_manage_cat':
    pvr_favs_manage_cat(args.get('cat_id', [''])[0], args.get('cat_name', [''])[0], args.get('group', ['Favorites'])[0])
elif mode == 'pvr_favs_new_group':
    dialog = xbmcgui.Dialog()
    name = dialog.input(_t(30147))
    if name:
        groups = _pvr_favs_load_all()
        if name in groups:
            dialog.notification('XStream Player', _t(30125))
        else:
            groups[name] = []
            _pvr_favs_save_all(groups)
            _sync_pvr_favorites()
            dialog.notification('XStream Player', _t(30126, name))
            xbmc.executebuiltin('Container.Refresh')
elif mode == 'pvr_favs_rename_group':
    old_name = args.get('group', [''])[0]
    dialog = xbmcgui.Dialog()
    new_name = dialog.input(_t(30148), default=old_name)
    if new_name and new_name != old_name:
        groups = _pvr_favs_load_all()
        if new_name in groups:
            dialog.notification('XStream Player', _t(30125))
        elif old_name in groups:
            items = groups.pop(old_name)
            groups[new_name] = items
            _pvr_favs_save_all(groups)
            _sync_pvr_favorites()
            dialog.notification('XStream Player', _t(30178, new_name))
            xbmc.executebuiltin('Container.Refresh')
elif mode == 'pvr_favs_delete_group':
    group_name = args.get('group', [''])[0]
    dialog = xbmcgui.Dialog()
    if dialog.yesno(_t(30038), _t(30252, group_name)):
        groups = _pvr_favs_load_all()
        if group_name in groups:
            del groups[group_name]
            _pvr_favs_save_all(groups)
            _sync_pvr_favorites()
            dialog.notification('XStream Player', _t(30179, group_name))
            xbmc.executebuiltin('Container.Refresh')
elif mode == 'pvr_fav_add':
    sid = args.get('stream_id', [''])[0]
    name = args.get('name', [''])[0]
    icon = args.get('icon', [''])[0]
    group = args.get('group', ['Favorites'])[0]
    if _pvr_favs_add({'stream_id': sid, 'name': name, 'stream_icon': icon}, group):
        _sync_pvr_favorites()
        xbmcgui.Dialog().notification('XStream Player', _t(30084).format(group))
        xbmc.executebuiltin('Container.Refresh')
elif mode == 'pvr_fav_remove':
    sid = args.get('stream_id', [''])[0]
    group = args.get('group', ['Favorites'])[0]
    if _pvr_favs_remove(sid, group):
        _sync_pvr_favorites()
        xbmcgui.Dialog().notification('XStream Player', _t(30085).format(group))
        xbmc.executebuiltin('Container.Refresh')
elif mode == 'open_pvr_guide':
    open_pvr_guide()
elif mode == 'tools_menu':
    tools_menu()
elif mode == 'reorder_main_menu':
    reorder_main_menu()

elif mode == 'play_stream':
    play_stream(args.get('url', [''])[0], args.get('name', [''])[0], args.get('title', [''])[0], args.get('plot', [''])[0], args.get('icon', [''])[0], args.get('stype', ['live'])[0],
                args.get('series_id', [''])[0], args.get('season_num', [''])[0], args.get('ep_id', [''])[0])
elif mode == 'toggle_watched':
    s_id = args.get('series_id', [''])[0]
    s_num = args.get('season_num', [''])[0]
    e_id = args.get('ep_id', [''])[0]
    action = args.get('action', ['watched'])[0]
    if action == 'watched':
        watched_db.mark_watched(s_id, s_num, e_id)
        xbmcgui.Dialog().notification('XStream Player', _t(30086))
    else:
        watched_db.mark_unwatched(s_id, s_num, e_id)
        xbmcgui.Dialog().notification('XStream Player', _t(30087))
    xbmc.executebuiltin('Container.Refresh')
elif mode == 'toggle_movie_watched':
    sid = args.get('stream_id', [''])[0]
    action = args.get('action', ['watched'])[0]
    if action == 'watched':
        watched_movies.mark_watched(sid)
        xbmcgui.Dialog().notification('XStream Player', _t(30138))
    else:
        watched_movies.mark_unwatched(sid)
        xbmcgui.Dialog().notification('XStream Player', _t(30139))
    xbmc.executebuiltin('Container.Refresh')
elif mode == 'toggle_season_watched':
    s_id = args.get('series_id', [''])[0]
    s_num = args.get('season_num', [''])[0]
    action = args.get('action', ['watched'])[0]
    # Get all episode IDs for this season
    creds = _get_credentials()
    url = creds.get('xtream_url', '')
    user = creds.get('xtream_username', '')
    pwd = creds.get('xtream_password', '')
    info = IPTV.get_xtream_series_info(url, user, pwd, s_id)
    eps = info.get('episodes', {}).get(s_num, [])
    ep_ids = [ep.get('id') for ep in eps if ep.get('id')]
    if action == 'watched':
        watched_db.mark_season_watched(s_id, s_num, ep_ids)
        xbmcgui.Dialog().notification('XStream Player', _t(30117).format(s_num))
    else:
        watched_db.mark_season_unwatched(s_id, s_num)
        xbmcgui.Dialog().notification('XStream Player', _t(30118).format(s_num))
    xbmc.executebuiltin('Container.Refresh')
elif mode == 'toggle_series_watched':
    s_id = args.get('series_id', [''])[0]
    action = args.get('action', ['watched'])[0]
    creds = _get_credentials()
    url = creds.get('xtream_url', '')
    user = creds.get('xtream_username', '')
    pwd = creds.get('xtream_password', '')
    info = IPTV.get_xtream_series_info(url, user, pwd, s_id)
    episodes = info.get('episodes', {})
    if action == 'watched':
        for season_num, eps in episodes.items():
            ep_ids = [ep.get('id') for ep in eps if ep.get('id')]
            watched_db.mark_season_watched(s_id, season_num, ep_ids)
        xbmcgui.Dialog().notification('XStream Player', _t(30119))
    else:
        watched_db.clear_series(s_id)
        xbmcgui.Dialog().notification('XStream Player', _t(30120))
    xbmc.executebuiltin('Container.Refresh')
elif mode == 'settings':
    settings()
elif mode == 'switch_profile':
    switch_profile()
elif mode == 'view_changelog':
    view_changelog()
elif mode == 'test_connection':
    test_connection()
elif mode == 'account_info':
    account_info()
elif mode == 'clear_history_tool':
    active_name = addon.getSetting(f'profile_{pm.active}_name') or f'Profile {pm.active}'
    if xbmcgui.Dialog().yesno(_t(30034), _t(30065).format(active_name)):
        watch_history.clear()
        resume_db.clear()
        xbmcgui.Dialog().notification('XStream Player', _t(30093).format(active_name))
elif mode == 'check_update':
    from updater import check_and_install_update
    check_and_install_update()
elif mode == 'revert_version':
    from updater import revert_version_menu
    revert_version_menu()
elif mode == 'toggle_setting':
    key = args.get('key', [''])[0]
    if key:
        current = addon.getSetting(key).lower() == 'true'
        addon.setSetting(key, 'false' if current else 'true')
        xbmcgui.Dialog().notification('XStream Player', _t(30306, key.replace("_", " ").title(), _t(30371 if current else 30370)))
        xbmc.executebuiltin('Container.Refresh')
elif mode == 'manage_visible_cats':
    manage_visible_cats()
elif mode == 'hide_categories_menu':
    hide_categories_menu(args.get('pnum', [None])[0])
elif mode == 'manage_content_dialog':
    manage_content_dialog(args.get('stype', ['live'])[0], args.get('pnum', [None])[0])
elif mode == 'hidden_items_all':
    stype = args.get('stype', ['live'])[0]
    pnum = args.get('pnum', [None])[0] or pm.active
    hidden_items = _get_hidden_items(stype, pnum)
    if not hidden_items:
        xbmcgui.Dialog().notification('XStream Player', _t(30075))
    else:
        creds = _get_credentials()
        streams = _get_cached_xtream_streams(creds.get('xtream_url', ''), creds.get('xtream_username', ''), creds.get('xtream_password', ''), stype)
        hidden_streams = [s for s in (streams or []) if str(s.get('stream_id', '')) in hidden_items]
        if not hidden_streams:
            xbmcgui.Dialog().notification('XStream Player', _t(30135))
        else:
            h_names = [s.get('name', 'Unknown') for s in hidden_streams]
            h_ids = [str(s.get('stream_id', '')) for s in hidden_streams]
            preselect = list(range(len(hidden_streams)))
            result = xbmcgui.Dialog().multiselect(_t(30339), h_names, preselect=preselect)
            if result is not None:
                new_hidden = {h_ids[i] for i in result} if result else set()
                orphan_ids = hidden_items - set(h_ids)
                _set_hidden_items(stype, new_hidden | orphan_ids, pnum)
                unhidden = len(hidden_streams) - (len(result) if result else 0)
                if unhidden:
                    xbmcgui.Dialog().notification('XStream Player', _t(30314, unhidden))
                xbmc.executebuiltin('Container.Refresh')
elif mode == 'manage_hidden_subcats':
    manage_hidden_subcats(args.get('stype', ['live'])[0], args.get('pnum', [None])[0])
elif mode == 'hide_subcat_action':
    hide_subcat_action(args.get('stype', ['live'])[0], args.get('cat_id', [''])[0], args.get('cat_name', [''])[0], args.get('pnum', [None])[0])
elif mode == 'hide_all_subcats':
    hide_all_subcats(args.get('stype', ['live'])[0], args.get('action', ['hide'])[0], args.get('pnum', [None])[0])
elif mode == 'backup_settings':
    backup_settings()
elif mode == 'restore_settings':
    restore_settings()
elif mode == 'clear_cache_menu':
    clear_cache_menu()
elif mode == 'clear_all_caches':
    clear_all_caches()
elif mode == 'clear_epg_cache':
    clear_epg_cache()
elif mode == 'reset_pvr_epg_db':
    reset_pvr_epg_db_action()
elif mode == 'clear_channel_cache':
    clear_channel_cache()
elif mode == 'clear_tmdb_cache':
    clear_tmdb_cache()
elif mode == 'force_reload_epg':
    pd = xbmcgui.DialogProgress()
    pd.create('XStream Player', _t(30289))
    EPG(addon).fetch()
    pd.close()
    xbmcgui.Dialog().notification('XStream Player', _t(30280))
elif mode == 'force_reload_pvr':
    pd = xbmcgui.DialogProgress()
    pd.create('XStream Player', _t(30568))
    _sync_pvr_force()
    pd.close()
    xbmcgui.Dialog().notification('XStream Player', _t(30281))
elif mode == 'select_ag_addons':
    select_ag_addons(args.get('group', ['1'])[0])
elif mode == 'open_addon_group':
    open_addon_group(args.get('group', ['1'])[0])
elif mode == 'open_addon':
    addon_id = args.get('addon_id', [''])[0]
    group = args.get('group', [None])[0]
    # If called from a group, check if group still has only 1 addon
    if group:
        addons = _get_group_addons(int(group))
        if len(addons) > 1:
            # Group now has multiple addons, redirect to group list
            open_addon_group(group)
        else:
            # Single addon - end directory then open
            xbmcplugin.endOfDirectory(addon_handle, succeeded=False)
            xbmc.executebuiltin(f'Container.Update(plugin://{addon_id})')
    else:
        xbmcplugin.endOfDirectory(addon_handle, succeeded=False)
        xbmc.executebuiltin(f'Container.Update(plugin://{addon_id})')
elif mode == 'empty_addon_group':
    empty_addon_group(args.get('group', ['1'])[0])
elif mode == 'recently_watched_by_type':
    recently_watched_by_type(args.get('stype', ['movie'])[0])
