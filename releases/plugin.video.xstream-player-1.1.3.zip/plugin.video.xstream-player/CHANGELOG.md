To disable changelog go to Tools/Settings/Update

## V 1.1.3

- Added settings.xml parse cache to reduce I/O on main menu open
- Fixed dead SSRF protection - now validates URLs before all network requests (IP-literal private addresses blocked, hostnames allowed)
- Fixed ZIP path traversal check for Windows-absolute paths (C:\\)
- Fixed update timestamp not saved when user clicks "Install Now"
- PIN codes now stored as SHA-256 hashes with addon-id salt (plaintext migrated on first use)
- Fixed atomic file writes - all JSON cache files now use write-to-temp-then-replace pattern
- Replaced time.sleep() cargo-cult with proper f.flush()/os.fsync() in EPG export
- Fixed false positives in adult category detection using regex word boundaries
- Fixed auto-update on Android devices
- Better error logging for update failures
- EPG database reset added to Settings/EPG. Reset if epg in PVR is not properly shown
- Fixed credentials leak in logs
- Fixed synchronous network calls blocking main menu
- Fixed Android restart after data refresh
- Fixed bootstrap running on every menu click
- Fixed PVR instance configuration for favorites
- Fixed account expiry check flag writing on failure
- Added better error logging (removed silent except pass)
- Fixed bare English strings in startup update dialog (now fully localized)
- Fixed bare except: clause in lang.py for better error handling
