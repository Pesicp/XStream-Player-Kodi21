# -*- coding: utf-8 -*-
"""Self-update system for XStream Player"""
import os
import re
import sys
import json
import time
import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

# GitHub Pages URL where releases are hosted
REPO_URL = 'https://pesicp.github.io/XStream-Player-Kodi21/releases/index.html'
ADDON_ID = 'plugin.video.xstream-player'

def get_addon():
    """Get addon instance"""
    return xbmcaddon.Addon(id=ADDON_ID)

def get_current_version():
    """Get currently installed version"""
    addon = get_addon()
    return addon.getAddonInfo('version')

def fetch_index_html():
    """Fetch index.html from GitHub Pages"""
    try:
        import urllib.request
        import ssl
        # Create SSL context that works on all systems
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        
        req = urllib.request.Request(REPO_URL, headers={'User-Agent': 'Mozilla/5.0'})
        with urllib.request.urlopen(req, context=ctx, timeout=10) as response:
            return response.read().decode('utf-8')
    except Exception as e:
        xbmc.log(f'[XStream Player] Update check failed: {str(e)}', xbmc.LOGERROR)
        return None

def parse_versions(html):
    """Parse all available versions from index.html"""
    if not html:
        return []
    
    # Find all zip links with version numbers
    pattern = r'href="(plugin\.video\.xstream-player-([\d.]+)\.zip)"'
    matches = re.findall(pattern, html)
    
    versions = []
    for filename, version in matches:
        versions.append({
            'version': version,
            'filename': filename,
            'url': f'https://pesicp.github.io/XStream-Player-Kodi21/releases/{filename}'
        })
    
    # Sort by version (highest first)
    def version_key(v):
        parts = v['version'].split('.')
        return [int(p) for p in parts]
    
    versions.sort(key=version_key, reverse=True)
    return versions

def check_for_update(silent=False):
    """Check if update is available
    Returns: (update_available, latest_version, download_url)
    """
    current = get_current_version()
    html = fetch_index_html()
    
    if not html:
        return False, None, None
    
    versions = parse_versions(html)
    if not versions:
        return False, None, None
    
    latest = versions[0]
    latest_version = latest['version']
    
    # Compare versions
    def version_tuple(v):
        return tuple(int(x) for x in v.split('.'))
    
    if version_tuple(latest_version) > version_tuple(current):
        return True, latest_version, latest['url']
    
    # No update available, but return the latest version for display
    return False, latest_version, None

def download_update(url, target_path):
    """Download update zip to temp location"""
    try:
        import urllib.request
        import ssl
        
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        
        req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
        with urllib.request.urlopen(req, context=ctx, timeout=30) as response:
            with open(target_path, 'wb') as f:
                f.write(response.read())
        return True
    except Exception as e:
        xbmc.log(f'[XStream Player] Download failed: {str(e)}', xbmc.LOGERROR)
        return False

def check_and_install_update():
    """Main entry point: Check for update and prompt user"""
    xbmc.log('[XStream Player] Check update started', xbmc.LOGINFO)
    dialog = xbmcgui.Dialog()
    
    try:
        xbmc.log('[XStream Player] Creating progress dialog', xbmc.LOGINFO)
        # Show progress
        progress = xbmcgui.DialogProgress()
        progress.create('XStream Player', 'Checking for updates...')
        
        xbmc.log('[XStream Player] Checking for update', xbmc.LOGINFO)
        update_available, new_version, url = check_for_update(silent=True)
        xbmc.log(f'[XStream Player] Update check result: available={update_available}, version={new_version}', xbmc.LOGINFO)
        
        progress.close()
        
        if not update_available:
            if new_version is None:
                dialog.ok('XStream Player', 'Update check failed.\n\nPlease check your internet connection.')
            else:
                dialog.ok('XStream Player', 'No available updates.')
            return
        
        # Ask user to update
        current = get_current_version()
        result = dialog.yesno(
            'Update Available',
            f'New version found!\n\nCurrent: {current}\nLatest: {new_version}\n\nInstall now?'
        )
        
        if not result:
            return
        
        # Download
        progress = xbmcgui.DialogProgress()
        progress.create('XStream Player', f'Downloading version {new_version}...')
        
        import tempfile
        temp_dir = tempfile.gettempdir()
        zip_path = os.path.join(temp_dir, f'{ADDON_ID}-{new_version}.zip')
        
        success = download_update(url, zip_path)
        progress.close()
        
        if not success:
            dialog.notification('XStream Player', 'Download failed', xbmcgui.NOTIFICATION_ERROR)
            return
        
        # Install
        progress = xbmcgui.DialogProgress()
        progress.create('XStream Player', 'Installing update...')
        
        # Extract zip directly to addons folder (silent install)
        import zipfile
        addon_path = xbmcvfs.translatePath('special://home/addons/')
        try:
            with zipfile.ZipFile(zip_path, 'r') as zip_ref:
                zip_ref.extractall(addon_path)
            # Force Kodi to reload the addon
            xbmc.executebuiltin('UpdateLocalAddons')
        except Exception as e:
            xbmc.log(f'[XStream Player] Extract failed: {str(e)}', xbmc.LOGERROR)
            progress.close()
            dialog.notification('XStream Player', 'Install failed', xbmcgui.NOTIFICATION_ERROR)
            return
        
        progress.close()
        
        # Update version setting so user sees new version in settings
        addon = get_addon()
        addon.setSetting('current_version_display', new_version)
        
        # Ask to restart
        restart = dialog.yesno(
            'Update Complete',
            f'Version {new_version} installed successfully!\n\nRelaunch Kodi now?',
            nolabel='Later',
            yeslabel='Restart Now'
        )
        
        if restart:
            xbmc.executebuiltin('RestartApp')
    
        xbmc.log('[XStream Player] Update check completed successfully', xbmc.LOGINFO)
    
    except Exception as e:
        xbmc.log(f'[XStream Player] Update ERROR: {str(e)}', xbmc.LOGERROR)
        import traceback
        xbmc.log(f'[XStream Player] Traceback: {traceback.format_exc()}', xbmc.LOGERROR)
        dialog.ok('XStream Player', 'Update check failed.\n\nPlease try again later.')

def silent_check_on_startup():
    """Background check on startup (if enabled in settings)"""
    addon = get_addon()
    check_interval = addon.getSetting('update_check_interval')
    
    # Check if auto-check is disabled
    if check_interval == 'Never':
        return
    
    # For "On Startup", always check (handled by caller)
    # For other intervals, check if enough time passed
    last_check = addon.getSetting('last_update_check')
    today = time.strftime('%Y-%m-%d')
    
    if check_interval == 'Daily':
        if last_check == today:
            return  # Already checked today
    elif check_interval == 'Weekly':
        if last_check:
            last_time = time.mktime(time.strptime(last_check, '%Y-%m-%d'))
            now_time = time.mktime(time.strptime(today, '%Y-%m-%d'))
            if (now_time - last_time) < (7 * 24 * 60 * 60):  # Less than 7 days
                return
    elif check_interval == 'Monthly':
        if last_check:
            last_time = time.mktime(time.strptime(last_check, '%Y-%m-%d'))
            now_time = time.mktime(time.strptime(today, '%Y-%m-%d'))
            if (now_time - last_time) < (30 * 24 * 60 * 60):  # Less than 30 days
                return
    # "On Startup" always proceeds here
    
    # Do silent check
    update_available, new_version, url = check_for_update(silent=True)
    
    if update_available:
        # Show dialog with Install Now / Later options
        current = get_current_version()
        result = xbmcgui.Dialog().yesno(
            'Update Available',
            f'A new version of XStream Player is available!\n\nCurrent: {current}\nLatest: {new_version}\n\nInstall now?',
            nolabel='Later',
            yeslabel='Install Now'
        )
        
        if result:
            # User clicked Install Now - run update check
            check_and_install_update()
        else:
            # User clicked Later - just save that we found an update
            addon.setSetting('update_available', 'true')
            addon.setSetting('update_version', new_version)
    
    # Save last check date
    addon.setSetting('last_update_check', today)

def fetch_all_versions_from_github():
    """Fetch all versions from GitHub API"""
    try:
        import urllib.request
        import ssl
        import json
        
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        
        url = 'https://api.github.com/repos/Pesicp/XStream-Player-Kodi21/contents/releases'
        req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
        
        with urllib.request.urlopen(req, context=ctx, timeout=10) as response:
            data = json.loads(response.read().decode('utf-8'))
        
        versions = []
        for item in data:
            name = item.get('name', '')
            match = re.match(r'plugin\.video\.xstream-player-([\d.]+)\.zip', name)
            if match:
                versions.append(match.group(1))
        
        # Sort by version (highest first)
        def version_key(v):
            parts = v.split('.')
            return [int(p) for p in parts]
        
        versions.sort(key=version_key, reverse=True)
        return versions
        
    except Exception as e:
        xbmc.log(f'[XStream Player] Failed to fetch versions from GitHub: {str(e)}', xbmc.LOGERROR)
        return []

def get_available_versions():
    """Get list of all available versions for revert"""
    return fetch_all_versions_from_github()

def revert_to_version(version):
    """Revert to specific older version"""
    # Build download URL directly
    filename = f'plugin.video.xstream-player-{version}.zip'
    url = f'https://raw.githubusercontent.com/Pesicp/XStream-Player-Kodi21/main/releases/{filename}'
    
    dialog = xbmcgui.Dialog()
    result = dialog.yesno(
        'Revert Version',
        f'Downgrade to version {version}?\n\nThis will replace your current installation.'
    )
    
    if not result:
        return False
    
    import tempfile
    temp_dir = tempfile.gettempdir()
    zip_path = os.path.join(temp_dir, f'{ADDON_ID}-{version}.zip')
    
    if not download_update(url, zip_path):
        xbmcgui.Dialog().notification('XStream Player', 'Download failed', xbmcgui.NOTIFICATION_ERROR)
        return False
    
    # Extract zip directly to addons folder (silent install)
    import zipfile
    addon_path = xbmcvfs.translatePath('special://home/addons/')
    try:
        with zipfile.ZipFile(zip_path, 'r') as zip_ref:
            zip_ref.extractall(addon_path)
        xbmc.executebuiltin('UpdateLocalAddons')
    except Exception as e:
        xbmc.log(f'[XStream Player] Extract failed: {str(e)}', xbmc.LOGERROR)
        xbmcgui.Dialog().notification('XStream Player', 'Install failed', xbmcgui.NOTIFICATION_ERROR)
        return False
    
    restart = dialog.yesno(
        'Revert Complete',
        f'Version {version} installed!\n\nRelaunch Kodi now?',
        nolabel='Later',
        yeslabel='Restart Now'
    )
    
    if restart:
        xbmc.executebuiltin('RestartApp')
    
    return True

def revert_version_menu():
    """Show menu to select version to revert to"""
    dialog = xbmcgui.Dialog()
    
    # Get available versions
    versions = get_available_versions()
    current = get_current_version()
    
    if not versions:
        dialog.notification('XStream Player', 'Could not fetch versions', xbmcgui.NOTIFICATION_ERROR)
        return
    
    # Filter out current version and show older ones
    older_versions = [v for v in versions if v != current]
    
    if not older_versions:
        dialog.ok('XStream Player', 'No older versions available to revert.')
        return
    
    # Show selection dialog
    selected = dialog.select(f'Revert to (current: {current})', older_versions)
    
    if selected == -1:  # User cancelled
        return
    
    # Revert to selected version
    revert_to_version(older_versions[selected])

# Entry point for RunScript calls
if __name__ == '__main__':
    if len(sys.argv) > 1:
        action = sys.argv[1]
        if action == 'check':
            check_and_install_update()
        elif action == 'silent':
            silent_check_on_startup()
