To disable changelog go to Tools/Settings/Update

## Version 2.0.0

### New Features
- Multi-profile support — up to 10 independent IPTV profiles on the main screen, each with fully isolated caches, favorites, watch history, resume points, search history, and hidden categories
- Single-profile direct mode — when only one profile enabled, its content (Live TV, Movies, Series, Replay) appear directly on the main menu instead of inside a profile folder, "Settings/General/Show profile content..."
- Backup & Restore — manifest-based version dispatch, settings whitelist for safe keys, automatic cache clearing on restore, and immediate PVR sync prompts
- Backup folder settings UI — browse and set the backup folder directly from addon settings
- Profile credential change detection — settings dialog snapshots credentials before/after changes and immediately prompts to load channels and sync PVR
- PVR sync retry — if user declines PVR sync after restore or settings changes, a retry prompt appears at next startup if PVR is empty
- Legacy v1.1.5 or older backup import — restores credentials, favorites, EPG cache, and history from older backups
- Cross-profile Global Search — added "All Profiles" option to search across all enabled profiles with combined or per-profile result views
- Series autoplay — automatically queues the next episode when watching series
- Series Up next — Install from Settings/Playback and buffer, after install go to "Settings/Playback-and-buffer/Up Next" settings and turn on "Behaviour/enable on playlist"
- Content loading controls — per-profile and manage content settings replace the old per-type toggles, letting you control which categories load and how many pages appear
- Pagination settings — independent page-size controls for Live TV, Movies, Series, and M3U Classic
- Parental control — PIN is now stored as SHA-256 hash instead of plaintext
- Search history clear options — added to Tools → Clear cache/history
- Automatic stale cache cleanup — removes cache files older than 7 days on startup
- EPG auto-detect fallback — when primary EPG URL fails it uses fallback and notifies the user

### UI / Settings Changes
- Tools menu reorganized into General settings, Manage Content, Reload profile data, and Reset/Reload sections
- `Warn about insecure HTTP connections` setting moved from "PVR and EPG" to "General settings"
- `PVR reload on launch` renamed to "Ensure PVR client is enabled on launch" for clarity
- Parental PIN input dialogs now use the full on-screen keyboard with masked input

### Many Bug Fixes and UI optimisations
