﻿# -*- coding: utf-8 -*-
import re

files = [
    'epg.py', 'iptv.py', 'updater.py', 'profiles.py', 
    'favorites.py', 'history.py', 'tmdb.py', 'lang.py'
]

for fname in files:
    with open(fname, 'r', encoding='utf-8') as f:
        lines = f.readlines()
    
    print(f'=== {fname} ===')
    for i, line in enumerate(lines):
        if re.match(r'^(\s*)def\s+\w+\(', line):
            j = i + 1
            while j < len(lines) and lines[j].strip() == '':
                j += 1
            if j < len(lines):
                next_line = lines[j].strip()
                if not (next_line.startswith('\"\"\"') or next_line.startswith("\"\"\"")):
                    print(f'  Line {i+1}: {line.strip()}')
