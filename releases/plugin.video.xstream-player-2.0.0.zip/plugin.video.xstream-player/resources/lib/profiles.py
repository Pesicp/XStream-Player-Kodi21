# -*- coding: utf-8 -*-
import json
import os
import re
import time

import xbmcvfs


class ProfileManager:
    def __init__(self, addon):
        self.addon = addon
        raw = addon.getSetting("active_pvr_profile") or "Profile 1"
        match = re.search(r"(\d+)$", raw)
        self.active = match.group(1) if match else "1"
        # self.active is PVR profile only; non-PVR code must pass explicit profile_num.
        self.profile_path = xbmcvfs.translatePath(addon.getAddonInfo("profile"))
        if not os.path.exists(self.profile_path):
            os.makedirs(self.profile_path)
        self._cat_file = os.path.join(self.profile_path, "category_prefs.json")

    def _load_cat_prefs(self):
        try:
            with open(self._cat_file, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return {}

    def _save_cat_prefs(self, prefs):
        tmp_file = self._cat_file + ".tmp"
        with open(tmp_file, "w", encoding="utf-8") as f:
            json.dump(prefs, f)
            try:
                f.flush()
                os.fsync(f.fileno())
            except OSError:
                pass
        os.replace(tmp_file, self._cat_file)

    def get_profile_setting(self, key):
        return self.addon.getSetting(f"profile_{self.active}_{key}")

    def get_credentials(self):
        import re

        source_type = self.get_profile_setting("source_type")

        # Get M3U URL if set (always read it, not just when source_type=="M3U",
        # so that missing/corrupted source_type doesn't silently drop credentials)
        m3u_url = self.get_profile_setting("m3u") or ""

        # Check if M3U has credentials (username/password in URL)
        has_m3u_creds = bool(m3u_url) and bool(
            re.search(
                r"\b(username|password|user|pass)=[^&\s]+", m3u_url, re.IGNORECASE
            )
        )

        # Get Xtream credentials (or parse from M3U if it has creds)
        if has_m3u_creds:
            # Parse M3U URL to extract Xtream credentials
            try:
                from urllib.parse import urlparse, parse_qs

                parsed = urlparse(m3u_url)
                params = parse_qs(parsed.query)
                username = params.get("username", [""])[0]
                password = params.get("password", [""])[0]
                base_url = f"{parsed.scheme}://{parsed.netloc}"
                xtream_url = base_url if username and password else ""
                xtream_username = username
                xtream_password = password
            except Exception:
                xtream_url = ""
                xtream_username = ""
                xtream_password = ""
        else:
            xtream_url = (
                self.get_profile_setting("xtream_url") if source_type != "M3U" else ""
            )
            xtream_username = (
                self.get_profile_setting("xtream_username")
                if source_type != "M3U"
                else ""
            )
            xtream_password = (
                self.get_profile_setting("xtream_password")
                if source_type != "M3U"
                else ""
            )

        # Get EPG URL (new fields with fallback to legacy epg_url)
        epg_m3u = self.get_profile_setting("epg_m3u") or ""
        epg_xtream = self.get_profile_setting("epg_xtream") or ""
        legacy_epg = self.get_profile_setting("epg_url") or ""  # Legacy field

        # Use appropriate EPG or fallback to legacy
        if source_type == "M3U":
            epg_url = epg_m3u or legacy_epg
        else:
            epg_url = epg_xtream or legacy_epg

        creds = {
            "name": self.get_profile_setting("name"),
            "source_type": source_type,
            "m3u_url": m3u_url,
            "xtream_url": xtream_url,
            "xtream_username": xtream_username,
            "xtream_password": xtream_password,
            "epg_m3u": epg_m3u,
            "epg_xtream": epg_xtream,
            "epg_url": epg_url,  # Legacy + fallback
        }
        return creds

    def get_visible_categories(self):
        prefs = self._load_cat_prefs()
        raw = prefs.get("global")
        if raw is None:
            defaults = ["live_pvr", "guide", "pvr_favs", "favorites", "search", "tools"]
            # v1.1.5 → v2.0 compatibility: auto-show credentialed profiles
            # When no category_prefs.json exists (fresh install or after update),
            # enabled profiles with login data are automatically visible.
            for n in range(1, 11):
                if self.addon.getSetting(f"profile_{n}_enabled") == "true":
                    has_xtream = bool(self.addon.getSetting(f"profile_{n}_xtream_url"))
                    has_m3u = bool(self.addon.getSetting(f"profile_{n}_m3u"))
                    if has_xtream or has_m3u:
                        defaults.append(f"profile_{n}")
            return defaults
        return [x.strip().lower() for x in raw.split("|") if x.strip()]

    def set_visible_categories(self, categories):
        prefs = self._load_cat_prefs()
        prefs["global"] = "|".join(categories)
        self._save_cat_prefs(prefs)


class RefreshTracker:
    def __init__(self, addon):
        self.addon = addon
        raw = addon.getSetting("active_pvr_profile") or "Profile 1"
        match = re.search(r"(\d+)$", raw)
        self.profile = match.group(1) if match else "1"
        self.profile_path = xbmcvfs.translatePath(addon.getAddonInfo("profile"))
        self.file = os.path.join(self.profile_path, f"refresh_{self.profile}.txt")
        self._ensure_profile()

    def _ensure_profile(self):
        if not os.path.exists(self.profile_path):
            os.makedirs(self.profile_path)

    def get_last_refresh(self):
        try:
            with open(self.file, "r", encoding="utf-8") as f:
                return float(f.read().strip())
        except Exception:
            return 0

    def set_last_refresh(self, t=None):
        t = t or time.time()
        with open(self.file, "w", encoding="utf-8") as f:
            f.write(str(t))

    def should_refresh(self):
        if self.addon.getSetting("auto_refresh_enabled").lower() != "true":
            return False
        interval = self.addon.getSetting("auto_refresh_interval") or "24"
        # settings.xml stores the raw English value from values="12|24|48|Never"
        if interval.lower() == "never":
            return False
        try:
            hours = float(interval)
        except ValueError:
            hours = 24
        last = self.get_last_refresh()
        return (time.time() - last) > (hours * 3600)
