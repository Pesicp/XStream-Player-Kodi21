To disable changelog go to Tools/Settings/Update

Version 1.1.0
- TMDB Integration: cast, genre, ratings, year
- Individual TMDB toggles (plot, posters, ratings, cast)
- Plot shows: Year | Genre + Cast + Plot text
- Fixed cache refresh for missing cast/genre
- Fixed Windows filename sanitization for TMDB cache
- Clear TMDB Cache added to Tools menu
