Version 1.0.9
------------------------

NEW FEATURES:

Main Menu Reorder
Tools -> Reorder Main Menu
    - Pick item to move
    - Pick destination (Before: [item] or Move to End)
    - Confirm with OK
    - Main menu updates instantly
    - Smart: handles enabled/disabled addon groups
    - Per-profile: each profile has its own saved order

Clear Watched Content
Tools -> Clear Cache/History -> Clear Watched Content
    - Clear All Watched (Movies + Series + Live TV)
    - Clear Watched Movies only
    - Clear Watched Series only
    - Clear Watched Live TV only
    - Per-profile: clears only active profile's data

TMDB Plot-Only Setting
Settings -> TMDB Integration
    - New option: "Use TMDB plot/info"
    - Works separate from poster setting
    - Get plots without changing posters

Auto-Show Changelog After Update
Settings -> Updates
    - Toggle: "Show changelog after update"
    - Changelog pops up automatically on first launch after update
    - Shows only the latest version's changes
    - "View Changelog" button to view full history anytime

Versions.json for Updates
    - More reliable update/revert system
    - No GitHub API rate limits
    - Faster version checking


BUG FIXES:

Movie Watched Markers Fixed
    - Problem: ResumePoints auto-deleted entries at >93% playback
    - Solution: New WatchedMovies class with persistent storage
    - Movies now properly show watched checkmarks

Context Menu Naming
    - Renamed to "Watched - XStream" / "Unwatched - XStream"
    - No confusion with Kodi's native marking
    - Available: Movies, Series, Seasons, Episodes

Main Menu Reorder Bug
    - Fixed "Before" logic placing items wrong
    - Fixed menu not updating until relaunch